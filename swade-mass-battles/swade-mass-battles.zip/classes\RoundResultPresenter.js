import { MassBattleRulesEngine } from './MassBattleRulesEngine.js';

export class RoundResultPresenter {
  constructor({ rulesEngine = MassBattleRulesEngine } = {}) {
    this.rulesEngine = rulesEngine;
  }

  getTokenImageForSide(side) {
    return side === 'player'
      ? 'modules/swade-mass-battles/images/BattleForceTokenGood.png'
      : 'modules/swade-mass-battles/images/BattleForceTokenEvil.png';
  }

  buildCurrentRoundResultEffectData(side, resultName, tokenImage, roundNumber) {
    const resultSlug = resultName.toLowerCase().replace(/\s+/g, '-');
    const shouldPulse = resultName === 'Victory' || resultName === 'Marginal Victory';
    return {
      cardClass: `round-result-effect-card round-result-${resultSlug}${shouldPulse ? ' round-result-pulse' : ''}`,
      compactClass: 'round-result-compact',
      expandedClass: 'round-result-expanded',
      hasButtons: false,
      title: `Round ${roundNumber}: ${resultName}`,
      description: 'Round outcome effect from this side perspective.',
      hasEffects: true,
      tokenImage,
      side,
      sameSideEffects: this.rulesEngine.getRoundResultEffects(resultName)
    };
  }

  buildRoundResultEffectDataFromEntry(side, entry) {
    const resultName = entry.resultName;
    const resultSlug = resultName.toLowerCase().replace(/\s+/g, '-');
    const tokenImage = this.getTokenImageForSide(side);
    const shouldPulse = resultName === 'Victory' || resultName === 'Marginal Victory';
    const ownSuccesses = Number.isFinite(Number(entry?.sideSuccesses)) ? Number(entry.sideSuccesses) : null;
    const otherSuccesses = Number.isFinite(Number(entry?.otherSuccesses)) ? Number(entry.otherSuccesses) : null;
    const sideName = entry?.sideName || (side === 'player' ? 'Player Battlemaster' : 'Enemy Battlemaster');
    const otherName = entry?.otherName || (side === 'player' ? 'Enemy Battlemaster' : 'Player Battlemaster');
    const descriptor = (typeof entry?.descriptor === 'string' && entry.descriptor.trim().length)
      ? entry.descriptor
      : (Number.isFinite(ownSuccesses) && Number.isFinite(otherSuccesses)
      ? this.rulesEngine.buildRoundResultDescriptorFromParts(sideName, ownSuccesses, otherName, otherSuccesses, resultName)
      : 'Round outcome effect from this side perspective.');
    const tokenFlow = this.rulesEngine.getStoredRoundTokenFlow(entry)
      || this.rulesEngine.aggregateTokenFlowFromValues([this.rulesEngine.getRoundTokenDeltaForResult(resultName)]);
    const netDeltaText = tokenFlow.netDelta > 0 ? `+${tokenFlow.netDelta}` : `${tokenFlow.netDelta}`;
    const modifierStickers = tokenFlow.lossOccurred
      ? [{ text: `Tokens ${netDeltaText}`, affectedSide: side }]
      : [];

    return {
      cardClass: `round-result-effect-card round-result-${resultSlug}${shouldPulse ? ' round-result-pulse' : ''}`,
      compactClass: 'round-result-compact',
      expandedClass: 'round-result-expanded',
      hasButtons: false,
      title: `Round ${entry.round}: ${resultName}`,
      description: descriptor,
      hasEffects: true,
      side,
      modifierStickers,
      tokenImage,
      sameSideEffects: this.rulesEngine.getRoundResultEffects(resultName)
    };
  }

}