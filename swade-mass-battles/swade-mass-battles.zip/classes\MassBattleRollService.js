import { MassBattleRulesEngine } from './MassBattleRulesEngine.js';

export class MassBattleRollService {
  constructor({ rulesEngine = MassBattleRulesEngine } = {}) {
    this.rulesEngine = rulesEngine;
  }

  async rollBattle(actor, side) {
    const battleSkillItem = actor.items.find((item) => item.type === 'skill' && item.name === 'Battle');
    if (battleSkillItem) {
      const modifiers = this.rulesEngine.calculateModifiers(side);
      const totalModifier = Number(modifiers?.battle) || 0;
      await battleSkillItem.roll({
        additionalMods: [{ label: 'Mass Battle Modifiers', value: totalModifier }]
      });
    } else {
      ui.notifications.warn(`${actor.name} does not have a Battle skill.`);
    }
  }

  async rollMorale(actor, side) {
    const modifiers = this.rulesEngine.calculateModifiers(side);
    const totalMoraleModifier = Number(modifiers?.morale) || 0;
    await actor.rollAttribute('spirit', {
      additionalMods: [{ label: 'Mass Battle Morale Modifiers', value: totalMoraleModifier }]
    });
  }
}