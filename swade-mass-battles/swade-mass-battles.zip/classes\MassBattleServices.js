import { MassBattleRulesEngine } from './MassBattleRulesEngine.js';
import { RoundResultPresenter } from './RoundResultPresenter.js';
import { MassBattleRollService } from './MassBattleRollService.js';
import { WorkflowService } from './WorkflowService.js';
import { WorkflowContextBuilder } from './WorkflowContextBuilder.js';
import { WorkflowInteractionController } from './WorkflowInteractionController.js';
import { WorkflowHudAccessService } from './WorkflowHudAccessService.js';

export class MassBattleServices {
  constructor({ rulesEngine = MassBattleRulesEngine } = {}) {
    this.rulesEngine = rulesEngine;
    this.roundResultPresenter = new RoundResultPresenter({ rulesEngine: this.rulesEngine });
    this.rollService = new MassBattleRollService({ rulesEngine: this.rulesEngine });
    this.workflowHudAccess = new WorkflowHudAccessService();
    this.workflowService = new WorkflowService({ rulesEngine: this.rulesEngine });
    this.workflowContextBuilder = new WorkflowContextBuilder({
      rulesEngine: this.rulesEngine,
      workflowService: this.workflowService
    });
    this.workflowInteractionController = new WorkflowInteractionController();
  }
}