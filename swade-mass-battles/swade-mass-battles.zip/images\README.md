# Battle Force Token Images

Place the following images in this folder:
- `BattleForceTokenGood.png` - Token image for player forces
- `BattleForceTokenEvil.png` - Token image for enemy forces

Recommended size: 32x32 pixels or larger (will be scaled to 32x32)
