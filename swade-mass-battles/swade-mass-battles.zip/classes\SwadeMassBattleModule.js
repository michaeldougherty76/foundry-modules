import { BattleData } from './BattleData.js';
import { MassBattleServices } from './MassBattleServices.js';
import { MassBattleHUDManager } from './MassBattleHUDManager.js';
import { TroopStatusesConfig } from './TroopStatusesConfig.js';
import { SocketHelper } from './helpers/SocketHelper.js';

export class SwadeMassBattleModule {
  static MODULE_ID = 'swade-mass-battles';
  static PLAYER_HUD_POSITION_SETTING = 'playerHudPosition';
  static ENEMY_HUD_POSITION_SETTING = 'enemyHudPosition';
  static sidebarResizeObserver = null;
  static hudTemplatesPromise = null;
  static massBattleHUD = null;
  static services = null;

  static getServices() {
    if (!SwadeMassBattleModule.services) {
      SwadeMassBattleModule.services = new MassBattleServices();
    }

    return SwadeMassBattleModule.services;
  }

  static getMassBattleHUD() {
    if (!SwadeMassBattleModule.massBattleHUD) {
      SwadeMassBattleModule.massBattleHUD = MassBattleHUDManager.getConfiguredInstance(SwadeMassBattleModule.massBattleHUD);
    }

    return SwadeMassBattleModule.massBattleHUD;
  }

  static exposeApi() {
    const swadeBattlesModule = game.modules.get(SwadeMassBattleModule.MODULE_ID);
    if (!swadeBattlesModule) return;

    swadeBattlesModule.api = {
      ...(swadeBattlesModule.api || {}),
      massBattleHUD: SwadeMassBattleModule.getMassBattleHUD(),
      getMassBattleHUD: () => SwadeMassBattleModule.getMassBattleHUD(),
      services: SwadeMassBattleModule.getServices(),
      getServices: () => SwadeMassBattleModule.getServices()
    };
  }

  static getMassBattleResultsTableChoices() {
    const choices = {
      '': '(None)'
    };

    const tables = Array.from(game.tables ?? []).sort((left, right) => left.name.localeCompare(right.name));
    for (const table of tables) {
      choices[table.uuid] = table.name;
    }

    return choices;
  }

  static registerSettings() {
    game.settings.register(SwadeMassBattleModule.MODULE_ID, 'battleData', {
      scope: 'world',
      config: false,
      type: Object,
      default: BattleData.defaultData()
    });

    game.settings.register(SwadeMassBattleModule.MODULE_ID, 'troopStatuses', {
      scope: 'world',
      config: false,
      type: Array,
      default: []
    });

    game.settings.register(SwadeMassBattleModule.MODULE_ID, SwadeMassBattleModule.PLAYER_HUD_POSITION_SETTING, {
      scope: 'client',
      config: false,
      type: Object,
      default: {
        top: null,
        left: null
      }
    });

    game.settings.register(SwadeMassBattleModule.MODULE_ID, SwadeMassBattleModule.ENEMY_HUD_POSITION_SETTING, {
      scope: 'client',
      config: false,
      type: Object,
      default: {
        top: null,
        right: null
      }
    });

    game.settings.registerMenu(SwadeMassBattleModule.MODULE_ID, 'troopStatusesMenu', {
      name: 'Configure Troop Statuses',
      label: 'Configure Troop Statuses',
      hint: 'Manage the available status options and their modifiers for troops',
      icon: 'fas fa-users',
      type: TroopStatusesConfig,
      restricted: true
    });
  }

  static registerKeybindings() {
    const toggleHud = () => {
      if (!game.user?.isGM) return true;
      void SwadeMassBattleModule.getMassBattleHUD().toggleHud();
      return true;
    };

    game.keybindings.register(SwadeMassBattleModule.MODULE_ID, 'openMassBattles', {
      name: 'Toggle Mass Battles HUD (Legacy Binding)',
      hint: 'Legacy binding that now toggles the Mass Battles HUD overlay',
      editable: [
        {
          key: 'KeyB',
          modifiers: ['Control', 'Shift']
        }
      ],
      onDown: toggleHud,
      restricted: false,
      precedence: CONST.KEYBINDING_PRECEDENCE.NORMAL
    });

    game.keybindings.register(SwadeMassBattleModule.MODULE_ID, 'toggleBattlesHUD', {
      name: 'Toggle Mass Battles HUD',
      hint: 'Toggles the Mass Battles HUD overlay',
      editable: [
        {
          key: 'KeyB',
          modifiers: ['Control']
        }
      ],
      onDown: toggleHud,
      restricted: false,
      precedence: CONST.KEYBINDING_PRECEDENCE.PRIORITY
    });
  }

  static async ensureHudTemplatesLoaded() {
    if (!SwadeMassBattleModule.hudTemplatesPromise) {
      SwadeMassBattleModule.hudTemplatesPromise = loadTemplates([
        'modules/swade-mass-battles/hbs/partials/battle-master.hbs',
        'modules/swade-mass-battles/hbs/partials/battlemaster-drop-zone.hbs',
        'modules/swade-mass-battles/hbs/partials/effect-card.hbs',
        'modules/swade-mass-battles/hbs/partials/force-section.hbs',
        'modules/swade-mass-battles/hbs/partials/tactical-advantages-section.hbs',
        'modules/swade-mass-battles/hbs/partials/troops-effect-cell.hbs',
        'modules/swade-mass-battles/hbs/partials/troops-section.hbs'
      ]);
    }

    await SwadeMassBattleModule.hudTemplatesPromise;
  }

  static async initialize() {
    SwadeMassBattleModule.exposeApi();
    SwadeMassBattleModule.registerSettings();
    SwadeMassBattleModule.registerKeybindings();
    await SwadeMassBattleModule.ensureHudTemplatesLoaded();
  }

  static ensureMassBattleResultsTableSetting() {
    if (game.settings.settings.has(`${SwadeMassBattleModule.MODULE_ID}.massBattleResultsTable`)) return;

    game.settings.register(SwadeMassBattleModule.MODULE_ID, 'massBattleResultsTable', {
      name: 'Mass Battle Results Table',
      hint: 'Select the RollTable used by the troop action button to roll Mass Battle results.',
      scope: 'world',
      config: true,
      restricted: true,
      type: String,
      default: '',
      choices: SwadeMassBattleModule.getMassBattleResultsTableChoices()
    });
  }

  static initializeHudAnchors(manager) {
    manager.updateHudAnchorPositions();

    window.addEventListener('resize', () => manager.updateHudAnchorPositions());

    const sidebar = document.querySelector('#sidebar');
    if (!sidebar || typeof ResizeObserver === 'undefined') return;

    SwadeMassBattleModule.sidebarResizeObserver?.disconnect?.();
    SwadeMassBattleModule.sidebarResizeObserver = new ResizeObserver(() => manager.updateHudAnchorPositions());
    SwadeMassBattleModule.sidebarResizeObserver.observe(sidebar);
  }

  static async initializeSockets() {
    if (await SocketHelper.initializeSocketlib(SwadeMassBattleModule.MODULE_ID)) {
      console.log('SWADE Battles: socketlib initialized');
      if (!game.user?.isGM) {
        await SocketHelper.requestMassBattlesStatusFromGM();
      }
      return;
    }

    console.warn('SWADE Battles: socketlib not found. Real-time sync disabled. Please install the socketlib module for multi-user synchronization.');
  }

  static async ready() {
    console.log('SWADE Battles ready');

    const manager = SwadeMassBattleModule.getMassBattleHUD();
    if (manager) {
      SwadeMassBattleModule.initializeHudAnchors(manager);
    }

    SwadeMassBattleModule.ensureMassBattleResultsTableSetting();
    await BattleData.ensureDefaults();

    await SwadeMassBattleModule.ensureHudTemplatesLoaded();

    await SwadeMassBattleModule.initializeSockets();
  }
}