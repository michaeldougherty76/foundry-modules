import { UIHelper } from './helpers/UIHelper.js';

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const { DialogV2 } = foundry.applications.api;

/**
 * Configuration form for Troop Statuses
 */
export class TroopStatusesConfig extends HandlebarsApplicationMixin(ApplicationV2) {
  static MODULE_ID = 'swade-mass-battles';

  static TROOP_STATUSES_SETTING = 'troopStatuses';

  static DEFAULT_OPTIONS = {
    id: 'troop-statuses-config',
    tag: 'form',
    window: {
      title: 'Configure Troop Statuses',
      resizable: true
    },
    position: {
      width: 760,
      height: 760
    },
    form: {
      handler: async function(event, form, formData) {
        await this._handleSubmit(event, form, formData);
      },
      closeOnSubmit: true
    }
  };

  static PARTS = {
    content: { template: 'modules/swade-mass-battles/hbs/troop-statuses-config.hbs' }
  };

  async _prepareContext(options) {
    const statuses = game.settings.get(TroopStatusesConfig.MODULE_ID, TroopStatusesConfig.TROOP_STATUSES_SETTING);
    return { statuses };
  }

  async _onRender(context, options) {
    await super._onRender(context, options);
    const html = $(this.element);

    UIHelper.addStatusButtons(html).on('click', () => {
      const statuses = game.settings.get(TroopStatusesConfig.MODULE_ID, TroopStatusesConfig.TROOP_STATUSES_SETTING);
      statuses.push({
        result: 'New Status',
        resultDescription: '',
        battleModifierSameSide: 0,
        battleModifierOppositeSide: 0,
        moraleModifierSameSide: 0,
        moraleModifierOppositeSide: 0,
        forceTokenModifierSameSide: 0,
        forceTokenModifierOppositeSide: 0,
        suffersFatigue: 0,
        suffersWound: 0,
      });
      game.settings.set(TroopStatusesConfig.MODULE_ID, TroopStatusesConfig.TROOP_STATUSES_SETTING, statuses);
      this.render();
    });

    UIHelper.deleteStatusButtons(html).on('click', (event) => {
      const index = parseInt(event.currentTarget.dataset.index);
      const statuses = game.settings.get(TroopStatusesConfig.MODULE_ID, TroopStatusesConfig.TROOP_STATUSES_SETTING);
      statuses.splice(index, 1);
      game.settings.set(TroopStatusesConfig.MODULE_ID, TroopStatusesConfig.TROOP_STATUSES_SETTING, statuses);
      this.render();
    });

    UIHelper.exportStatusesButtons(html).on('click', () => {
      void this._showExportDialog();
    });

    UIHelper.importStatusesButtons(html).on('click', () => {
      void this._showImportDialog();
    });
  }

  async _handleSubmit(event, form, formData) {
    const expanded = foundry.utils.expandObject(formData.object);
    const statuses = this._normalizeStatuses(expanded?.statuses || []);

    await game.settings.set(TroopStatusesConfig.MODULE_ID, TroopStatusesConfig.TROOP_STATUSES_SETTING, statuses);
    ui.notifications.info('Troop statuses updated successfully');
  }

  _normalizeStatuses(statusesInput) {
    const source = Array.isArray(statusesInput)
      ? statusesInput
      : Object.values(statusesInput || {});

    return source.map((status) => ({
      result: status?.result || 'Unnamed',
      resultDescription: status?.resultDescription || '',
      battleModifierSameSide: Number.parseInt(status?.battleModifierSameSide, 10) || 0,
      battleModifierOppositeSide: Number.parseInt(status?.battleModifierOppositeSide, 10) || 0,
      moraleModifierSameSide: Number.parseInt(status?.moraleModifierSameSide, 10) || 0,
      moraleModifierOppositeSide: Number.parseInt(status?.moraleModifierOppositeSide, 10) || 0,
      forceTokenModifierSameSide: Number.parseInt(status?.forceTokenModifierSameSide, 10) || 0,
      forceTokenModifierOppositeSide: Number.parseInt(status?.forceTokenModifierOppositeSide, 10) || 0,
      suffersFatigue: Number.parseInt(status?.suffersFatigue, 10) || 0,
      suffersWound: Number.parseInt(status?.suffersWound, 10) || 0,
    }));
  }

  _collectStatusesFromCurrentForm() {
    const html = $(this.element);
    const statuses = [];
    const rows = html.find('.status-entry');

    if (!rows.length) {
      return game.settings.get(TroopStatusesConfig.MODULE_ID, TroopStatusesConfig.TROOP_STATUSES_SETTING);
    }

    rows.each((index, row) => {
      const rowHtml = $(row);
      statuses.push({
        result: rowHtml.find(`[name="statuses.${index}.result"]`).val(),
        resultDescription: rowHtml.find(`[name="statuses.${index}.resultDescription"]`).val(),
        battleModifierSameSide: rowHtml.find(`[name="statuses.${index}.battleModifierSameSide"]`).val(),
        battleModifierOppositeSide: rowHtml.find(`[name="statuses.${index}.battleModifierOppositeSide"]`).val(),
        moraleModifierSameSide: rowHtml.find(`[name="statuses.${index}.moraleModifierSameSide"]`).val(),
        moraleModifierOppositeSide: rowHtml.find(`[name="statuses.${index}.moraleModifierOppositeSide"]`).val(),
        forceTokenModifierSameSide: rowHtml.find(`[name="statuses.${index}.forceTokenModifierSameSide"]`).val(),
        forceTokenModifierOppositeSide: rowHtml.find(`[name="statuses.${index}.forceTokenModifierOppositeSide"]`).val(),
        suffersFatigue: rowHtml.find(`[name="statuses.${index}.suffersFatigue"]`).val(),
        suffersWound: rowHtml.find(`[name="statuses.${index}.suffersWound"]`).val(),
      });
    });

    return this._normalizeStatuses(statuses);
  }

  async _showExportDialog() {
    const statuses = this._collectStatusesFromCurrentForm();
    const statusJson = JSON.stringify(statuses, null, 2);

    await DialogV2.wait({
      window: {
        title: 'Export Troop Statuses JSON'
      },
      content: `
        <div class="status-json-dialog">
          <p>Copy this JSON and keep it as a backup or share it between worlds.</p>
          <textarea id="troop-statuses-export-json" readonly>${statusJson}</textarea>
        </div>
      `,
      position: {
        width: 720,
        height: 560
      },
      buttons: [
        {
          action: 'copy',
          label: 'Copy JSON',
          callback: async (_event, _button, dialog) => {
            const textArea = dialog.element?.querySelector('#troop-statuses-export-json');
            const text = textArea?.value || statusJson;

            try {
              await navigator.clipboard.writeText(text);
              ui.notifications.info('Troop statuses JSON copied to clipboard.');
            } catch (_error) {
              ui.notifications.warn('Unable to copy automatically. Please copy the JSON manually.');
            }
          }
        },
        {
          action: 'close',
          label: 'Close',
          default: true
        }
      ]
    });
  }

  async _showImportDialog() {
    await DialogV2.wait({
      window: {
        title: 'Import Troop Statuses JSON'
      },
      content: `
        <div class="status-json-dialog">
          <p>Paste a JSON array of status objects. Saving will replace all existing troop status configs.</p>
          <textarea id="troop-statuses-import-json" placeholder='[\n  {\n    "result": "Normal",\n    "resultDescription": "No penalties",\n    "battleModifierSameSide": 0\n  }\n]'></textarea>
        </div>
      `,
      position: {
        width: 720,
        height: 560
      },
      buttons: [
        {
          action: 'save',
          label: 'Save Import',
          default: true,
          callback: async (_event, _button, dialog) => {
            const textArea = dialog.element?.querySelector('#troop-statuses-import-json');
            const inputJson = (textArea?.value || '').trim();

            if (!inputJson) {
              ui.notifications.warn('Import JSON is empty.');
              return false;
            }

            let parsed;
            try {
              parsed = JSON.parse(inputJson);
            } catch (_error) {
              ui.notifications.error('Invalid JSON. Please check the format and try again.');
              return false;
            }

            if (!Array.isArray(parsed)) {
              ui.notifications.error('Imported JSON must be an array of status objects.');
              return false;
            }

            const normalized = this._normalizeStatuses(parsed);
            await game.settings.set(TroopStatusesConfig.MODULE_ID, TroopStatusesConfig.TROOP_STATUSES_SETTING, normalized);
            ui.notifications.info(`Imported ${normalized.length} troop status ${normalized.length === 1 ? 'entry' : 'entries'}.`);
            this.render();
          }
        },
        {
          action: 'cancel',
          label: 'Cancel'
        }
      ]
    });
  }
}
