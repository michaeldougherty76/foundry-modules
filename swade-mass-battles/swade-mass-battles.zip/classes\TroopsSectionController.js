import { UIHelper } from './helpers/UIHelper.js';

const { getTemplate } = foundry.applications.handlebars;

const TROOPS_EFFECT_CELL_TEMPLATE = 'modules/swade-mass-battles/hbs/partials/troops-effect-cell.hbs';

export class TroopsSectionController {
  static async load({ html, side, troops, prepareEffectData, onShowTroopStatusDialog, onRemoveTroop }) {
    html = $(html);
    const troopsGrid = UIHelper.troopsGrid(html, side);
    troopsGrid.empty();

    const troopStatuses = game.settings.get('swade-mass-battles', 'troopStatuses');
    const template = await getTemplate('modules/swade-mass-battles/hbs/partials/effect-card.hbs');
    const effectCellTemplate = await getTemplate(TROOPS_EFFECT_CELL_TEMPLATE);

    for (let index = 0; index < troops.length; index += 1) {
      const troop = troops[index];
      const actorUuid = typeof troop === 'string' ? troop : troop.uuid;
      const statusResult = typeof troop === 'object' ? (troop.status || 'Did not participate') : 'Did not participate';

      let status = troopStatuses.find((entry) => entry.result === statusResult);
      if (!status) {
        status = {
          result: 'Did not participate',
          resultDescription: 'The character did not participate directly in this Mass Battle this round.',
          battleModifierSameSide: 0,
          battleModifierOppositeSide: 0,
          moraleModifierSameSide: 0,
          moraleModifierOppositeSide: 0,
          forceTokenModifierSameSide: 0,
          forceTokenModifierOppositeSide: 0,
          suffersFatigue: 0,
          suffersWound: 0
        };
      }

      const actor = await fromUuid(actorUuid);
      if (actor) {
        const actorTokenImage = actor?.prototypeToken?.texture?.src || actor?.img;
        const effectData = prepareEffectData(side, status);
        const isDidNotParticipate = String(status.result || '').trim().toLowerCase() === 'did not participate';
        const didNotParticipateClass = isDidNotParticipate ? 'troop-status-did-not-participate' : '';

        const cardHtml = template({
          cardClass: `troop-effect-${side}-${index}`,
          compactClass: 'troop-compact',
          expandedClass: 'troop-expanded',
          hasButtons: true,
          removeButtonClass: 'remove-troop',
          editButtonClass: 'troop-status',
          side,
          index,
          title: status.result,
          description: status.resultDescription,
          showCompactActorImage: true,
          compactActorImageOnRight: true,
          actorImage: actorTokenImage,
          ...effectData
        });
        const effectCell = $(effectCellTemplate({
          side,
          index,
          didNotParticipateClass,
          cardHtml
        }));

        troopsGrid.append(effectCell);
      }
    }

    UIHelper.troopStatusButtons(html, side).on('click', async (event) => {
      const button = $(event.target);
      const buttonSide = button.data('side');
      const buttonIndex = button.data('index');
      await onShowTroopStatusDialog(buttonSide, buttonIndex);
    });

    UIHelper.removeTroopButtons(html, side).on('click', async (event) => {
      const button = $(event.target);
      const buttonSide = button.data('side');
      const buttonIndex = button.data('index');
      await onRemoveTroop(buttonSide, buttonIndex);
    });

    UIHelper.troopEffectCards(html, side).each(function() {
      UIHelper.troopCompact($(this)).on('click', function(event) {
        // Only toggle if we didn't click on a button
        if (!$(event.target).is('button')) {
          const card = $(this).closest('[class*="troop-effect-"]');
          UIHelper.troopExpanded(card).slideToggle(200);
        }
      });
    });
  }
}