import { SocketHelper } from './helpers/SocketHelper.js';
import { UIHelper } from './helpers/UIHelper.js';
import { MassBattleRulesEngine } from './MassBattleRulesEngine.js';
import { RoundResultPresenter } from './RoundResultPresenter.js';
import { HudContextBuilder } from './HudContextBuilder.js';
import { HudInteractionController } from './HudInteractionController.js';
import { BattlemasterSectionController } from './BattlemasterSectionController.js';
import { MassBattleRollService } from './MassBattleRollService.js';
import { AdvantagesSectionController } from './AdvantagesSectionController.js';
import { TroopsSectionController } from './TroopsSectionController.js';
import { HudMutationController } from './HudMutationController.js';

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;
const { getTemplate } = foundry.applications.handlebars;

const MODULE_ID = 'swade-mass-battles';
const PLAYER_HUD_POSITION_SETTING = 'playerHudPosition';
const ENEMY_HUD_POSITION_SETTING = 'enemyHudPosition';

function getMassBattleHUDManager() {
  return game.modules.get(MODULE_ID)?.api?.massBattleHUD ?? null;
}

function getMassBattleServices() {
  return game.modules.get(MODULE_ID)?.api?.services ?? null;
}

const state = {
  get playerMassBattlesHUD() {
    return getMassBattleHUDManager()?.getPlayerHUD?.() ?? null;
  },
  get enemyMassBattlesHUD() {
    return getMassBattleHUDManager()?.getEnemyHUD?.() ?? null;
  }
};

async function sendBattleDataUpdate(battleData) {
  await SocketHelper.sendBattleDataUpdate(battleData);
}

export class MassBattlesHUD extends HandlebarsApplicationMixin(ApplicationV2) {
  static async refreshMassBattlesHudContent() {
    const battleData = game.settings.get('swade-mass-battles', 'battleData');
    const workflowStage = Number.isInteger(battleData.workflowStage) ? battleData.workflowStage : 0;
    const isSetupStage = workflowStage === 0;
    const isTroopActionsStage = workflowStage === 2;
    const isBattleRollsStage = workflowStage === 3;
    const isMoraleChecksStage = workflowStage === 4;
    const renderedHuds = [state.playerMassBattlesHUD, state.enemyMassBattlesHUD]
      .filter((hud) => hud?.rendered && hud?.element);

    for (const hud of renderedHuds) {
      const hudRoot = $(hud.element);
      hudRoot.toggleClass('workflow-stage-setup-active', isSetupStage);
      hudRoot.toggleClass('workflow-stage-troop-actions-active', isTroopActionsStage);
      hudRoot.toggleClass('workflow-stage-battle-rolls-active', isBattleRollsStage);
      hudRoot.toggleClass('workflow-stage-morale-checks-active', isMoraleChecksStage);

      await hud.updateBattlemasterDisplay(hud.element, 'player');
      await hud.updateBattlemasterDisplay(hud.element, 'enemy');
      await hud.loadTroops(hud.element, 'player', battleData.playerTroops || []);
      await hud.loadTroops(hud.element, 'enemy', battleData.enemyTroops || []);
      await hud.updateBattlemasterButtons(hud.element, 'player');
      await hud.updateBattlemasterButtons(hud.element, 'enemy');
    }
  }

  static getBattleRollSuccesses(battleData, side) {
    return MassBattleRulesEngine.getBattleRollSuccesses(battleData, side);
  }

  static getRoundResultHistoryKey(side) {
    return MassBattleRulesEngine.getRoundResultHistoryKey(side);
  }

  static getRoundResultHistoryForSide(battleData, side) {
    return MassBattleRulesEngine.getRoundResultHistoryForSide(battleData, side);
  }

  static formatSuccessLabel(value) {
    return MassBattleRulesEngine.formatSuccessLabel(value);
  }

  static buildRoundResultDescriptorFromParts(sideName, sideSuccesses, otherName, otherSuccesses, resultName) {
    return MassBattleRulesEngine.buildRoundResultDescriptorFromParts(sideName, sideSuccesses, otherName, otherSuccesses, resultName);
  }

  static getRoundResultEffects(resultName) {
    return MassBattleRulesEngine.getRoundResultEffects(resultName);
  }

  static getRoundResultNameForSide(side, differential) {
    return MassBattleRulesEngine.getRoundResultNameForSide(side, differential);
  }

  static getRoundTokenDeltaForResult(resultName) {
    return MassBattleRulesEngine.getRoundTokenDeltaForResult(resultName);
  }

  static collectForceTokenModifierValues(entries, property) {
    return MassBattleRulesEngine.collectForceTokenModifierValues(entries, property);
  }

  static collectTroopForceTokenModifierValues(troops, troopStatuses, property) {
    return MassBattleRulesEngine.collectTroopForceTokenModifierValues(troops, troopStatuses, property);
  }

  static aggregateTokenFlowFromValues(values) {
    return MassBattleRulesEngine.aggregateTokenFlowFromValues(values);
  }

  static getStoredRoundTokenFlow(entry) {
    return MassBattleRulesEngine.getStoredRoundTokenFlow(entry);
  }

  static getRoundTokenFlowSourceValues(battleData, side, roundResultName = null) {
    return MassBattleRulesEngine.getRoundTokenFlowSourceValues(battleData, side, roundResultName);
  }

  static getRoundTokenFlowForResult(battleData, side, roundResultName) {
    return MassBattleRulesEngine.getRoundTokenFlowForResult(battleData, side, roundResultName);
  }

  static getRoundTokenFlowForSide(battleData, side, round = null) {
    return MassBattleRulesEngine.getRoundTokenFlowForSide(battleData, side, round);
  }

  static getCumulativeTokenLossesForSide(battleData, side) {
    return MassBattleRulesEngine.getCumulativeTokenLossesForSide(battleData, side);
  }

  static calculateModifiers(side) {
    return MassBattleRulesEngine.calculateModifiers(side);
  }

  static buildModifierStickers(side, effectData) {
    const oppositeSide = side === 'player' ? 'enemy' : 'player';
    const stickers = [];

    const pushSticker = (value, label, affectedSide) => {
      if (!Number.isFinite(value) || value === 0) return;
      const sign = value > 0 ? '+' : '';
      stickers.push({
        text: `${sign}${value} ${label}`,
        affectedSide
      });
    };

    pushSticker(Number(effectData?.battleModifierSameSide) || 0, 'Battle', side);
    pushSticker(Number(effectData?.moraleModifierSameSide) || 0, 'Morale', side);
    {
      const value = Number(effectData?.forceTokenModifierSameSide) || 0;
      const label = Math.abs(value) === 1 ? 'Token' : 'Tokens';
      pushSticker(value, label, side);
    }

    pushSticker(Number(effectData?.battleModifierOppositeSide) || 0, 'Battle', oppositeSide);
    pushSticker(Number(effectData?.moraleModifierOppositeSide) || 0, 'Morale', oppositeSide);
    {
      const value = Number(effectData?.forceTokenModifierOppositeSide) || 0;
      const label = Math.abs(value) === 1 ? 'Token' : 'Tokens';
      pushSticker(value, label, oppositeSide);
    }

    const count = stickers.length;
    if (count === 0) return [];

    return stickers.map((sticker, index) => {
      let topPercent = 50;
      if (count > 1) {
        topPercent = (index / (count - 1)) * 100;
      }

      return {
        ...sticker,
        topPercent: topPercent.toFixed(2)
      };
    });
  }

  static prepareEffectData(side, effectData) {
    const oppositeSide = side === 'player' ? 'enemy' : 'player';
    const sameSideEffects = [];
    const oppositeSideEffects = [];
    let woundStickerText = '';
    let fatigueStickerText = '';

    if (effectData.battleModifierSameSide !== 0) {
      const sign = effectData.battleModifierSameSide > 0 ? '+' : '';
      sameSideEffects.push({ text: `${sign}${effectData.battleModifierSameSide} Battle`, textCompact: `${sign}${effectData.battleModifierSameSide} Bat.`, isCharacterEffect: false });
    }
    if (effectData.moraleModifierSameSide !== 0) {
      const sign = effectData.moraleModifierSameSide > 0 ? '+' : '';
      sameSideEffects.push({ text: `${sign}${effectData.moraleModifierSameSide} Morale`, textCompact: `${sign}${effectData.moraleModifierSameSide} Mor.`, isCharacterEffect: false });
    }
    if (effectData.forceTokenModifierSameSide !== 0) {
      const sign = effectData.forceTokenModifierSameSide > 0 ? '+' : '';
      const tokenText = Math.abs(effectData.forceTokenModifierSameSide) === 1 ? 'Token' : 'Tokens';
      sameSideEffects.push({ text: `${sign}${effectData.forceTokenModifierSameSide} ${tokenText}`, textCompact: `${sign}${effectData.forceTokenModifierSameSide} ${tokenText}`, isCharacterEffect: false });
    }

    if (effectData.battleModifierOppositeSide !== 0) {
      const sign = effectData.battleModifierOppositeSide > 0 ? '+' : '';
      oppositeSideEffects.push({ text: `${sign}${effectData.battleModifierOppositeSide} Battle`, textCompact: `${sign}${effectData.battleModifierOppositeSide} Bat.`, isCharacterEffect: false });
    }
    if (effectData.moraleModifierOppositeSide !== 0) {
      const sign = effectData.moraleModifierOppositeSide > 0 ? '+' : '';
      oppositeSideEffects.push({ text: `${sign}${effectData.moraleModifierOppositeSide} Morale`, textCompact: `${sign}${effectData.moraleModifierOppositeSide} Mor.`, isCharacterEffect: false });
    }
    if (effectData.forceTokenModifierOppositeSide !== 0) {
      const sign = effectData.forceTokenModifierOppositeSide > 0 ? '+' : '';
      const tokenText = Math.abs(effectData.forceTokenModifierOppositeSide) === 1 ? 'Token' : 'Tokens';
      oppositeSideEffects.push({ text: `${sign}${effectData.forceTokenModifierOppositeSide} ${tokenText}`, textCompact: `${sign}${effectData.forceTokenModifierOppositeSide} ${tokenText}`, isCharacterEffect: false });
    }

    if (effectData.suffersFatigue > 0) {
      sameSideEffects.push({ text: `${effectData.suffersFatigue} Fatigue`, textCompact: `${effectData.suffersFatigue} Fat.`, isCharacterEffect: true });
      fatigueStickerText = `+${effectData.suffersFatigue} Fatigue`;
    }
    if (effectData.suffersWound > 0) {
      const woundText = effectData.suffersWound === 1 ? 'Wound' : 'Wounds';
      sameSideEffects.push({ text: `${effectData.suffersWound} ${woundText}`, textCompact: `${effectData.suffersWound} Wnd.`, isCharacterEffect: true });
      woundStickerText = `+${effectData.suffersWound} Wound`;
    }

    return {
      sameSideEffects,
      oppositeSideEffects,
      hasEffects: sameSideEffects.length > 0 || oppositeSideEffects.length > 0,
      modifierStickers: MassBattlesHUD.buildModifierStickers(side, effectData),
      woundStickerText,
      fatigueStickerText,
      tokenImage: side === 'player' ? 'modules/swade-mass-battles/images/BattleForceTokenGood.png' : 'modules/swade-mass-battles/images/BattleForceTokenEvil.png',
      oppositeTokenImage: oppositeSide === 'player' ? 'modules/swade-mass-battles/images/BattleForceTokenGood.png' : 'modules/swade-mass-battles/images/BattleForceTokenEvil.png'
    };
  }

  static buildStatusEffectsHtml(side, status) {
    if (!status) return '';
    const tokenImage = side === 'player' ? 'modules/swade-mass-battles/images/BattleForceTokenGood.png' : 'modules/swade-mass-battles/images/BattleForceTokenEvil.png';
    const oppositeTokenImage = side === 'player' ? 'modules/swade-mass-battles/images/BattleForceTokenEvil.png' : 'modules/swade-mass-battles/images/BattleForceTokenGood.png';
    const row = (img, text) => `<div style="display:flex;align-items:center;justify-content:center;gap:5px;font-size:0.85em;padding:2px 0;"><img src="${img}" style="width:16px;height:16px;border:none;"/><span>${text}</span></div>`;
    const rows = [];
    const formatSigned = (value) => value > 0 ? `+${value}` : `${value}`;

    if (status.battleModifierSameSide) rows.push(row(tokenImage, `${formatSigned(status.battleModifierSameSide)} Battle`));
    if (status.moraleModifierSameSide) rows.push(row(tokenImage, `${formatSigned(status.moraleModifierSameSide)} Morale`));
    if (status.forceTokenModifierSameSide) {
      const tokenText = Math.abs(status.forceTokenModifierSameSide) === 1 ? 'Token' : 'Tokens';
      rows.push(row(tokenImage, `${formatSigned(status.forceTokenModifierSameSide)} ${tokenText}`));
    }
    if ((status.suffersFatigue || 0) > 0) rows.push(row(tokenImage, `${status.suffersFatigue} Fatigue`));
    if ((status.suffersWound || 0) > 0) rows.push(row(tokenImage, `${status.suffersWound} ${status.suffersWound === 1 ? 'Wound' : 'Wounds'}`));

    if (status.battleModifierOppositeSide) rows.push(row(oppositeTokenImage, `${formatSigned(status.battleModifierOppositeSide)} Battle`));
    if (status.moraleModifierOppositeSide) rows.push(row(oppositeTokenImage, `${formatSigned(status.moraleModifierOppositeSide)} Morale`));
    if (status.forceTokenModifierOppositeSide) {
      const tokenText = Math.abs(status.forceTokenModifierOppositeSide) === 1 ? 'Token' : 'Tokens';
      rows.push(row(oppositeTokenImage, `${formatSigned(status.forceTokenModifierOppositeSide)} ${tokenText}`));
    }

    if (rows.length === 0) return '';
    return `<div style="border-top:1px dotted #999;padding-top:5px;margin-top:5px;">${rows.join('')}</div>`;
  }

  static buildRoundResultEffectDataFromEntry(side, entry) {
    const services = getMassBattleServices();
    const rulesEngine = services?.rulesEngine || MassBattleRulesEngine;
    const presenter = services?.roundResultPresenter || new RoundResultPresenter({ rulesEngine });
    return presenter.buildRoundResultEffectDataFromEntry(side, entry);
  }

  static updateForceTokens(html, side, size) {
    html = $(html);
    const tokenContainer = UIHelper.forceTokens(html, side);
    tokenContainer.empty();

    const tokenImage = side === 'player'
      ? 'modules/swade-mass-battles/images/BattleForceTokenGood.png'
      : 'modules/swade-mass-battles/images/BattleForceTokenEvil.png';

    for (let index = 0; index < size; index += 1) {
      tokenContainer.append(`<img class="force-token-item" src="${tokenImage}" style="width: 32px; height: 32px; border: none;"/>`);
    }
  }

  static async updateForceEffects(html, playerSize, enemySize) {
    html = $(html);
    UIHelper.forceEffect(html, 'player').empty();
    UIHelper.forceEffect(html, 'enemy').empty();

    const template = await getTemplate('modules/swade-mass-battles/hbs/partials/effect-card.hbs');
    const renderForceCard = (side, tokenImage, bonus) => {
      const effectHtml = template({
        cardClass: 'force-effect-card',
        compactClass: 'force-compact',
        expandedClass: 'force-expanded',
        hasButtons: false,
        isForceEffect: true,
        side,
        title: 'Forces Bonus',
        description: 'The forces on this side outnumber the other side.',
        hasEffects: true,
        tokenImage,
        sameSideEffects: [{ text: `+${bonus} Battle`, textCompact: `+${bonus} Bat.` }],
        modifierStickers: MassBattlesHUD.buildModifierStickers(side, { battleModifierSameSide: bonus })
      });

      UIHelper.forceEffect(html, side).html(effectHtml);
      UIHelper.forceCompactInSide(html, side).on('click', function() {
        $(this).siblings('.force-expanded').slideToggle(200);
      });
    };

    const diff = playerSize - enemySize;
    if (diff > 0) {
      renderForceCard('player', 'modules/swade-mass-battles/images/BattleForceTokenGood.png', diff);
    } else if (diff < 0) {
      renderForceCard('enemy', 'modules/swade-mass-battles/images/BattleForceTokenEvil.png', Math.abs(diff));
    }
  }

  static DEFAULT_OPTIONS = {
    window: { frame: false, positioned: false },
    classes: ['mass-battles-hud']
  };

  static PARTS = {
    content: { template: 'modules/swade-mass-battles/hbs/swade-mass-battles-hud.hbs' }
  };

  constructor(side = 'player', options = {}) {
    super(Object.assign({ id: `mass-battles-hud-${side}` }, options));
    this.side = side;
  }

  async refreshBattlemasterDisplays(side) {
    await BattlemasterSectionController.refreshDisplays({ state, side });
  }
  
  async _prepareContext(options) {
    const services = getMassBattleServices();
    const rulesEngine = services?.rulesEngine || MassBattleRulesEngine;
    return HudContextBuilder.build({
      side: this.side,
      buildModifierStickers: MassBattlesHUD.buildModifierStickers,
      rulesEngine,
      roundResultPresenter: services?.roundResultPresenter || new RoundResultPresenter({ rulesEngine })
    });
  }

  getHudPositionSettingKey() {
    return this.side === 'enemy' ? ENEMY_HUD_POSITION_SETTING : PLAYER_HUD_POSITION_SETTING;
  }

  getHudPositionSettingValue() {
    const key = this.getHudPositionSettingKey();
    const raw = game.settings.get('swade-mass-battles', key);
    return raw && typeof raw === 'object' ? raw : {};
  }

  applySavedHudPosition() {
    const position = this.getHudPositionSettingValue();
    const root = document.documentElement;

    if (this.side === 'enemy') {
      if (Number.isFinite(position?.top)) {
        root.style.setProperty('--swade-enemy-hud-top-user', `${Math.round(position.top)}px`);
      } else {
        root.style.removeProperty('--swade-enemy-hud-top-user');
      }

      if (Number.isFinite(position?.right)) {
        root.style.setProperty('--swade-enemy-hud-right-user', `${Math.round(position.right)}px`);
      } else {
        root.style.removeProperty('--swade-enemy-hud-right-user');
      }
      return;
    }

    if (Number.isFinite(position?.top)) {
      root.style.setProperty('--swade-player-hud-top-user', `${Math.round(position.top)}px`);
    } else {
      root.style.removeProperty('--swade-player-hud-top-user');
    }

    if (Number.isFinite(position?.left)) {
      root.style.setProperty('--swade-player-hud-left-user', `${Math.round(position.left)}px`);
    } else {
      root.style.removeProperty('--swade-player-hud-left-user');
    }
  }

  async saveHudPosition(position) {
    const key = this.getHudPositionSettingKey();
    const payload = this.side === 'enemy'
      ? {
          top: Number.isFinite(position?.top) ? Math.round(position.top) : null,
          right: Number.isFinite(position?.right) ? Math.round(position.right) : null
        }
      : {
          top: Number.isFinite(position?.top) ? Math.round(position.top) : null,
          left: Number.isFinite(position?.left) ? Math.round(position.left) : null
        };

    await game.settings.set('swade-mass-battles', key, payload);
  }

  enableHudDragging(html) {
    const rootElem = this.element;
    if (!rootElem) return;

    const dragHandle = UIHelper.hudDragHandle(html).first();
    if (!dragHandle.length) return;

    dragHandle.off('mousedown.hudDrag').on('mousedown.hudDrag', (event) => {
      if (event.button !== 0) return;
      event.preventDefault();

      const rect = rootElem.getBoundingClientRect();
      const startMouseX = event.clientX;
      const startMouseY = event.clientY;
      const startTop = rect.top;
      const startLeft = rect.left;
      const startRight = Math.max(0, window.innerWidth - rect.right);
      const maxTop = Math.max(0, window.innerHeight - rect.height);
      const maxHorizontal = Math.max(0, window.innerWidth - rect.width);

      const onMouseMove = (moveEvent) => {
        const deltaX = moveEvent.clientX - startMouseX;
        const deltaY = moveEvent.clientY - startMouseY;

        const top = Math.min(maxTop, Math.max(0, startTop + deltaY));
        const clampedLeft = Math.min(maxHorizontal, Math.max(0, startLeft + deltaX));
        const clampedRight = Math.min(maxHorizontal, Math.max(0, startRight - deltaX));

        if (this.side === 'enemy') {
          document.documentElement.style.setProperty('--swade-enemy-hud-top-user', `${Math.round(top)}px`);
          document.documentElement.style.setProperty('--swade-enemy-hud-right-user', `${Math.round(clampedRight)}px`);
        } else {
          document.documentElement.style.setProperty('--swade-player-hud-top-user', `${Math.round(top)}px`);
          document.documentElement.style.setProperty('--swade-player-hud-left-user', `${Math.round(clampedLeft)}px`);
        }
      };

      const onMouseUp = async (upEvent) => {
        const deltaX = upEvent.clientX - startMouseX;
        const deltaY = upEvent.clientY - startMouseY;
        const top = Math.min(maxTop, Math.max(0, startTop + deltaY));
        const left = Math.min(maxHorizontal, Math.max(0, startLeft + deltaX));
        const right = Math.min(maxHorizontal, Math.max(0, startRight - deltaX));

        window.removeEventListener('mousemove', onMouseMove);
        window.removeEventListener('mouseup', onMouseUp);

        if (this.side === 'enemy') {
          await this.saveHudPosition({ top, right });
          return;
        }

        await this.saveHudPosition({ top, left });
      };

      window.addEventListener('mousemove', onMouseMove);
      window.addEventListener('mouseup', onMouseUp);
    });
  }
  
  async _onRender(context, options) {
    await super._onRender(context, options);
    const html = $(this.element);
    await HudInteractionController.onRender({
      hud: this,
      html,
      getMassBattleHUDManager,
      state,
      sendBattleDataUpdate
    });
  }
  
  async updateBattlemasterDisplay(html, side) {
    await BattlemasterSectionController.updateDisplay({
      html,
      side,
      sendBattleDataUpdate,
      onRefreshDisplays: async (changedSide) => this.refreshBattlemasterDisplays(changedSide),
      onRollBattle: async (actor, changedSide) => this.rollBattle(actor, changedSide),
      onRollMorale: async (actor, changedSide) => this.rollMorale(actor, changedSide)
    });
  }
  
  async loadAdvantages(html, side, advantages) {
    await AdvantagesSectionController.load({
      html,
      side,
      advantages,
      prepareEffectData: MassBattlesHUD.prepareEffectData,
      onEditAdvantage: async (buttonSide, buttonIndex) => this.showEditAdvantageHUD(buttonSide, buttonIndex),
      onRemoveAdvantage: async (buttonSide, buttonIndex) => this.removeAdvantageHUD(buttonSide, buttonIndex)
    });
  }
  
  async loadTroops(html, side, troops) {
    await TroopsSectionController.load({
      html,
      side,
      troops,
      prepareEffectData: MassBattlesHUD.prepareEffectData,
      onShowTroopStatusDialog: async (buttonSide, buttonIndex) => this.showTroopStatusDialogHUD(buttonSide, buttonIndex),
      onRemoveTroop: async (buttonSide, buttonIndex) => this.removeTroopHUD(buttonSide, buttonIndex)
    });
  }
  
  async updateBattlemasterButtons(html, side) {
    html = $(html);
    // Calculate modifiers
    const modifiers = MassBattlesHUD.calculateModifiers(side);
    const battleModText = modifiers.battle >= 0 ? `+${modifiers.battle}` : `${modifiers.battle}`;
    const moraleModText = modifiers.morale >= 0 ? `+${modifiers.morale}` : `${modifiers.morale}`;
    
    // Update modifier spans only, not the entire button
    const $battleModifier = UIHelper.totalModifier(html, side);
    const $moraleModifier = UIHelper.moraleModifier(html, side);
    
    if ($battleModifier.length) {
      $battleModifier.text(battleModText);
    }
    if ($moraleModifier.length) {
      $moraleModifier.text(moraleModText);
    }
  }
  
  async rollBattle(actor, side) {
    const services = getMassBattleServices();
    const rulesEngine = services?.rulesEngine || MassBattleRulesEngine;
    const rollService = services?.rollService || new MassBattleRollService({ rulesEngine });
    await rollService.rollBattle(actor, side);
  }
  
  async rollMorale(actor, side) {
    const services = getMassBattleServices();
    const rulesEngine = services?.rulesEngine || MassBattleRulesEngine;
    const rollService = services?.rollService || new MassBattleRollService({ rulesEngine });
    await rollService.rollMorale(actor, side);
  }
  
  async showEditAdvantageHUD(side, index) {
    await HudMutationController.showEditAdvantageHUD({
      side,
      index,
      state
    });
  }
  
  async removeAdvantageHUD(side, index) {
    await HudMutationController.removeAdvantageHUD({
      side,
      index,
      state,
      sendBattleDataUpdate
    });
  }
  
  async showTroopStatusDialogHUD(side, index) {
    await HudMutationController.showTroopStatusDialogHUD({
      side,
      index,
      state
    });
  }
  
  async removeTroopHUD(side, index) {
    await HudMutationController.removeTroopHUD({
      side,
      index,
      state,
      sendBattleDataUpdate
    });
  }
}
