/**
 * SWADE Battles Module
 * A module for enhanced combat and battles in SWADE
 */

import { Hooker } from './classes/Hooker.js';

Hooker.hookEmUp();





