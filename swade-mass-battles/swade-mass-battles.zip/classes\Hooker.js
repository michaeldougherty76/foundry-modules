import { SwadeMassBattleModule } from './SwadeMassBattleModule.js';
import { ChatMessageStream } from './ChatMessageStream.js';

export class Hooker {
  static areMassBattleHUDsOpen() {
    return SwadeMassBattleModule.getMassBattleHUD().isOpen();
  }

  static hookEmUp() {
    Hooks.on('init', async function() {
      await SwadeMassBattleModule.initialize();
    });

    Hooks.on('createChatMessage', ChatMessageStream.handleCreateChatMessage);

    Hooks.on('ready', async function() {
      await SwadeMassBattleModule.ready();
    });

    Hooks.on('renderSceneControls', () => {
      SwadeMassBattleModule.getMassBattleHUD().updateHudAnchorPositions();
    });

    Hooks.on('collapseSidebar', () => {
      SwadeMassBattleModule.getMassBattleHUD().scheduleEnemyHudAnchorUpdate();
    });

    Hooks.on('renderSidebar', () => {
      SwadeMassBattleModule.getMassBattleHUD().scheduleEnemyHudAnchorUpdate();
    });

    Hooks.on('changeSidebarTab', () => {
      SwadeMassBattleModule.getMassBattleHUD().scheduleEnemyHudAnchorUpdate();
    });
  }
}