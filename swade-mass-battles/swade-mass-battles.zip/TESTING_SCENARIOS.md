# SWADE Mass Battles Test Scenarios

## Purpose
This checklist covers manual testing scenarios to verify core functionality, regressions, and multiplayer behavior for the SWADE Mass Battles module.

## Suggested Test Matrix
Run the scenarios in these environments when possible.

- [ ] GM only, socketlib installed
- [ ] GM + 1 Player, socketlib installed
- [ ] GM + 1 Player, socketlib disabled or unavailable
- [ ] Fresh world with no prior battle data
- [ ] Existing world with previously saved battle data

## Preconditions and Fixtures
- [ ] Module enabled and active in world
- [ ] SWADE system enabled
- [ ] At least 4 actors available for battlemaster and troop assignment
- [ ] At least one actor has Battle skill
- [ ] At least one actor has Spirit attribute available for morale roll
- [ ] Optional RollTable configured for Mass Battle Results Table setting
- [ ] Optional troop statuses configured in troop status menu

## 1. Module Initialization and Registration
- [ ] World starts with no console errors from init or ready hooks
- [ ] Module settings appear and are readable/writable
- [ ] Keybinding to toggle HUD appears and works
- [ ] Legacy keybinding still works without conflict
- [ ] HUD templates/partials load without missing-template errors
- [ ] API object is present on game.modules module entry

## 2. HUD Lifecycle and Layout
- [ ] HUD opens via keybinding
- [ ] HUD closes and reopens without duplicated controls
- [ ] Player HUD, Enemy HUD, and Workflow HUD render consistently
- [ ] HUD position persists after close and reopen
- [ ] HUD position persists after page refresh
- [ ] Sidebar collapse/expand does not break anchor positions
- [ ] Window resize keeps HUDs visible and anchored

## 3. Permissions and Role Gating
- [ ] GM can open/close and fully interact with workflow
- [ ] Non-GM can view appropriate read-only states
- [ ] Non-GM cannot mutate workflow stage or battle data directly
- [ ] Non-GM receives synchronized updates from GM

## 4. Workflow Stage Navigation
- [ ] Stage 0 through Stage 4 buttons update current stage correctly
- [ ] Stage-specific instructions update correctly
- [ ] Stage-specific CSS classes toggle correctly on both HUDs
- [ ] Switching stages does not clear unrelated persisted data

## 5. Setup Stage: Battlemaster Assignment
- [ ] Drag/drop actor into player battlemaster zone assigns correctly
- [ ] Drag/drop actor into enemy battlemaster zone assigns correctly
- [ ] Battlemaster display shows actor image and name
- [ ] Remove battlemaster button clears only selected side
- [ ] Battle roll button appears with correct die and modifier text
- [ ] Morale roll button appears with correct die and modifier text

## 6. Tactical Advantages Stage
- [ ] Add advantage creates card on correct side
- [ ] Edit advantage updates existing card
- [ ] Remove advantage deletes only selected card
- [ ] Legacy advantage data format still renders correctly
- [ ] Advantage compact/expanded card toggle behaves correctly
- [ ] Modifier effects are reflected in battlemaster modifiers

## 7. Troop Actions Stage
- [ ] Drag/drop troop actor adds troop to correct side list
- [ ] Troop card renders compact and expanded sections correctly
- [ ] Troop status dialog opens and saves selection
- [ ] Remove troop deletes only selected troop
- [ ] Did not participate status styling appears where expected
- [ ] Troop effects update battle/morale modifiers correctly

## 8. Force Size and Force Effects
- [ ] Increase force size updates numeric display
- [ ] Decrease force size does not go below zero
- [ ] Force token icons update for both sides
- [ ] Force advantage effect card appears on side with greater force
- [ ] Force effect card disappears when force sizes become equal
- [ ] Modifier updates propagate to battlemaster roll buttons

## 9. Battle Rolls Stage (Workflow Stage 3)
- [ ] Battlemaster Battle roll chat messages are detected
- [ ] Pending battle roll queue populates for correct side
- [ ] Duplicate message IDs are not added twice
- [ ] Accept pending battle roll applies total and successes correctly
- [ ] Round outcome summary updates after both sides have totals
- [ ] Round result history entries are created for both sides
- [ ] Differential logic produces correct win/tie/marginal/victory labels

## 10. Morale Checks Stage (Workflow Stage 4)
- [ ] Morale required state appears only when side lost tokens
- [ ] Battlemaster Spirit/morale chat messages are detected
- [ ] Pending morale roll queue populates for correct side
- [ ] Accept pending morale roll stores correct value
- [ ] Morale outcome text/class shows pass/fail correctly
- [ ] Duplicate morale message IDs are not added twice

## 11. Round Advancement and Round Reset
- [ ] Advance to next round increments round number
- [ ] Advance resets workflow stage to setup
- [ ] Advance clears pending battle and morale queues
- [ ] Advance clears current round stored battle/morale totals
- [ ] Advance resets troop statuses to Did not participate
- [ ] Advance preserves historical round-result cards as designed
- [ ] Reset round sets round number to 1
- [ ] Reset round clears battle/morale totals and pending queues
- [ ] Reset round clears round result history for both sides
- [ ] Reset round clears round result underlay cards from both HUDs

## 12. Chat Message Stream Handling
- [ ] Battle message detection excludes morale/spirit messages
- [ ] Morale message detection includes morale and spirit text
- [ ] Total extraction works from message.rolls
- [ ] Total extraction works from message.roll.total fallback
- [ ] Total extraction works from rendered HTML total fallback
- [ ] Side resolution works for speaker actor and token actor
- [ ] Unrelated chat messages do not mutate battle data

## 13. Round Result Presentation and History
- [ ] Round result cards render for current round
- [ ] Round result history cards render in chronological order
- [ ] Token delta stickers match stored token flow
- [ ] Descriptor text renders when present
- [ ] Descriptor fallback generation is correct when missing
- [ ] Expand/collapse interaction works for round result cards

## 14. Socket Sync and Multiplayer Consistency
- [ ] GM refresh sync button pushes latest battle data
- [ ] GM refresh sync button updates round result underlays on clients
- [ ] Workflow HUD rerenders after sync where expected
- [ ] With socketlib unavailable, local-only warning appears
- [ ] With socketlib available, success info notification appears
- [ ] Player clients receive and display new stage and card updates

## 15. Persistence and Reload Behavior
- [ ] Battle data persists across full browser reload
- [ ] HUD state remains consistent after reload
- [ ] Stored battlemaster UUIDs rehydrate displays correctly
- [ ] Stored troops and statuses rehydrate correctly
- [ ] Stored round history rehydrates correctly

## 16. Settings and Configuration
- [ ] Troop statuses menu opens and saves data
- [ ] Changes in troop statuses affect new and existing troop cards correctly
- [ ] Mass Battle Results Table setting lists available tables
- [ ] Rolling results table without setting shows warning
- [ ] Rolling results table with missing UUID shows warning

## 17. Negative and Edge Cases
- [ ] Battlemaster actor missing Battle skill shows warning on battle roll
- [ ] Invalid or deleted UUIDs fail gracefully without crashes
- [ ] Empty troop lists render without errors
- [ ] Empty advantages lists render without errors
- [ ] Rapid repeated button clicks do not duplicate or corrupt state
- [ ] Stage changes during pending queues do not create invalid states

## 18. UI and Accessibility Sanity Checks
- [ ] Buttons are visually distinguishable and clickable
- [ ] Text remains readable at common Foundry UI scales
- [ ] Images/icons load correctly and have sensible fallback behavior
- [ ] No major layout overlap between player and enemy HUD panes

## 19. Regression Smoke Suite
Run this as a fast confidence pass after any refactor.

- [ ] Open HUD
- [ ] Assign both battlemasters
- [ ] Add one advantage per side
- [ ] Add one troop per side and set non-default status
- [ ] Progress to battle stage and accept one battle roll per side
- [ ] Progress to morale stage and accept one morale roll where required
- [ ] Advance round and verify reset behavior
- [ ] Reset round and verify history clear behavior
- [ ] Confirm no console errors throughout

## Notes Section
Use this section during test runs.

- Date:
- Build/Commit:
- Environment:
- Tester:
- Failed scenarios:
- Follow-up issues:
