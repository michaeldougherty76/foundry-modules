import { UIHelper } from './UIHelper.js';
import { MassBattlesHUD } from '../MassBattlesHUD.js';
import { SocketHelper } from './SocketHelper.js';

const { DialogV2 } = foundry.applications.api;

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function normalizeAdvantage(advantage) {
  return {
    result: String(advantage?.result || 'Tactical Advantage'),
    resultDescription: String(advantage?.resultDescription || ''),
    battleModifierSameSide: Number.parseInt(advantage?.battleModifierSameSide, 10) || 0,
    battleModifierOppositeSide: Number.parseInt(advantage?.battleModifierOppositeSide, 10) || 0,
    moraleModifierSameSide: Number.parseInt(advantage?.moraleModifierSameSide, 10) || 0,
    moraleModifierOppositeSide: Number.parseInt(advantage?.moraleModifierOppositeSide, 10) || 0,
    forceTokenModifierSameSide: Number.parseInt(advantage?.forceTokenModifierSameSide, 10) || 0,
    forceTokenModifierOppositeSide: Number.parseInt(advantage?.forceTokenModifierOppositeSide, 10) || 0,
    suffersFatigue: Number.parseInt(advantage?.suffersFatigue, 10) || 0,
    suffersWound: Number.parseInt(advantage?.suffersWound, 10) || 0,
    effectType: 'Tactical Advantage Effects'
  };
}

function parseAdvantageFromDialog(html) {
  html = $(html);
  return normalizeAdvantage({
    result: UIHelper.find(html, '#advantage-name').val().trim() || 'Tactical Advantage',
    resultDescription: UIHelper.find(html, '#advantage-description').val().trim(),
    battleModifierSameSide: UIHelper.find(html, '#battle-same').val(),
    battleModifierOppositeSide: UIHelper.find(html, '#battle-opposite').val(),
    moraleModifierSameSide: UIHelper.find(html, '#morale-same').val(),
    moraleModifierOppositeSide: UIHelper.find(html, '#morale-opposite').val(),
    forceTokenModifierSameSide: UIHelper.find(html, '#force-same').val(),
    forceTokenModifierOppositeSide: UIHelper.find(html, '#force-opposite').val(),
    suffersFatigue: UIHelper.find(html, '#suffers-fatigue').val(),
    suffersWound: UIHelper.find(html, '#suffers-wound').val()
  });
}

function buildAdvantageDialogContent(advantage) {
  const safeResult = escapeHtml(advantage.result);
  const safeDescription = escapeHtml(advantage.resultDescription);

  return `
    <form style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
      <div style="grid-column: 1 / -1;">
        <label>Name:</label>
        <input type="text" id="advantage-name" style="width: 100%;" placeholder="e.g., High Ground" value="${safeResult}"/>
      </div>
      <div style="grid-column: 1 / -1;">
        <label>Description:</label>
        <input type="text" id="advantage-description" style="width: 100%;" placeholder="Optional description" value="${safeDescription}"/>
      </div>
      <div style="grid-column: 1 / -1; font-weight: bold; border-bottom: 1px solid #999; padding-bottom: 5px;">Same Side Effects</div>
      <div>
        <label>Battle Modifier:</label>
        <input type="number" id="battle-same" style="width: 100%;" value="${advantage.battleModifierSameSide}"/>
      </div>
      <div>
        <label>Morale Modifier:</label>
        <input type="number" id="morale-same" style="width: 100%;" value="${advantage.moraleModifierSameSide}"/>
      </div>
      <div style="grid-column: 1 / -1;">
        <label>Force Token Modifier:</label>
        <input type="number" id="force-same" style="width: 100%;" value="${advantage.forceTokenModifierSameSide}"/>
      </div>
      <div style="grid-column: 1 / -1; font-weight: bold; border-bottom: 1px solid #999; padding-bottom: 5px; margin-top: 10px;">Opposite Side Effects</div>
      <div>
        <label>Battle Modifier:</label>
        <input type="number" id="battle-opposite" style="width: 100%;" value="${advantage.battleModifierOppositeSide}"/>
      </div>
      <div>
        <label>Morale Modifier:</label>
        <input type="number" id="morale-opposite" style="width: 100%;" value="${advantage.moraleModifierOppositeSide}"/>
      </div>
      <div style="grid-column: 1 / -1;">
        <label>Force Token Modifier:</label>
        <input type="number" id="force-opposite" style="width: 100%;" value="${advantage.forceTokenModifierOppositeSide}"/>
      </div>
      <div style="grid-column: 1 / -1; font-weight: bold; border-bottom: 1px solid #999; padding-bottom: 5px; margin-top: 10px;">Character Effects</div>
      <div>
        <label>Suffers Fatigue:</label>
        <input type="number" id="suffers-fatigue" style="width: 100%;" min="0" value="${advantage.suffersFatigue || 0}"/>
      </div>
      <div>
        <label>Suffers Wound:</label>
        <input type="number" id="suffers-wound" style="width: 100%;" min="0" value="${advantage.suffersWound || 0}"/>
      </div>
      </form>
  `;
}

export class DialogHelper {
  static async sendBattleDataUpdate(battleData) {
    await SocketHelper.sendBattleDataUpdate(battleData);
  }

  static buildStatusEffectsHtml(side, status) {
    return MassBattlesHUD.buildStatusEffectsHtml(side, status);
  }

  static async showAddAdvantageDialog(side, onSaved = null) {
    const content = buildAdvantageDialogContent(normalizeAdvantage({ result: 'Tactical Advantage' }));

    await DialogV2.wait({
      window: { title: 'Add Tactical Advantage' },
      content,
      position: { width: 500 },
      buttons: [
        {
          action: 'add',
          label: 'Add',
          default: true,
          callback: async (_event, _button, dialog) => {
            const battleData = game.settings.get('swade-mass-battles', 'battleData');
            const advantages = side === 'player' ? (battleData.playerAdvantages || []) : (battleData.enemyAdvantages || []);
            advantages.push(parseAdvantageFromDialog(dialog.element));

            if (side === 'player') {
              battleData.playerAdvantages = advantages;
            } else {
              battleData.enemyAdvantages = advantages;
            }

            await DialogHelper.sendBattleDataUpdate(battleData);
            if (typeof onSaved === 'function') {
              await onSaved(battleData);
            }
          }
        },
        {
          action: 'cancel',
          label: 'Cancel'
        }
      ]
    });
  }

  static async showEditAdvantageDialog(side, index, onSaved = null) {
    const battleData = game.settings.get('swade-mass-battles', 'battleData');
    const advantages = side === 'player' ? (battleData.playerAdvantages || []) : (battleData.enemyAdvantages || []);
    const adv = advantages[index];

    const advantage = (typeof adv === 'object' && adv?.result)
      ? normalizeAdvantage(adv)
      : normalizeAdvantage({
        result: adv?.description || 'Tactical Advantage',
        battleModifierSameSide: adv?.modifier || 0
      });

    await DialogV2.wait({
      window: { title: 'Edit Tactical Advantage' },
      content: buildAdvantageDialogContent(advantage),
      position: { width: 500 },
      buttons: [
        {
          action: 'save',
          label: 'Save',
          default: true,
          callback: async (_event, _button, dialog) => {
            advantages[index] = parseAdvantageFromDialog(dialog.element);

            if (side === 'player') {
              battleData.playerAdvantages = advantages;
            } else {
              battleData.enemyAdvantages = advantages;
            }

            await DialogHelper.sendBattleDataUpdate(battleData);
            if (typeof onSaved === 'function') {
              await onSaved(battleData);
            }
          }
        },
        {
          action: 'cancel',
          label: 'Cancel'
        }
      ]
    });
  }

  static async showTroopStatusDialog(side, index, onSaved = null) {
    const battleData = game.settings.get('swade-mass-battles', 'battleData');
    const troops = side === 'player' ? (battleData.playerTroops || []) : (battleData.enemyTroops || []);
    const troop = troops[index];
    const troopStatuses = game.settings.get('swade-mass-battles', 'troopStatuses');

    const actorUuid = typeof troop === 'string' ? troop : troop?.uuid;
    const currentStatus = typeof troop === 'object' ? (troop?.status || 'Did not participate') : 'Did not participate';

    const actor = actorUuid ? await fromUuid(actorUuid) : null;
    if (!actor) return;

    const defaultStatus = {
      result: 'Did not participate',
      resultDescription: 'The character did not participate directly in this Mass Battle this round.',
      battleModifierSameSide: 0,
      battleModifierOppositeSide: 0,
      moraleModifierSameSide: 0,
      moraleModifierOppositeSide: 0,
      forceTokenModifierSameSide: 0,
      forceTokenModifierOppositeSide: 0,
      suffersFatigue: 0,
      suffersWound: 0
    };

    let optionsHtml = '';
    optionsHtml += `<option value="Did not participate" ${currentStatus === 'Did not participate' ? 'selected' : ''}>Did not participate</option>`;

    troopStatuses.forEach((status) => {
      if (status.result !== 'Did not participate') {
        const selected = status.result === currentStatus ? 'selected' : '';
        optionsHtml += `<option value="${escapeHtml(status.result)}" ${selected}>${escapeHtml(status.result)}</option>`;
      }
    });

    let initialStatus = troopStatuses.find((status) => status.result === currentStatus);
    if (!initialStatus && currentStatus === 'Did not participate') {
      initialStatus = defaultStatus;
    }

    const initialDescription = escapeHtml(initialStatus?.resultDescription || '');
    const initialEffectsHtml = DialogHelper.buildStatusEffectsHtml(side, initialStatus);
    await DialogV2.wait({
      window: { title: 'Change Troop Status' },
      content: `
        <div>
          <p><strong>Character:</strong> ${escapeHtml(actor.name)}</p>
          <div style="margin-top: 10px;">
            <label>Status:</label>
            <select id="troop-status" style="width: 100%; padding: 5px;">${optionsHtml}</select>
          </div>
          <div style="margin-top: 10px;">
            <div class="status-description" style="font-style: italic; color: #666; font-size: 0.9em; min-height: 1.5em; line-height: 1.4;">${initialDescription}</div>
            <div class="status-effects-container">${initialEffectsHtml}</div>
          </div>
        </div>
      `,
      position: {
        width: 400,
        height: 'auto'
      },
      buttons: [
        {
          action: 'save',
          label: 'Save',
          default: true,
          callback: async (_event, _button, dialog) => {
            const html = $(dialog.element);
            const newStatus = UIHelper.find(html, '#troop-status').val();
            troops[index] = {
              uuid: actorUuid,
              status: newStatus
            };

            if (side === 'player') {
              battleData.playerTroops = troops;
            } else {
              battleData.enemyTroops = troops;
            }

            await DialogHelper.sendBattleDataUpdate(battleData);
            if (typeof onSaved === 'function') {
              await onSaved({ battleData, side, troops });
            }
          }
        },
        {
          action: 'cancel',
          label: 'Cancel'
        }
      ],
      render: (_event, dialogRef) => {
        const html = $(dialogRef.element);
        const statusSelect = UIHelper.find(html, '#troop-status');
        const statusDesc = UIHelper.statusDescription(html);

        statusSelect.on('change', function() {
          const selectedValue = $(this).val();
          let selectedStatus = troopStatuses.find((status) => status.result === selectedValue);

          if (!selectedStatus && selectedValue === 'Did not participate') {
            selectedStatus = defaultStatus;
          }

          if (!selectedStatus) return;
          statusDesc.text(selectedStatus.resultDescription);
          UIHelper.statusEffectsContainer(html).html(DialogHelper.buildStatusEffectsHtml(side, selectedStatus));

          requestAnimationFrame(() => {
            dialogRef.setPosition({ height: 'auto' });
          });
        });
      }
    });
  }
}