import { UIHelper } from './helpers/UIHelper.js';

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

/**
 * Configuration form for Troop Statuses
 */
export class TroopStatusesConfig extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: 'troop-statuses-config',
    tag: 'form',
    window: {
      title: 'Configure Troop Statuses',
      resizable: true
    },
    position: {
      width: 800
    },
    form: {
      handler: async function(event, form, formData) {
        await this._handleSubmit(event, form, formData);
      },
      closeOnSubmit: true
    }
  };

  static PARTS = {
    content: { template: 'modules/swade-mass-battles/hbs/troop-statuses-config.hbs' }
  };

  async _prepareContext(options) {
    const statuses = game.settings.get('swade-mass-battles', 'troopStatuses');
    return { statuses };
  }

  async _onRender(context, options) {
    await super._onRender(context, options);
    const html = $(this.element);

    UIHelper.addStatusButtons(html).on('click', () => {
      const statuses = game.settings.get('swade-mass-battles', 'troopStatuses');
      statuses.push({
        result: 'New Status',
        resultDescription: '',
        battleModifierSameSide: 0,
        battleModifierOppositeSide: 0,
        moraleModifierSameSide: 0,
        moraleModifierOppositeSide: 0,
        forceTokenModifierSameSide: 0,
        forceTokenModifierOppositeSide: 0,
        suffersFatigue: 0,
        suffersWound: 0,
      });
      game.settings.set('swade-mass-battles', 'troopStatuses', statuses);
      this.render();
    });

    UIHelper.deleteStatusButtons(html).on('click', (event) => {
      const index = parseInt(event.currentTarget.dataset.index);
      const statuses = game.settings.get('swade-mass-battles', 'troopStatuses');
      statuses.splice(index, 1);
      game.settings.set('swade-mass-battles', 'troopStatuses', statuses);
      this.render();
    });
  }

  async _handleSubmit(event, form, formData) {
    const statuses = [];
    const expanded = foundry.utils.expandObject(formData.object);

    if (expanded.statuses) {
      for (let key in expanded.statuses) {
        const status = expanded.statuses[key];
        statuses.push({
          result: status.result || 'Unnamed',
          resultDescription: status.resultDescription || '',
          battleModifierSameSide: parseInt(status.battleModifierSameSide) || 0,
          battleModifierOppositeSide: parseInt(status.battleModifierOppositeSide) || 0,
          moraleModifierSameSide: parseInt(status.moraleModifierSameSide) || 0,
          moraleModifierOppositeSide: parseInt(status.moraleModifierOppositeSide) || 0,
          forceTokenModifierSameSide: parseInt(status.forceTokenModifierSameSide) || 0,
          forceTokenModifierOppositeSide: parseInt(status.forceTokenModifierOppositeSide) || 0,
          suffersFatigue: parseInt(status.suffersFatigue) || 0,
          suffersWound: parseInt(status.suffersWound) || 0,
        });
      }
    }

    await game.settings.set('swade-mass-battles', 'troopStatuses', statuses);
    ui.notifications.info('Troop statuses updated successfully');
  }
}
