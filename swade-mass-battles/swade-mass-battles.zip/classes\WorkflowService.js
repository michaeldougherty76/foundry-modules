import { MassBattleRulesEngine } from './MassBattleRulesEngine.js';
import { SocketHelper } from './helpers/SocketHelper.js';

export class WorkflowService {
  constructor({ rulesEngine = MassBattleRulesEngine, socketHelper = SocketHelper } = {}) {
    this.rulesEngine = rulesEngine;
    this.socketHelper = socketHelper;
  }

  getActorTokenImage(actor) {
    return actor?.prototypeToken?.texture?.src || actor?.img || 'icons/svg/mystery-man.svg';
  }

  getPendingBattleRollsKey(side) {
    return side === 'player' ? 'playerPendingBattleRolls' : 'enemyPendingBattleRolls';
  }

  getPendingMoraleRollsKey(side) {
    return side === 'player' ? 'playerPendingMoraleRolls' : 'enemyPendingMoraleRolls';
  }

  getPendingBattleRollsForSide(battleData, side) {
    const key = this.getPendingBattleRollsKey(side);
    const list = Array.isArray(battleData?.[key]) ? battleData[key] : [];
    return list
      .filter((entry) => Number.isFinite(entry?.total))
      .map((entry, index) => {
        const total = Number(entry.total);
        const successes = Number.isFinite(entry.successes) ? Number(entry.successes) : Math.max(0, Math.floor(total / 4));
        return {
          id: entry.id || `${side}-pending-${index}`,
          messageId: entry.messageId || null,
          total,
          successes,
          flavor: String(entry.flavor || '').trim(),
          createdAt: Number.isFinite(entry.createdAt) ? Number(entry.createdAt) : 0
        };
      })
      .sort((a, b) => b.createdAt - a.createdAt);
  }

  getPendingMoraleRollsForSide(battleData, side) {
    const key = this.getPendingMoraleRollsKey(side);
    const list = Array.isArray(battleData?.[key]) ? battleData[key] : [];
    return list
      .filter((entry) => Number.isFinite(entry?.total))
      .map((entry, index) => ({
        id: entry.id || `${side}-morale-pending-${index}`,
        messageId: entry.messageId || null,
        total: Number(entry.total),
        flavor: String(entry.flavor || '').trim(),
        createdAt: Number.isFinite(entry.createdAt) ? Number(entry.createdAt) : 0
      }))
      .sort((a, b) => b.createdAt - a.createdAt);
  }

  sideNeedsMoraleCheck(battleData, side) {
    return this.rulesEngine.getRoundTokenFlowForSide(battleData, side).lossOccurred;
  }

  getMoraleCheckTotalKey(side) {
    return side === 'player' ? 'playerMoraleCheckTotal' : 'enemyMoraleCheckTotal';
  }

  getMoraleOutcomeData(total) {
    if (!Number.isFinite(total)) return null;
    if (Number(total) >= 4) {
      return {
        outcomeClass: 'workflow-morale-status workflow-morale-status--pass',
        outcomeText: 'Staying in the fight'
      };
    }

    return {
      outcomeClass: 'workflow-morale-status workflow-morale-status--fail',
      outcomeText: 'Fleeing the battle'
    };
  }

  async sendBattleDataUpdate(battleData) {
    await this.socketHelper.sendBattleDataUpdate(battleData);
  }

  async rollOnMassBattleResultsTable(side = null, index = null) {
    const tableUuid = game.settings.get('swade-mass-battles', 'massBattleResultsTable');
    if (!tableUuid) {
      ui.notifications.warn('No Mass Battle results table is configured in Module Settings.');
      return;
    }

    const table = await fromUuid(tableUuid);
    if (!table) {
      ui.notifications.warn('The configured Mass Battle results table could not be found.');
      return;
    }

    let actor = null;
    if (side !== null && index !== null) {
      const battleData = game.settings.get('swade-mass-battles', 'battleData');
      const troops = side === 'player' ? (battleData.playerTroops || []) : (battleData.enemyTroops || []);
      const troop = troops[index];
      const actorUuid = typeof troop === 'string' ? troop : troop?.uuid;
      actor = actorUuid ? await fromUuid(actorUuid) : null;
    }

    await table.draw();

    if (actor) {
      ui.notifications.info(`Rolled on ${table.name} for ${actor.name}.`);
    }
  }

  getRoundResultHistoryKey(side) {
    return side === 'player' ? 'playerRoundResultHistory' : 'enemyRoundResultHistory';
  }

  upsertRoundResultHistoryEntry(battleData, side, round, entryData) {
    const key = this.getRoundResultHistoryKey(side);
    const list = Array.isArray(battleData[key]) ? battleData[key].slice() : [];
    const index = list.findIndex((entry) => Number(entry?.round) === Number(round));
    const nextEntry = {
      round: Number(round),
      resultName: entryData.resultName,
      sideName: entryData.sideName,
      sideSuccesses: entryData.sideSuccesses,
      otherName: entryData.otherName,
      otherSuccesses: entryData.otherSuccesses,
      descriptor: entryData.descriptor,
      tokenNetDelta: Number.isFinite(Number(entryData.tokenNetDelta)) ? Number(entryData.tokenNetDelta) : 0,
      tokenLosses: Number.isFinite(Number(entryData.tokenLosses)) ? Math.max(0, Number(entryData.tokenLosses)) : 0,
      tokenGains: Number.isFinite(Number(entryData.tokenGains)) ? Math.max(0, Number(entryData.tokenGains)) : 0,
      tokenLossOccurred: Boolean(entryData.tokenLossOccurred)
    };

    if (index >= 0) {
      list[index] = nextEntry;
    } else {
      list.push(nextEntry);
    }

    list.sort((a, b) => a.round - b.round);
    battleData[key] = list;
  }

  async appendCurrentRoundResultHistoryIfReady(battleData) {
    const playerSuccesses = this.rulesEngine.getBattleRollSuccesses(battleData, 'player');
    const enemySuccesses = this.rulesEngine.getBattleRollSuccesses(battleData, 'enemy');
    if (!Number.isFinite(playerSuccesses) || !Number.isFinite(enemySuccesses)) return;

    const differential = playerSuccesses - enemySuccesses;
    const roundNumber = Number.isInteger(battleData?.battleRound) && battleData.battleRound > 0 ? battleData.battleRound : 1;
    const playerResultName = this.rulesEngine.getRoundResultNameForSide('player', differential);
    const enemyResultName = this.rulesEngine.getRoundResultNameForSide('enemy', differential);
    const playerTokenFlow = this.rulesEngine.getRoundTokenFlowForResult(battleData, 'player', playerResultName);
    const enemyTokenFlow = this.rulesEngine.getRoundTokenFlowForResult(battleData, 'enemy', enemyResultName);

    let playerName = 'Player Battlemaster';
    let enemyName = 'Enemy Battlemaster';

    const playerActor = battleData.playerBattleMaster ? await fromUuid(battleData.playerBattleMaster) : null;
    const enemyActor = battleData.enemyBattleMaster ? await fromUuid(battleData.enemyBattleMaster) : null;
    if (playerActor?.name) playerName = playerActor.name;
    if (enemyActor?.name) enemyName = enemyActor.name;

    this.upsertRoundResultHistoryEntry(battleData, 'player', roundNumber, {
      resultName: playerResultName,
      sideName: playerName,
      sideSuccesses: playerSuccesses,
      otherName: enemyName,
      otherSuccesses: enemySuccesses,
      tokenNetDelta: playerTokenFlow.netDelta,
      tokenLosses: playerTokenFlow.losses,
      tokenGains: playerTokenFlow.gains,
      tokenLossOccurred: playerTokenFlow.lossOccurred,
      descriptor: this.rulesEngine.buildRoundResultDescriptorFromParts(
        playerName,
        playerSuccesses,
        enemyName,
        enemySuccesses,
        playerResultName
      )
    });

    this.upsertRoundResultHistoryEntry(battleData, 'enemy', roundNumber, {
      resultName: enemyResultName,
      sideName: enemyName,
      sideSuccesses: enemySuccesses,
      otherName: playerName,
      otherSuccesses: playerSuccesses,
      tokenNetDelta: enemyTokenFlow.netDelta,
      tokenLosses: enemyTokenFlow.losses,
      tokenGains: enemyTokenFlow.gains,
      tokenLossOccurred: enemyTokenFlow.lossOccurred,
      descriptor: this.rulesEngine.buildRoundResultDescriptorFromParts(
        enemyName,
        enemySuccesses,
        playerName,
        playerSuccesses,
        enemyResultName
      )
    });
  }

  async syncRoundResultUnderlays(battleData) {
    await this.socketHelper.syncRoundResultUnderlays(battleData);
  }

  scheduleRoundResultUnderlaySync() {
    this.socketHelper.scheduleRoundResultUnderlaySync();
  }

  setPreserveRoundResultUnderlaysOnce(value) {
    if (value) this.socketHelper.markPreserveRoundResultUnderlaysOnce();
  }

  hasSocket() {
    return this.socketHelper.hasSocket();
  }
}