export class WorkflowHudAccessService {
  getMassBattleHUDManager() {
    return game.modules.get('swade-mass-battles')?.api?.massBattleHUD ?? null;
  }

  getPlayerHUD() {
    return this.getMassBattleHUDManager()?.getPlayerHUD?.() ?? null;
  }

  getEnemyHUD() {
    return this.getMassBattleHUDManager()?.getEnemyHUD?.() ?? null;
  }

  getWorkflowHUD() {
    return this.getMassBattleHUDManager()?.getWorkflowHUD?.() ?? null;
  }
}