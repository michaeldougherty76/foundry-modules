import { DialogHelper } from './helpers/DialogHelper.js';
import { UIHelper } from './helpers/UIHelper.js';

export class HudInteractionController {
  static async onRender({ hud, html, getMassBattleHUDManager, state, sendBattleDataUpdate }) {
    hud.applySavedHudPosition();
    hud.enableHudDragging(html);

    // Round-result cards are injected dynamically; delegate toggle handling from HUD root.
    html.off('click.roundResultToggle').on('click.roundResultToggle', '.round-result-compact', function(event) {
      if ($(event.target).is('button')) return;
      const card = $(this).closest('.round-result-effect-card');
      UIHelper.roundResultExpanded(card).slideToggle(200);
    });

    // Close button
    UIHelper.closeHudButtons(html).on('click', () => {
      if (!game.user?.isGM) return;
      void getMassBattleHUDManager()?.setHudState(false, { broadcast: true });
    });

    // All clients must build synced HUD content locally; only edit handlers are GM-only.
    const battleData = game.settings.get('swade-mass-battles', 'battleData');
    const workflowStage = Number.isInteger(battleData.workflowStage) ? battleData.workflowStage : 0;
    const isSetupStage = workflowStage === 0;
    const isTroopActionsStage = workflowStage === 2;
    const isBattleRollsStage = workflowStage === 3;
    const isMoraleChecksStage = workflowStage === 4;
    const hudRoot = html.closest('[id^="mass-battles-hud"]');
    if (hudRoot.length) {
      hudRoot.toggleClass('workflow-stage-setup-active', isSetupStage);
      hudRoot.toggleClass('workflow-stage-troop-actions-active', isTroopActionsStage);
      hudRoot.toggleClass('workflow-stage-battle-rolls-active', isBattleRollsStage);
      hudRoot.toggleClass('workflow-stage-morale-checks-active', isMoraleChecksStage);
    }

    await hud.loadAdvantages(html, 'player', battleData.playerAdvantages || []);
    await hud.loadAdvantages(html, 'enemy', battleData.enemyAdvantages || []);
    await hud.loadTroops(html, 'player', battleData.playerTroops || []);
    await hud.loadTroops(html, 'enemy', battleData.enemyTroops || []);

    hud.constructor.updateForceTokens(html, 'player', battleData.playerForceSize || 0);
    hud.constructor.updateForceTokens(html, 'enemy', battleData.enemyForceSize || 0);
    await hud.constructor.updateForceEffects(html, battleData.playerForceSize || 0, battleData.enemyForceSize || 0);

    // Non-GM users can view the HUD, but only the GM can drive workflow/presence/data edits.
    if (!game.user?.isGM) return;

    // Battlemaster drop zones
    UIHelper.battlemasterDrops(html).on('drop', async (event) => {
      event.preventDefault();
      const data = JSON.parse(event.originalEvent.dataTransfer.getData('text/plain'));
      if (data.type === 'Actor') {
        const actor = await fromUuid(data.uuid);
        if (actor) {
          const side = event.currentTarget.dataset.side;
          const nextBattleData = game.settings.get('swade-mass-battles', 'battleData');
          if (side === 'player') {
            nextBattleData.playerBattleMaster = actor.uuid;
          } else {
            nextBattleData.enemyBattleMaster = actor.uuid;
          }
          await sendBattleDataUpdate(nextBattleData);

          await hud.refreshBattlemasterDisplays(side);
        }
      }
    });

    UIHelper.battlemasterDrops(html).on('dragover', (event) => {
      event.preventDefault();
    });

    // Remove battlemaster
    UIHelper.removeBattlemasterButtons(html).on('click', async (event) => {
      event.preventDefault();
      event.stopPropagation();
      const side = event.currentTarget.dataset.side;
      const nextBattleData = game.settings.get('swade-mass-battles', 'battleData');
      if (side === 'player') {
        nextBattleData.playerBattleMaster = null;
      } else {
        nextBattleData.enemyBattleMaster = null;
      }
      await sendBattleDataUpdate(nextBattleData);

      await hud.refreshBattlemasterDisplays(side);
    });

    // Roll buttons use shared roll helpers.
    UIHelper.rollBattleButtons(html).on('click', async (event) => {
      event.preventDefault();
      event.stopPropagation();
      const side = event.currentTarget.dataset.side;
      const actorUuid = event.currentTarget.dataset.actorUuid;
      const actor = await fromUuid(actorUuid);
      if (actor) {
        await hud.rollBattle(actor, side);
      }
    });

    UIHelper.rollMoraleButtons(html).on('click', async (event) => {
      event.preventDefault();
      event.stopPropagation();
      const side = event.currentTarget.dataset.side;
      const actorUuid = event.currentTarget.dataset.actorUuid;
      const actor = await fromUuid(actorUuid);
      if (actor) {
        await hud.rollMorale(actor, side);
      }
    });

    // Force controls
    UIHelper.forceIncreaseButtons(html).on('click', async (event) => {
      const side = event.currentTarget.dataset.side;
      const nextBattleData = game.settings.get('swade-mass-battles', 'battleData');
      if (side === 'player') {
        nextBattleData.playerForceSize = (nextBattleData.playerForceSize || 0) + 1;
      } else {
        nextBattleData.enemyForceSize = (nextBattleData.enemyForceSize || 0) + 1;
      }
      await sendBattleDataUpdate(nextBattleData);
      const playerSize = nextBattleData.playerForceSize || 0;
      const enemySize = nextBattleData.enemyForceSize || 0;

      // Keep both HUD windows in sync without full re-render.
      const hudRoots = [
        state.playerMassBattlesHUD,
        state.enemyMassBattlesHUD
      ].filter((entry) => entry?.rendered && entry?.element)
        .map((entry) => $(entry.element));

      for (const root of hudRoots) {
        UIHelper.forceValue(root, 'player').text(playerSize);
        UIHelper.forceValue(root, 'enemy').text(enemySize);
        hud.constructor.updateForceTokens(root, 'player', playerSize);
        hud.constructor.updateForceTokens(root, 'enemy', enemySize);
        await hud.constructor.updateForceEffects(root, playerSize, enemySize);
      }

      // Update battlemaster buttons with new modifiers
      await hud.updateBattlemasterButtons(html, 'player');
      await hud.updateBattlemasterButtons(html, 'enemy');
    });

    UIHelper.forceDecreaseButtons(html).on('click', async (event) => {
      const side = event.currentTarget.dataset.side;
      const nextBattleData = game.settings.get('swade-mass-battles', 'battleData');
      if (side === 'player') {
        nextBattleData.playerForceSize = Math.max(0, (nextBattleData.playerForceSize || 0) - 1);
      } else {
        nextBattleData.enemyForceSize = Math.max(0, (nextBattleData.enemyForceSize || 0) - 1);
      }
      await sendBattleDataUpdate(nextBattleData);
      const playerSize = nextBattleData.playerForceSize || 0;
      const enemySize = nextBattleData.enemyForceSize || 0;

      // Keep both HUD windows in sync without full re-render.
      const hudRoots = [
        state.playerMassBattlesHUD,
        state.enemyMassBattlesHUD
      ].filter((entry) => entry?.rendered && entry?.element)
        .map((entry) => $(entry.element));

      for (const root of hudRoots) {
        UIHelper.forceValue(root, 'player').text(playerSize);
        UIHelper.forceValue(root, 'enemy').text(enemySize);
        hud.constructor.updateForceTokens(root, 'player', playerSize);
        hud.constructor.updateForceTokens(root, 'enemy', enemySize);
        await hud.constructor.updateForceEffects(root, playerSize, enemySize);
      }

      // Update battlemaster buttons with new modifiers
      await hud.updateBattlemasterButtons(html, 'player');
      await hud.updateBattlemasterButtons(html, 'enemy');
    });

    // Add advantage buttons
    UIHelper.addAdvantageButtons(html).on('click', (event) => {
      const side = event.currentTarget.dataset.side;
      void DialogHelper.showAddAdvantageDialog(side, async (nextBattleData) => {
        if (state.playerMassBattlesHUD && state.playerMassBattlesHUD.rendered) {
          await state.playerMassBattlesHUD.loadAdvantages(state.playerMassBattlesHUD.element, 'player', nextBattleData.playerAdvantages || []);
          await state.playerMassBattlesHUD.loadAdvantages(state.playerMassBattlesHUD.element, 'enemy', nextBattleData.enemyAdvantages || []);
          await state.playerMassBattlesHUD.updateBattlemasterButtons(state.playerMassBattlesHUD.element, 'player');
          await state.playerMassBattlesHUD.updateBattlemasterButtons(state.playerMassBattlesHUD.element, 'enemy');
        }
        if (state.enemyMassBattlesHUD && state.enemyMassBattlesHUD.rendered) {
          await state.enemyMassBattlesHUD.loadAdvantages(state.enemyMassBattlesHUD.element, 'player', nextBattleData.playerAdvantages || []);
          await state.enemyMassBattlesHUD.loadAdvantages(state.enemyMassBattlesHUD.element, 'enemy', nextBattleData.enemyAdvantages || []);
          await state.enemyMassBattlesHUD.updateBattlemasterButtons(state.enemyMassBattlesHUD.element, 'player');
          await state.enemyMassBattlesHUD.updateBattlemasterButtons(state.enemyMassBattlesHUD.element, 'enemy');
        }
      });
    });

    // Troop drop zones
    UIHelper.troopDrops(html).on('drop', async (event) => {
      event.preventDefault();
      const data = JSON.parse(event.originalEvent.dataTransfer.getData('text/plain'));
      if (data.type === 'Actor') {
        const actor = await fromUuid(data.uuid);
        if (actor) {
          const side = event.currentTarget.dataset.side;
          const nextBattleData = game.settings.get('swade-mass-battles', 'battleData');
          const troopsList = side === 'player' ? (nextBattleData.playerTroops || []) : (nextBattleData.enemyTroops || []);
          troopsList.push({
            uuid: actor.uuid,
            status: 'Did not participate',
            effectType: 'Troop Effects',
            actorId: actor.id
          });
          if (side === 'player') {
            nextBattleData.playerTroops = troopsList;
          } else {
            nextBattleData.enemyTroops = troopsList;
          }
          await sendBattleDataUpdate(nextBattleData);

          // Update the appropriate HUD without re-rendering (avoids repositioning)
          if (side === 'player' && state.playerMassBattlesHUD && state.playerMassBattlesHUD.rendered) {
            await state.playerMassBattlesHUD.loadTroops(state.playerMassBattlesHUD.element, side, troopsList);
          } else if (side === 'enemy' && state.enemyMassBattlesHUD && state.enemyMassBattlesHUD.rendered) {
            await state.enemyMassBattlesHUD.loadTroops(state.enemyMassBattlesHUD.element, side, troopsList);
          }
        }
      }
    });

    UIHelper.troopDrops(html).on('dragover', (event) => {
      event.preventDefault();
    });
  }
}