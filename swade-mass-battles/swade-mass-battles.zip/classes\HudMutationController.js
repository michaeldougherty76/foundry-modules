import { DialogHelper } from './helpers/DialogHelper.js';

export class HudMutationController {
  static async syncAdvantagesAndButtonsAcrossRenderedHuds(state, battleData) {
    if (state.playerMassBattlesHUD && state.playerMassBattlesHUD.rendered) {
      await state.playerMassBattlesHUD.loadAdvantages(state.playerMassBattlesHUD.element, 'player', battleData.playerAdvantages || []);
      await state.playerMassBattlesHUD.loadAdvantages(state.playerMassBattlesHUD.element, 'enemy', battleData.enemyAdvantages || []);
      await state.playerMassBattlesHUD.updateBattlemasterButtons(state.playerMassBattlesHUD.element, 'player');
      await state.playerMassBattlesHUD.updateBattlemasterButtons(state.playerMassBattlesHUD.element, 'enemy');
    }

    if (state.enemyMassBattlesHUD && state.enemyMassBattlesHUD.rendered) {
      await state.enemyMassBattlesHUD.loadAdvantages(state.enemyMassBattlesHUD.element, 'player', battleData.playerAdvantages || []);
      await state.enemyMassBattlesHUD.loadAdvantages(state.enemyMassBattlesHUD.element, 'enemy', battleData.enemyAdvantages || []);
      await state.enemyMassBattlesHUD.updateBattlemasterButtons(state.enemyMassBattlesHUD.element, 'player');
      await state.enemyMassBattlesHUD.updateBattlemasterButtons(state.enemyMassBattlesHUD.element, 'enemy');
    }
  }

  static async showEditAdvantageHUD({ side, index, state }) {
    await DialogHelper.showEditAdvantageDialog(side, index, async (battleData) => {
      await HudMutationController.syncAdvantagesAndButtonsAcrossRenderedHuds(state, battleData);
    });
  }

  static async removeAdvantageHUD({ side, index, state, sendBattleDataUpdate }) {
    const battleData = game.settings.get('swade-mass-battles', 'battleData');
    const advantages = side === 'player' ? (battleData.playerAdvantages || []) : (battleData.enemyAdvantages || []);

    advantages.splice(index, 1);

    if (side === 'player') {
      battleData.playerAdvantages = advantages;
    } else {
      battleData.enemyAdvantages = advantages;
    }

    await sendBattleDataUpdate(battleData);

    await HudMutationController.syncAdvantagesAndButtonsAcrossRenderedHuds(state, battleData);
  }

  static async showTroopStatusDialogHUD({ side, index, state }) {
    await DialogHelper.showTroopStatusDialog(side, index, async ({ side: updatedSide, troops }) => {
      if (updatedSide === 'player' && state.playerMassBattlesHUD && state.playerMassBattlesHUD.rendered) {
        await state.playerMassBattlesHUD.loadTroops(state.playerMassBattlesHUD.element, updatedSide, troops);
        await state.playerMassBattlesHUD.updateBattlemasterButtons(state.playerMassBattlesHUD.element, 'player');
        await state.playerMassBattlesHUD.updateBattlemasterButtons(state.playerMassBattlesHUD.element, 'enemy');
      } else if (updatedSide === 'enemy' && state.enemyMassBattlesHUD && state.enemyMassBattlesHUD.rendered) {
        await state.enemyMassBattlesHUD.loadTroops(state.enemyMassBattlesHUD.element, updatedSide, troops);
        await state.enemyMassBattlesHUD.updateBattlemasterButtons(state.enemyMassBattlesHUD.element, 'player');
        await state.enemyMassBattlesHUD.updateBattlemasterButtons(state.enemyMassBattlesHUD.element, 'enemy');
      }
    });
  }

  static async removeTroopHUD({ side, index, state, sendBattleDataUpdate }) {
    const battleData = game.settings.get('swade-mass-battles', 'battleData');
    const troops = side === 'player' ? (battleData.playerTroops || []) : (battleData.enemyTroops || []);

    troops.splice(index, 1);

    if (side === 'player') {
      battleData.playerTroops = troops;
    } else {
      battleData.enemyTroops = troops;
    }

    await sendBattleDataUpdate(battleData);

    // Update the appropriate HUD without re-rendering (avoids repositioning)
    if (side === 'player' && state.playerMassBattlesHUD && state.playerMassBattlesHUD.rendered) {
      await state.playerMassBattlesHUD.loadTroops(state.playerMassBattlesHUD.element, side, troops);
    } else if (side === 'enemy' && state.enemyMassBattlesHUD && state.enemyMassBattlesHUD.rendered) {
      await state.enemyMassBattlesHUD.loadTroops(state.enemyMassBattlesHUD.element, side, troops);
    }
  }
}