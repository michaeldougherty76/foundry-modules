﻿import { BattleData } from '../BattleData.js';
import { MassBattlesHUD } from '../MassBattlesHUD.js';
import { UIHelper } from './UIHelper.js';

const { getTemplate } = foundry.applications.handlebars;

/**
 * SocketHelper
 *
 * Static coordinator for socketlib setup and socket-driven battle state sync.
 */
export class SocketHelper {
	static socket = null;

	static preserveRoundResultUnderlaysOnce = false;

	static roundResultSyncTimeoutIds = [];

	static getMassBattleHUDManager() {
		return game.modules.get('swade-mass-battles')?.api?.massBattleHUD ?? null;
	}

	static getWorkflowHud() {
		return SocketHelper.getMassBattleHUDManager()?.getWorkflowHUD?.() ?? null;
	}

	static getPlayerHud() {
		return SocketHelper.getMassBattleHUDManager()?.getPlayerHUD?.() ?? null;
	}

	static getEnemyHud() {
		return SocketHelper.getMassBattleHUDManager()?.getEnemyHUD?.() ?? null;
	}

	static async syncRoundResultUnderlayForHud(hud, battleData) {
		if (!hud?.side) return;

		const root = $(`#mass-battles-hud-${hud.side}`);
		if (!root.length) return;

		const host = UIHelper.roundResultUnderlayHost(root, hud.side).first();
		if (!host.length) return;

		const effectDataList = MassBattlesHUD.getRoundResultHistoryForSide(battleData, hud.side)
			.map((entry) => MassBattlesHUD.buildRoundResultEffectDataFromEntry(hud.side, entry));

		if (!effectDataList.length) {
			host.html('');
			return;
		}

		const template = await getTemplate('modules/swade-mass-battles/hbs/partials/effect-card.hbs');
		const underlayHtml = effectDataList
			.map((effectData) => `<div class="hud-round-result-underlay">${template(effectData)}</div>`)
			.join('');

		host.html(underlayHtml);
	}

	static async syncRoundResultUnderlays(battleData) {
		await Promise.all([
			SocketHelper.syncRoundResultUnderlayForHud(SocketHelper.getPlayerHud(), battleData),
			SocketHelper.syncRoundResultUnderlayForHud(SocketHelper.getEnemyHud(), battleData)
		]);
	}

	static scheduleRoundResultUnderlaySync() {
		for (const id of SocketHelper.roundResultSyncTimeoutIds) {
			window.clearTimeout(id);
		}
		SocketHelper.roundResultSyncTimeoutIds = [];

		const delays = [0, 120, 300];
		for (const delay of delays) {
			const id = window.setTimeout(async () => {
				const currentBattleData = game.settings.get('swade-mass-battles', 'battleData');
				await SocketHelper.syncRoundResultUnderlays(currentBattleData);
			}, delay);
			SocketHelper.roundResultSyncTimeoutIds.push(id);
		}
	}

	static hasSocket() {
		return Boolean(SocketHelper.socket);
	}

	static getSocket() {
		return SocketHelper.socket;
	}

	static async initializeSocketlib(moduleName = 'swade-mass-battles') {
		if (typeof socketlib === 'undefined') {
			SocketHelper.socket = null;
			return false;
		}

		const socket = socketlib.registerModule(moduleName);
		SocketHelper.socket = socket;

		socket.register('commitBattleDataFromGM', (battleData) => SocketHelper.commitBattleDataFromGM(battleData));
		socket.register('updateBattleData', (battleData) => SocketHelper.receiveBattleDataUpdate(battleData));
		socket.register('applyMassBattlesHudState', (payload = {}) => SocketHelper.getMassBattleHUDManager()?.applyHudState(payload));
		socket.register('getMassBattlesStatusFromGM', () => SocketHelper.getMassBattleHUDManager()?.getStatusForGM());

		return true;
	}

	static async broadcastHudState(payload) {
		if (!SocketHelper.socket) return;
		await SocketHelper.socket.executeForEveryone('applyMassBattlesHudState', payload);
	}

	static markPreserveRoundResultUnderlaysOnce() {
		SocketHelper.preserveRoundResultUnderlaysOnce = true;
	}

	static async refreshRenderedHudWindows() {
		const workflowHud = SocketHelper.getWorkflowHud();
		if (workflowHud?.rendered) {
			workflowHud.render();
		}

		await MassBattlesHUD.refreshMassBattlesHudContent();
	}

	static async requestMassBattlesStatusFromGM() {
		if (game.user?.isGM || !SocketHelper.socket) return;

		try {
			const status = await SocketHelper.socket.executeAsGM('getMassBattlesStatusFromGM');
			if (!status || typeof status !== 'object') return;
			await SocketHelper.getMassBattleHUDManager()?.applyHudState(status);
		} catch (error) {
			console.warn('SWADE Battles: Failed to request mass battles HUD status from GM.', error);
		}
	}

	static async sendBattleDataUpdate(battleData) {
		if (SocketHelper.socket) {
			if (game.user?.isGM) {
				await SocketHelper.commitBattleDataFromGM(battleData);
				return;
			}

			await SocketHelper.socket.executeAsGM('commitBattleDataFromGM', battleData);
			return;
		}

		// Fallback when socketlib is unavailable.
		await BattleData.set(battleData);
	}

	static async commitBattleDataFromGM(battleData) {
		if (!game.user?.isGM) return;

		await BattleData.set(battleData);
		if (SocketHelper.socket) {
			await SocketHelper.socket.executeForEveryone('updateBattleData', battleData);
		}
	}

	static async receiveBattleDataUpdate(battleData, { force = false } = {}) {
		const existing = BattleData.getRaw();
		const existingRound = Number(existing?.battleRound ?? 1);
		const incomingRound = Number(battleData?.battleRound ?? 1);
		const sameScope = existingRound === incomingRound;

		const existingHasBothTotals = Number.isFinite(existing?.playerBattleRollTotal) && Number.isFinite(existing?.enemyBattleRollTotal);
		const incomingHasBothTotals = Number.isFinite(battleData?.playerBattleRollTotal) && Number.isFinite(battleData?.enemyBattleRollTotal);
		const existingHasOutcomeState = Number.isFinite(MassBattlesHUD.getBattleRollSuccesses(existing, 'player')) && Number.isFinite(MassBattlesHUD.getBattleRollSuccesses(existing, 'enemy'));
		const incomingClearsOutcomeState = !Number.isFinite(MassBattlesHUD.getBattleRollSuccesses(battleData, 'player')) && !Number.isFinite(MassBattlesHUD.getBattleRollSuccesses(battleData, 'enemy'));
		const isRoundAdvanceClear = incomingRound === existingRound + 1 && existingHasOutcomeState && incomingClearsOutcomeState;

		// Ignore stale payloads that would regress complete current-round roll data.
		if (!force && sameScope && existingHasBothTotals && !incomingHasBothTotals) {
			await SocketHelper.syncRoundResultUnderlays(existing);
			SocketHelper.scheduleRoundResultUnderlaySync();
			await SocketHelper.refreshRenderedHudWindows();
			return;
		}

		// Preserve underlay cards on round advance while roll fields are intentionally cleared.
		if (!force && (SocketHelper.preserveRoundResultUnderlaysOnce || isRoundAdvanceClear)) {
			SocketHelper.preserveRoundResultUnderlaysOnce = false;
			await BattleData.set(battleData);
			await SocketHelper.refreshRenderedHudWindows();
			return;
		}

		// Update local settings
		await BattleData.set(battleData);

		const syncedBattleData = BattleData.getRaw();
		await SocketHelper.syncRoundResultUnderlays(syncedBattleData);
		SocketHelper.scheduleRoundResultUnderlaySync();

		await SocketHelper.refreshRenderedHudWindows();
	}
}
