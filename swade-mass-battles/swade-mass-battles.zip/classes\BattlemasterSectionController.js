import { MassBattleRulesEngine } from './MassBattleRulesEngine.js';
import { UIHelper } from './helpers/UIHelper.js';

const { getTemplate } = foundry.applications.handlebars;

const BATTLEMASTER_DISPLAY_TEMPLATE = 'modules/swade-mass-battles/hbs/partials/battle-master.hbs';
const BATTLEMASTER_DROP_ZONE_TEMPLATE = 'modules/swade-mass-battles/hbs/partials/battlemaster-drop-zone.hbs';

export class BattlemasterSectionController {
  static async refreshDisplays({ state, side }) {
    const renderedHuds = [state.playerMassBattlesHUD, state.enemyMassBattlesHUD]
      .filter((hud) => hud?.rendered && hud?.element);

    for (const hud of renderedHuds) {
      await hud.updateBattlemasterDisplay(hud.element, side);
    }
  }

  static async updateDisplay({ html, side, sendBattleDataUpdate, onRefreshDisplays, onRollBattle, onRollMorale }) {
    html = $(html);
    const battleData = game.settings.get('swade-mass-battles', 'battleData');
    const battlemasterUuid = side === 'player' ? battleData.playerBattleMaster : battleData.enemyBattleMaster;

    // Find the battlemaster container - either the drop zone or existing battlemaster
    const container = UIHelper.battlemasterContainerBySide(html, side);
    container.empty();

    if (battlemasterUuid) {
      const actor = await fromUuid(battlemasterUuid);
      if (actor) {
        const battleSkillItem = actor.items.find((item) => item.type === 'skill' && item.name === 'Battle');
        const battleDie = battleSkillItem?.system?.die?.sides || 4;
        const spiritDie = actor.system?.attributes?.spirit?.die?.sides || 4;

        const modifiers = MassBattleRulesEngine.calculateModifiers(side);
        const battleModText = modifiers.battle >= 0 ? `+${modifiers.battle}` : `${modifiers.battle}`;
        const moraleModText = modifiers.morale >= 0 ? `+${modifiers.morale}` : `${modifiers.morale}`;

        const battlemasterTemplate = await getTemplate(BATTLEMASTER_DISPLAY_TEMPLATE);
        const battlemasterHtml = $(battlemasterTemplate({
          side,
          actor: {
            img: actor.img,
            name: actor.name,
            uuid: actor.uuid
          },
          battleDie,
          spiritDie,
          battleModText,
          moraleModText
        }));
        container.append(battlemasterHtml);

        UIHelper.removeBattlemasterButtons(container).on('click', async (event) => {
          event.preventDefault();
          event.stopPropagation();
          const changedSide = event.currentTarget.dataset.side;
          const nextBattleData = game.settings.get('swade-mass-battles', 'battleData');
          if (changedSide === 'player') {
            nextBattleData.playerBattleMaster = null;
          } else {
            nextBattleData.enemyBattleMaster = null;
          }
          await sendBattleDataUpdate(nextBattleData);

          await onRefreshDisplays(changedSide);
        });

        UIHelper.rollBattleButtons(container).on('click', async (event) => {
          event.preventDefault();
          event.stopPropagation();
          const changedSide = event.currentTarget.dataset.side;
          const actorUuid = event.currentTarget.dataset.actorUuid;
          const rollActor = await fromUuid(actorUuid);
          if (rollActor) {
            await onRollBattle(rollActor, changedSide);
          }
        });

        UIHelper.rollMoraleButtons(container).on('click', async (event) => {
          event.preventDefault();
          event.stopPropagation();
          const changedSide = event.currentTarget.dataset.side;
          const actorUuid = event.currentTarget.dataset.actorUuid;
          const rollActor = await fromUuid(actorUuid);
          if (rollActor) {
            await onRollMorale(rollActor, changedSide);
          }
        });
      }
      return;
    }

    const dropZoneTemplate = await getTemplate(BATTLEMASTER_DROP_ZONE_TEMPLATE);
    const dropZone = $(dropZoneTemplate({ side }));
    container.append(dropZone);

    dropZone.on('drop', async (event) => {
      event.preventDefault();
      const data = JSON.parse(event.originalEvent.dataTransfer.getData('text/plain'));
      if (data.type === 'Actor') {
        const actor = await fromUuid(data.uuid);
        if (actor) {
          const changedSide = event.currentTarget.dataset.side;
          const nextBattleData = game.settings.get('swade-mass-battles', 'battleData');
          if (changedSide === 'player') {
            nextBattleData.playerBattleMaster = actor.uuid;
          } else {
            nextBattleData.enemyBattleMaster = actor.uuid;
          }
          await sendBattleDataUpdate(nextBattleData);

          await onRefreshDisplays(changedSide);
        }
      }
    });

    dropZone.on('dragover', (event) => {
      event.preventDefault();
    });
  }
}