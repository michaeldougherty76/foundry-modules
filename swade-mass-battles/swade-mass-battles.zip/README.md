# SWADE Battles

A Foundry VTT module for the SWADE system.

## Features

Coming soon...

## Installation

Install from the Foundry VTT module browser or manually using the manifest URL.

## Requirements

- SWADE System for Foundry VTT

## License

TBD
