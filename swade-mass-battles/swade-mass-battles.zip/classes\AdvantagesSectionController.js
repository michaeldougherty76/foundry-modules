import { UIHelper } from './helpers/UIHelper.js';

const { getTemplate } = foundry.applications.handlebars;

export class AdvantagesSectionController {
  static async load({ html, side, advantages, prepareEffectData, onEditAdvantage, onRemoveAdvantage }) {
    html = $(html);
    const list = UIHelper.advantagesList(html, side);
    list.empty();

    const template = await getTemplate('modules/swade-mass-battles/hbs/partials/effect-card.hbs');

    advantages.forEach((adv, index) => {
      // Handle legacy format with just description and modifier
      const advantage = (typeof adv === 'object' && adv.result) ? adv : {
        result: adv.description || 'Tactical Advantage',
        resultDescription: '',
        battleModifierSameSide: adv.modifier || 0,
        battleModifierOppositeSide: 0,
        moraleModifierSameSide: 0,
        moraleModifierOppositeSide: 0,
        forceTokenModifierSameSide: 0,
        forceTokenModifierOppositeSide: 0,
        suffersFatigue: 0,
        suffersWound: 0
      };

      const effectData = prepareEffectData(side, advantage);

      const cardHtml = template({
        cardClass: `advantage-card-${side}-${index}`,
        compactClass: 'advantage-compact',
        expandedClass: 'advantage-expanded',
        hasButtons: true,
        removeButtonClass: 'remove-advantage',
        editButtonClass: 'edit-advantage',
        side,
        index,
        title: advantage.result,
        description: advantage.resultDescription,
        ...effectData
      });

      list.append(cardHtml);
    });

    UIHelper.editAdvantageButtons(html, side).on('click', async (event) => {
      const button = $(event.target);
      const buttonSide = button.data('side');
      const buttonIndex = button.data('index');
      await onEditAdvantage(buttonSide, buttonIndex);
    });

    UIHelper.removeAdvantageButtons(html, side).on('click', async (event) => {
      const button = $(event.target);
      const buttonSide = button.data('side');
      const buttonIndex = button.data('index');
      await onRemoveAdvantage(buttonSide, buttonIndex);
    });

    UIHelper.advantageCards(html, side).each(function() {
      UIHelper.advantageCompact($(this)).on('click', function(event) {
        // Only toggle if we didn't click on a button
        if (!$(event.target).is('button')) {
          const card = $(this).closest('[class*="advantage-card-"]');
          UIHelper.advantageExpanded(card).slideToggle(200);
        }
      });
    });
  }
}