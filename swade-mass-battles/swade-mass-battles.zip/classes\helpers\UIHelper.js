﻿const DEFAULT_PLAYER_HUD_LEFT = 180;
const DEFAULT_ENEMY_HUD_RIGHT = 350;

/**
 * UI-only utility methods used by HUD orchestration.
 *
 * Keep this helper focused on DOM querying, viewport/layout reactions,
 * and CSS variable updates that are presentation concerns.
 */
export class UIHelper {
  static find(scope, selector) {
    return scope?.find(selector);
  }

  static hudDragHandle(scope) {
    return UIHelper.find(scope, '.hud-drag-handle');
  }

  static closeHudButtons(scope) {
    return UIHelper.find(scope, '.close-hud');
  }

  static battlemasterDrops(scope) {
    return UIHelper.find(scope, '.battlemaster-drop');
  }

  static removeBattlemasterButtons(scope) {
    return UIHelper.find(scope, '.remove-battlemaster');
  }

  static rollBattleButtons(scope) {
    return UIHelper.find(scope, '.roll-battle');
  }

  static rollMoraleButtons(scope) {
    return UIHelper.find(scope, '.roll-morale');
  }

  static forceIncreaseButtons(scope) {
    return UIHelper.find(scope, '.force-increase');
  }

  static forceDecreaseButtons(scope) {
    return UIHelper.find(scope, '.force-decrease');
  }

  static forceValue(scope, side) {
    return UIHelper.find(scope, `.force-value[data-side="${side}"]`);
  }

  static addAdvantageButtons(scope) {
    return UIHelper.find(scope, '.add-advantage-btn');
  }

  static troopDrops(scope) {
    return UIHelper.find(scope, '.troop-drop');
  }

  static battlemasterDropBySide(scope, side) {
    return UIHelper.find(scope, `.battlemaster-drop[data-side="${side}"]`);
  }

  static battlemasterContainerBySide(scope, side) {
    let container = UIHelper.battlemasterDropBySide(scope, side).parent();
    if (!container.length) {
      container = UIHelper.find(scope, `.hud-battlemaster .remove-battlemaster[data-side="${side}"]`).closest('.hud-row-content');
    }
    return container;
  }

  static advantagesList(scope, side) {
    return UIHelper.find(scope, `.advantages-list[data-side="${side}"]`);
  }

  static editAdvantageButtons(scope, side) {
    return UIHelper.find(scope, `.edit-advantage[data-side="${side}"]`);
  }

  static removeAdvantageButtons(scope, side) {
    return UIHelper.find(scope, `.remove-advantage[data-side="${side}"]`);
  }

  static advantageCards(scope, side) {
    return UIHelper.find(scope, `[class*="advantage-card-${side}-"]`);
  }

  static troopsGrid(scope, side) {
    return UIHelper.find(scope, `.troops-grid[data-side="${side}"]`);
  }

  static troopStatusButtons(scope, side) {
    return UIHelper.find(scope, `.troop-status[data-side="${side}"]`);
  }

  static removeTroopButtons(scope, side) {
    return UIHelper.find(scope, `.remove-troop[data-side="${side}"]`);
  }

  static troopEffectCards(scope, side) {
    return UIHelper.find(scope, `[class*="troop-effect-${side}-"]`);
  }

  static totalModifier(scope, side) {
    return UIHelper.find(scope, `.total-modifier[data-side="${side}"]`);
  }

  static moraleModifier(scope, side) {
    return UIHelper.find(scope, `.morale-modifier[data-side="${side}"]`);
  }

  static addStatusButtons(scope) {
    return UIHelper.find(scope, '.add-status');
  }

  static deleteStatusButtons(scope) {
    return UIHelper.find(scope, '.delete-status');
  }

  static forceTokens(scope, side) {
    return UIHelper.find(scope, `.force-tokens[data-side="${side}"]`);
  }

  static forceEffect(scope, side) {
    return UIHelper.find(scope, `.force-effect[data-side="${side}"]`);
  }

  static forceCompactInSide(scope, side) {
    return UIHelper.find(scope, `.force-effect[data-side="${side}"] .force-compact`);
  }

  static workflowButtonsByStage(scope) {
    return UIHelper.find(scope, '.workflow-button[data-stage]');
  }

  static workflowAcceptPendingRollButtons(scope) {
    return UIHelper.find(scope, '.workflow-accept-pending-roll');
  }

  static workflowAcceptPendingMoraleRollButtons(scope) {
    return UIHelper.find(scope, '.workflow-accept-pending-morale-roll');
  }

  static troopDropZonesForStage(scope) {
    return UIHelper.find(scope, '.drop-zone.troop-drop');
  }

  static tacticalAdvantagesStageElements(scope) {
    return UIHelper.find(scope, '.advantages-row-content, .advantages-row-label');
  }

  static roundResultExpanded(scope) {
    return UIHelper.find(scope, '.round-result-expanded');
  }

  static advantageCompact(scope) {
    return UIHelper.find(scope, '.advantage-compact');
  }

  static advantageExpanded(scope) {
    return UIHelper.find(scope, '.advantage-expanded');
  }

  static troopCompact(scope) {
    return UIHelper.find(scope, '.troop-compact');
  }

  static troopExpanded(scope) {
    return UIHelper.find(scope, '.troop-expanded');
  }

  static roundResultUnderlayHost(scope, side) {
    return UIHelper.find(scope, `.hud-round-result-underlay-host[data-side="${side}"]`);
  }

  static statusDescription(scope) {
    return UIHelper.find(scope, '.status-description');
  }

  static statusEffectsContainer(scope) {
    return UIHelper.find(scope, '.status-effects-container');
  }

  static getPlayerHudLeftFromControls() {
    const uiLeft = document.querySelector('#ui-left');
    const controls = uiLeft?.querySelector('#controls') || document.querySelector('#controls');

    // Try to anchor off the second controls column first, then fall back to controls/ui-left.
    const secondColumn = controls?.querySelector('.sub-controls, .control-tools, .toolclip, [class*="sub-control"], [class*="control-tools"]');
    const anchorSource = secondColumn || controls || uiLeft;
    if (!anchorSource) return null;

    const anchorRect = anchorSource.getBoundingClientRect();
    return Math.round(anchorRect.right + 50);
  }

  static updatePlayerHudAnchorPosition() {
    const computedLeft = UIHelper.getPlayerHudLeftFromControls();
    const left = Number.isFinite(computedLeft) ? computedLeft : DEFAULT_PLAYER_HUD_LEFT;
    document.documentElement.style.setProperty('--swade-mass-battles-player-hud-left', `${left}px`);
  }

  static getEnemyHudRightFromSidebar() {
    const sidebar = document.querySelector('#sidebar');
    if (!sidebar) return null;

    const rect = sidebar.getBoundingClientRect();
    const sidebarWidth = Math.max(0, Math.round(rect.width));
    const expandedExtraOffset = sidebar.classList.contains('collapsed') ? 0 : 30;

    // Keep enemy HUD 10px away from the sidebar/chat toolbar edge.
    return sidebarWidth + 10 + expandedExtraOffset;
  }

  static updateEnemyHudAnchorPosition() {
    const computedRight = UIHelper.getEnemyHudRightFromSidebar();
    const right = Number.isFinite(computedRight) ? computedRight : DEFAULT_ENEMY_HUD_RIGHT;
    document.documentElement.style.setProperty('--swade-enemy-hud-right', `${right}px`);
  }

  static updateHudAnchorPositions() {
    UIHelper.updatePlayerHudAnchorPosition();
    UIHelper.updateEnemyHudAnchorPosition();
  }

  static scheduleEnemyHudAnchorUpdate() {
    // Sidebar collapse/expand can animate, so update after layout settles.
    UIHelper.updateEnemyHudAnchorPosition();
    requestAnimationFrame(() => UIHelper.updateEnemyHudAnchorPosition());
    window.setTimeout(() => UIHelper.updateEnemyHudAnchorPosition(), 160);
  }
}
