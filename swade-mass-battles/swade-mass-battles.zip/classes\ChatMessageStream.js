import { WorkflowService } from './WorkflowService.js';
import { WorkflowHudAccessService } from './WorkflowHudAccessService.js';

function getModuleServices() {
  return game.modules.get('swade-mass-battles')?.api?.services ?? null;
}

function getWorkflowService() {
  return getModuleServices()?.workflowService || new WorkflowService();
}

function getWorkflowHudAccess() {
  return getModuleServices()?.workflowHudAccess || new WorkflowHudAccessService();
}

function isMassBattleHudOpen() {
  return getWorkflowHudAccess().getMassBattleHUDManager()?.isOpen?.() ?? false;
}

export class ChatMessageStream {
  static getMessageTotal(message) {
    const rolls = Array.isArray(message.rolls) ? message.rolls : [];
    for (const roll of rolls) {
      if (Number.isFinite(roll?.total)) return Number(roll.total);
    }

    const directTotal = Number(message.roll?.total);
    if (Number.isFinite(directTotal)) return directTotal;

    const html = String(message.content ?? '');
    const match = html.match(/class="(?:[^"]*\s)?total(?:\s[^"]*)?"[^>]*>\s*(-?\d+)\s*</i);
    if (match) {
      const parsed = Number.parseInt(match[1], 10);
      if (Number.isFinite(parsed)) return parsed;
    }

    return null;
  }

  static isBattleRollMessage(message) {
    const flavor = String(message?.flavor ?? '');
    const content = String(message?.content ?? '');
    const combined = `${flavor} ${content}`.toLowerCase();

    if (combined.includes('morale') || combined.includes('spirit')) return false;
    return combined.includes('battle');
  }

  static isMoraleRollMessage(message) {
    const flavor = String(message?.flavor ?? '');
    const content = String(message?.content ?? '');
    const combined = `${flavor} ${content}`.toLowerCase();
    return combined.includes('morale') || combined.includes('spirit');
  }

  static resolveBattleSideForMessage(message, battleData) {
    const speaker = message.speaker || {};
    const speakerActor = speaker.actor ? game.actors.get(speaker.actor) : null;
    const speakerScene = speaker.scene ? game.scenes?.get(speaker.scene) : null;
    const speakerToken = speaker.token && speakerScene ? speakerScene.tokens?.get(speaker.token) : null;
    const tokenActor = speakerToken?.actor || null;

    const candidateKeys = new Set([
      speakerActor?.uuid,
      speakerActor?.id,
      tokenActor?.uuid,
      tokenActor?.id,
      speaker.actor
    ].filter(Boolean));

    if (battleData.playerBattleMaster && candidateKeys.has(battleData.playerBattleMaster)) return 'player';
    if (battleData.enemyBattleMaster && candidateKeys.has(battleData.enemyBattleMaster)) return 'enemy';

    return null;
  }

  static addPendingBattleRoll(battleData, side, message, total) {
    const workflowService = getWorkflowService();
    const key = workflowService.getPendingBattleRollsKey(side);
    const existing = workflowService.getPendingBattleRollsForSide(battleData, side);
    const messageId = message?.id || null;
    if (messageId && existing.some((entry) => entry.messageId === messageId)) return;

    const next = [{
      id: foundry.utils.randomID(),
      messageId,
      total,
      successes: Math.max(0, Math.floor(total / 4)),
      flavor: String(message?.flavor || '').trim(),
      createdAt: Date.now()
    }, ...existing].slice(0, 12);

    battleData[key] = next;
  }

  static addPendingMoraleRoll(battleData, side, message, total) {
    const workflowService = getWorkflowService();
    const key = workflowService.getPendingMoraleRollsKey(side);
    const existing = workflowService.getPendingMoraleRollsForSide(battleData, side);
    const messageId = message?.id || null;
    if (messageId && existing.some((entry) => entry.messageId === messageId)) return;

    const next = [{
      id: foundry.utils.randomID(),
      messageId,
      total,
      flavor: String(message?.flavor || '').trim(),
      createdAt: Date.now()
    }, ...existing].slice(0, 12);

    battleData[key] = next;
  }

  static async handleCreateChatMessage(message, options, userId) {
    if (!game.user?.isGM) return;

    const battleData = game.settings.get('swade-mass-battles', 'battleData');
    if (!battleData || !isMassBattleHudOpen()) return;

    const workflowService = getWorkflowService();
    const workflowHudAccess = getWorkflowHudAccess();

    const workflowStage = Number.isInteger(battleData.workflowStage) ? battleData.workflowStage : 0;
    const side = ChatMessageStream.resolveBattleSideForMessage(message, battleData);
    const total = ChatMessageStream.getMessageTotal(message);

    if (side && Number.isFinite(total) && workflowStage === 3 && ChatMessageStream.isBattleRollMessage(message)) {
      ChatMessageStream.addPendingBattleRoll(battleData, side, message, Number(total));
      void workflowService.sendBattleDataUpdate(battleData).then(() => {
        const workflowHUD = workflowHudAccess.getWorkflowHUD?.() ?? null;
        if (workflowHUD?.rendered) workflowHUD.render();
      });
      return;
    }

    if (side && Number.isFinite(total) && workflowStage === 4 && workflowService.sideNeedsMoraleCheck(battleData, side) && ChatMessageStream.isMoraleRollMessage(message)) {
      ChatMessageStream.addPendingMoraleRoll(battleData, side, message, Number(total));
      void workflowService.sendBattleDataUpdate(battleData).then(() => {
        const workflowHUD = workflowHudAccess.getWorkflowHUD?.() ?? null;
        if (workflowHUD?.rendered) workflowHUD.render();
      });
    }
  }
}
