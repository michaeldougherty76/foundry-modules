﻿import { BattleData } from './BattleData.js';
import { MassBattlesHUD } from './MassBattlesHUD.js';
import { WorkflowHUD } from './WorkflowHUD.js';
import { SocketHelper } from './helpers/SocketHelper.js';
import { UIHelper } from './helpers/UIHelper.js';

/**
 * MassBattleHUDManager
 *
 * Top-level coordinator that owns and manages the three HUD Application instances
 * involved in a Mass Battle session:
 *
 *  - `workflowHUD`           — center workflow pane ({@link WorkflowHUD})
 *  - `playerMassBattlesHUD`  — player-side HUD panel ({@link MassBattlesHUD})
 *  - `enemyMassBattlesHUD`   — enemy-side HUD panel ({@link MassBattlesHUD})
 *
 * Typical lifecycle:
 * ```js
 * const hud = new MassBattleHUDManager();
 * hud.openLocal(); // creates and renders all mass-battle HUDs
 * hud.isOpen();   // true
 * hud.closeLocal(); // closes and nulls the active HUDs
 * ```
 */
export class MassBattleHUDManager {
  static getConfiguredInstance(existingManager = null) {
    return existingManager instanceof MassBattleHUDManager ? existingManager : new MassBattleHUDManager();
  }

  constructor() {
    /**
     * The workflow pane Application, or `null` when closed.
     * @type {Application | null}
     */
    this.workflowHUD = null;

    /**
     * Player-side mass battle HUD Application.
     * @type {Application | null}
     */
    this.playerMassBattlesHUD = null;

    /**
     * Enemy-side mass battle HUD Application.
     * @type {Application | null}
     */
    this.enemyMassBattlesHUD = null;
  }

  _getPlayerHud() {
    return this.playerMassBattlesHUD;
  }

  _setPlayerHud(hud) {
    this.playerMassBattlesHUD = hud;
  }

  _getEnemyHud() {
    return this.enemyMassBattlesHUD;
  }

  _setEnemyHud(hud) {
    this.enemyMassBattlesHUD = hud;
  }

  _getWorkflowHud() {
    return this.workflowHUD;
  }

  _setWorkflowHud(hud) {
    this.workflowHUD = hud;
  }

  getPlayerHUD() {
    return this._getPlayerHud();
  }

  getEnemyHUD() {
    return this._getEnemyHud();
  }

  getWorkflowHUD() {
    return this._getWorkflowHud();
  }

  // ---------------------------------------------------------------------------
  // State queries
  // ---------------------------------------------------------------------------

  /**
   * Returns `true` when the workflow HUD Application is currently rendered.
   * @returns {boolean}
   */
  isOpen() {
    return Boolean(this._getPlayerHud()?.rendered || this._getEnemyHud()?.rendered || this._getWorkflowHud()?.rendered);
  }

  // ---------------------------------------------------------------------------
  // Open / close
  // ---------------------------------------------------------------------------

  /**
   * Creates (if necessary) and renders the workflow HUD.
   * Safe to call when the HUD is already open.
   */
  openLocal() {
    const windows = Object.values(ui.windows || {});

    let playerHud = this._getPlayerHud();
    if (!playerHud || !ui.windows?.[playerHud.appId]) {
      playerHud = windows.find((app) => app instanceof MassBattlesHUD && app.side === 'player') || null;
      this._setPlayerHud(playerHud);
    }

    let enemyHud = this._getEnemyHud();
    if (!enemyHud || !ui.windows?.[enemyHud.appId]) {
      enemyHud = windows.find((app) => app instanceof MassBattlesHUD && app.side === 'enemy') || null;
      this._setEnemyHud(enemyHud);
    }

    let workflowHud = this._getWorkflowHud();
    if (!workflowHud || !ui.windows?.[workflowHud.appId]) {
      workflowHud = windows.find((app) => app instanceof WorkflowHUD) || null;
      this._setWorkflowHud(workflowHud);
    }

    if (!playerHud || !playerHud.rendered) {
      this.updatePlayerHudAnchorPosition();
      playerHud = playerHud || new MassBattlesHUD('player');
      if (playerHud) {
        this._setPlayerHud(playerHud);
        playerHud.render(true);
      }
    }

    if (!enemyHud || !enemyHud.rendered) {
      enemyHud = enemyHud || new MassBattlesHUD('enemy');
      if (enemyHud) {
        this._setEnemyHud(enemyHud);
        enemyHud.render(true);
      }
    }

    if (!workflowHud || !workflowHud.rendered) {
      workflowHud = workflowHud || new WorkflowHUD();
      if (workflowHud) {
        this._setWorkflowHud(workflowHud);
        workflowHud.render(true);
      }
    }
  }

  /**
   * Closes and destroys the workflow HUD Application reference.
   * Safe to call when the HUD is already closed.
   */
  closeLocal() {
    const playerHud = this._getPlayerHud();
    if (playerHud) {
      playerHud.close();
      this._setPlayerHud(null);
    }

    const enemyHud = this._getEnemyHud();
    if (enemyHud) {
      enemyHud.close();
      this._setEnemyHud(null);
    }

    const workflowHud = this._getWorkflowHud();
    if (workflowHud) {
      workflowHud.close();
      this._setWorkflowHud(null);
    }

    const windows = Object.values(ui.windows || {});
    for (const app of windows) {
      if (app instanceof MassBattlesHUD || app instanceof WorkflowHUD) app.close();
    }

    const hudRoots = document.querySelectorAll(
      '#mass-battles-hud-player, #mass-battles-hud-enemy, #workflow-hud, .workflow-hud, .mass-battles-hud-container'
    );
    for (const root of hudRoots) {
      const appRoot = root.closest('.app') || root;
      appRoot.remove();
    }
  }

  /**
   * Toggles the workflow HUD open/closed.
   */
  async setHudState(active, { broadcast = false, battleData = null } = {}) {
    if (active) {
      this.openLocal();
    } else {
      this.closeLocal();
    }

    if (broadcast && game.user?.isGM) {
      const payloadBattleData = battleData || BattleData.getRaw() || null;
      await SocketHelper.broadcastHudState({
        active: Boolean(active),
        battleData: payloadBattleData,
        sourceUserId: game.user?.id
      });
    }
  }

  async applyHudState(payload = {}) {
    if (payload?.sourceUserId && payload.sourceUserId === game.user?.id) return;

    if (payload?.battleData && typeof payload.battleData === 'object') {
      // HUD-state payloads originate from GM snapshots and should be applied authoritatively.
      await SocketHelper.receiveBattleDataUpdate(payload.battleData, { force: true });
    }

    await this.setHudState(Boolean(payload?.active), { broadcast: false });
  }

  async toggleHud() {
    if (!game.user?.isGM) return;
    const shouldOpen = !this.isOpen();
    await this.setHudState(shouldOpen, { broadcast: true });
  }

  getStatusForGM() {
    if (!game.user?.isGM) return { active: false, battleData: null };
    return {
      active: this.isOpen(),
      battleData: BattleData.getRaw() || null
    };
  }

  // ---------------------------------------------------------------------------
  // Refresh
  // ---------------------------------------------------------------------------

  /**
   * Re-renders the workflow HUD if it is currently open.
   */
  refresh() {
    if (this._getWorkflowHud()?.rendered) this._getWorkflowHud().render();
    if (this._getPlayerHud()?.rendered) this._getPlayerHud().render();
    if (this._getEnemyHud()?.rendered) this._getEnemyHud().render();
  }

  getPlayerHudLeftFromControls() {
    return UIHelper.getPlayerHudLeftFromControls();
  }

  updatePlayerHudAnchorPosition() {
    UIHelper.updatePlayerHudAnchorPosition();
  }

  getEnemyHudRightFromSidebar() {
    return UIHelper.getEnemyHudRightFromSidebar();
  }

  updateEnemyHudAnchorPosition() {
    UIHelper.updateEnemyHudAnchorPosition();
  }

  updateHudAnchorPositions() {
    UIHelper.updateHudAnchorPositions();
  }

  scheduleEnemyHudAnchorUpdate() {
    UIHelper.scheduleEnemyHudAnchorUpdate();
  }
}
