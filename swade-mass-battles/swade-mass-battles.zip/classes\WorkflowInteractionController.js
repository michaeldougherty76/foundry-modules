import { UIHelper } from './helpers/UIHelper.js';

export class WorkflowInteractionController {
  constructor({ uiHelper = UIHelper } = {}) {
    this.uiHelper = uiHelper;
  }

  async onRender({ hud, html, workflowMethods }) {
    const uiHelper = this.uiHelper;
    const {
      sendBattleDataUpdate,
      getPendingBattleRollsForSide,
      getPendingMoraleRollsForSide,
      getMoraleCheckTotalKey,
      getMoraleOutcomeData,
      appendCurrentRoundResultHistoryIfReady,
      syncRoundResultUnderlays,
      scheduleRoundResultUnderlaySync,
      rollOnMassBattleResultsTable,
      getPlayerHUD,
      getEnemyHUD,
      setPreserveRoundResultUnderlaysOnce,
      hasSocket,
      getWorkflowHUD
    } = workflowMethods;

    // Players and GM can both roll on the configured Mass Battle results table.
    uiHelper.find(html, '#workflow-roll-results-table').on('click', async () => {
      await rollOnMassBattleResultsTable();
    });

    // Workflow progression is GM-authoritative.
    if (!game.user?.isGM) return;

    uiHelper.find(html, '#workflow-refresh-sync').on('click', async (event) => {
      event.preventDefault();
      event.stopPropagation();

      const battleData = game.settings.get('swade-mass-battles', 'battleData');
      const canBroadcast = hasSocket();

      await sendBattleDataUpdate(battleData);
      await syncRoundResultUnderlays(battleData);
      scheduleRoundResultUnderlaySync();

      const workflowHud = getWorkflowHUD();
      if (workflowHud?.rendered) {
        workflowHud.render();
      }

      if (canBroadcast) {
        ui.notifications.info('Mass Battle state re-synced to connected players.');
      } else {
        ui.notifications.warn('socketlib is unavailable, so re-sync was applied locally only.');
      }
    });

    // ------------------------------------------------------------------
    // Workflow stage navigation
    // ------------------------------------------------------------------
    uiHelper.workflowButtonsByStage(html).on('click', async (event) => {
      const battleData = game.settings.get('swade-mass-battles', 'battleData');
      const targetStage = Number.parseInt(event.currentTarget.dataset.stage ?? '0', 10);
      if (!Number.isInteger(targetStage)) return;

      battleData.workflowStage = targetStage;
      await sendBattleDataUpdate(battleData);

      const isSetupStage = targetStage === 0;
      const isTacticalAdvantagesStage = targetStage === 1;
      const isTroopActionsStage = targetStage === 2;
      const isBattleRollsStage = targetStage === 3;
      const isMoraleChecksStage = targetStage === 4;
      const hudRoots = [getPlayerHUD(), getEnemyHUD()]
        .filter((nextHud) => nextHud?.rendered && nextHud?.element)
        .map((nextHud) => $(nextHud.element));

      for (const root of hudRoots) {
        uiHelper.troopDropZonesForStage(root).toggleClass('workflow-stage-setup', isSetupStage);
        uiHelper.tacticalAdvantagesStageElements(root).toggleClass('workflow-stage-tactical-advantages', isTacticalAdvantagesStage);
        root.toggleClass('workflow-stage-setup-active', isSetupStage);
        root.toggleClass('workflow-stage-troop-actions-active', isTroopActionsStage);
        root.toggleClass('workflow-stage-battle-rolls-active', isBattleRollsStage);
        root.toggleClass('workflow-stage-morale-checks-active', isMoraleChecksStage);
      }

      hud.render();
    });

    // ------------------------------------------------------------------
    // Accept a pending battle roll
    // ------------------------------------------------------------------
    uiHelper.workflowAcceptPendingRollButtons(html).on('click', async (event) => {
      if (!game.user?.isGM) return;

      const side = String(event.currentTarget.dataset.side || '');
      const rollId = String(event.currentTarget.dataset.rollId || '');
      if (!['player', 'enemy'].includes(side) || !rollId) return;

      const battleData = game.settings.get('swade-mass-battles', 'battleData');
      const pending = getPendingBattleRollsForSide(battleData, side);
      const chosen = pending.find((entry) => entry.id === rollId);
      if (!chosen) {
        ui.notifications.warn('That pending roll was not found.');
        return;
      }

      if (side === 'player') {
        battleData.playerBattleRollTotal = chosen.total;
        battleData.playerBattleRollSuccesses = chosen.successes;
      } else {
        battleData.enemyBattleRollTotal = chosen.total;
        battleData.enemyBattleRollSuccesses = chosen.successes;
      }

      await appendCurrentRoundResultHistoryIfReady(battleData);
      await sendBattleDataUpdate(battleData);

      const syncedBattleData = game.settings.get('swade-mass-battles', 'battleData');
      await syncRoundResultUnderlays(syncedBattleData);
      scheduleRoundResultUnderlaySync();

      hud.render();
      ui.notifications.info(`Accepted ${side} battlemaster roll ${chosen.total} (${chosen.successes} succ.).`);
    });

    // ------------------------------------------------------------------
    // Accept a pending morale roll
    // ------------------------------------------------------------------
    uiHelper.workflowAcceptPendingMoraleRollButtons(html).on('click', async (event) => {
      if (!game.user?.isGM) return;

      const side = String(event.currentTarget.dataset.side || '');
      const rollId = String(event.currentTarget.dataset.rollId || '');
      if (!['player', 'enemy'].includes(side) || !rollId) return;

      const battleData = game.settings.get('swade-mass-battles', 'battleData');
      const pending = getPendingMoraleRollsForSide(battleData, side);
      const chosen = pending.find((entry) => entry.id === rollId);
      if (!chosen) {
        ui.notifications.warn('That pending morale roll was not found.');
        return;
      }

      battleData[getMoraleCheckTotalKey(side)] = chosen.total;
      await sendBattleDataUpdate(battleData);

      hud.render();
      const outcome = getMoraleOutcomeData(chosen.total);
      ui.notifications.info(`${side === 'player' ? 'Player' : 'Enemy'} morale accepted: ${chosen.total}. ${outcome?.outcomeText || ''}`.trim());
    });

    // ------------------------------------------------------------------
    // Advance to next round
    // ------------------------------------------------------------------
    uiHelper.find(html, '#workflow-advance-next-turn').on('click', async () => {
      const battleData = game.settings.get('swade-mass-battles', 'battleData');

      const resetTroopsForNewTurn = (troops) => {
        if (!Array.isArray(troops)) return [];
        return troops.map((troop) => {
          if (typeof troop === 'string') return { uuid: troop, status: 'Did not participate' };
          if (troop && typeof troop === 'object') return { ...troop, status: 'Did not participate' };
          return troop;
        });
      };

      battleData.workflowStage = 0;
      battleData.battleRound = (Number.isInteger(battleData.battleRound) && battleData.battleRound > 0 ? battleData.battleRound : 1) + 1;
      battleData.playerBattleRollTotal = null;
      battleData.enemyBattleRollTotal = null;
      battleData.playerBattleRollSuccesses = null;
      battleData.enemyBattleRollSuccesses = null;
      battleData.playerPendingBattleRolls = [];
      battleData.enemyPendingBattleRolls = [];
      battleData.playerMoraleCheckTotal = null;
      battleData.enemyMoraleCheckTotal = null;
      battleData.playerPendingMoraleRolls = [];
      battleData.enemyPendingMoraleRolls = [];
      battleData.playerTroops = resetTroopsForNewTurn(battleData.playerTroops);
      battleData.enemyTroops = resetTroopsForNewTurn(battleData.enemyTroops);

      setPreserveRoundResultUnderlaysOnce(true);
      await sendBattleDataUpdate(battleData);

      const hudRoots = [getPlayerHUD(), getEnemyHUD()]
        .filter((nextHud) => nextHud?.rendered && nextHud?.element)
        .map((nextHud) => $(nextHud.element));

      for (const root of hudRoots) {
        uiHelper.troopDropZonesForStage(root).toggleClass('workflow-stage-setup', true);
        uiHelper.tacticalAdvantagesStageElements(root).toggleClass('workflow-stage-tactical-advantages', false);
        root.toggleClass('workflow-stage-setup-active', true);
        root.toggleClass('workflow-stage-troop-actions-active', false);
        root.toggleClass('workflow-stage-battle-rolls-active', false);
        root.toggleClass('workflow-stage-morale-checks-active', false);
      }

      const playerHUD = getPlayerHUD();
      const enemyHUD = getEnemyHUD();

      if (playerHUD?.rendered) {
        await playerHUD.loadTroops(playerHUD.element, 'player', battleData.playerTroops || []);
        await playerHUD.updateBattlemasterButtons(playerHUD.element, 'player');
        await playerHUD.updateBattlemasterButtons(playerHUD.element, 'enemy');
      }
      if (enemyHUD?.rendered) {
        await enemyHUD.loadTroops(enemyHUD.element, 'enemy', battleData.enemyTroops || []);
        await enemyHUD.updateBattlemasterButtons(enemyHUD.element, 'player');
        await enemyHUD.updateBattlemasterButtons(enemyHUD.element, 'enemy');
      }

      hud.render();
      ui.notifications.info(`Advanced to next round: now on Round ${battleData.battleRound}. Workflow reset, troop actions cleared, and battle roll totals/successes reset.`);
    });

    // ------------------------------------------------------------------
    // Reset round to Round 1
    // ------------------------------------------------------------------
    uiHelper.find(html, '#workflow-reset-round').on('click', async () => {
      const battleData = game.settings.get('swade-mass-battles', 'battleData');
      battleData.battleRound = 1;
      battleData.playerBattleRollTotal = null;
      battleData.enemyBattleRollTotal = null;
      battleData.playerBattleRollSuccesses = null;
      battleData.enemyBattleRollSuccesses = null;
      battleData.playerPendingBattleRolls = [];
      battleData.enemyPendingBattleRolls = [];
      battleData.playerMoraleCheckTotal = null;
      battleData.enemyMoraleCheckTotal = null;
      battleData.playerPendingMoraleRolls = [];
      battleData.enemyPendingMoraleRolls = [];
      battleData.playerRoundResultHistory = [];
      battleData.enemyRoundResultHistory = [];
      await sendBattleDataUpdate(battleData);
      await syncRoundResultUnderlays(battleData);
      scheduleRoundResultUnderlaySync();

      // Remove outcome cards in-place to avoid HUD re-render docking/position shifts.
      $('#mass-battles-hud-player .hud-round-result-underlay-host[data-side="player"]').html('');
      $('#mass-battles-hud-enemy .hud-round-result-underlay-host[data-side="enemy"]').html('');

      hud.render();
      ui.notifications.info('Round reset to 1 and round-result outcome cards cleared.');
    });
  }
}