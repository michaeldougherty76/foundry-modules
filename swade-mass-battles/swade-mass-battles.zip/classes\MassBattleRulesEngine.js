export class MassBattleRulesEngine {
  static getBattleRollSuccesses(battleData, side) {
    if (!battleData) return null;

    const successKey = side === 'player' ? 'playerBattleRollSuccesses' : 'enemyBattleRollSuccesses';
    const totalKey = side === 'player' ? 'playerBattleRollTotal' : 'enemyBattleRollTotal';

    if (Number.isFinite(battleData[successKey])) {
      return Number(battleData[successKey]);
    }

    if (Number.isFinite(battleData[totalKey])) {
      return Math.max(0, Math.floor(Number(battleData[totalKey]) / 4));
    }

    return null;
  }

  static getRoundResultHistoryKey(side) {
    return side === 'player' ? 'playerRoundResultHistory' : 'enemyRoundResultHistory';
  }

  static getRoundResultHistoryForSide(battleData, side) {
    const key = MassBattleRulesEngine.getRoundResultHistoryKey(side);
    const list = Array.isArray(battleData?.[key]) ? battleData[key] : [];
    return list
      .filter((entry) => Number.isInteger(entry?.round) && entry.round > 0 && typeof entry?.resultName === 'string')
      .slice()
      .sort((a, b) => a.round - b.round);
  }

  static formatSuccessLabel(value) {
    return value === 1 ? 'success' : 'successes';
  }

  static buildRoundResultDescriptorFromParts(sideName, sideSuccesses, otherName, otherSuccesses, resultName) {
    return `${sideName} scored ${sideSuccesses} ${MassBattleRulesEngine.formatSuccessLabel(sideSuccesses)} vs ${otherName}'s ${otherSuccesses} ${MassBattleRulesEngine.formatSuccessLabel(otherSuccesses)}. The result was a ${resultName.toLowerCase()}`;
  }

  static getRoundResultEffects(resultName) {
    switch (resultName) {
      case 'Victory':
        return [{ text: '(Nothing)', isNoIcon: true }];
      case 'Loss':
        return [{ text: '-2 Tokens' }];
      case 'Marginal Victory':
        return [{ text: '-1 Token' }];
      case 'Marginal Loss':
        return [{ text: '-2 Token' }];
      case 'Tie':
        return [{ text: '-1 Token' }];
      default:
        return [];
    }
  }

  static getRoundResultNameForSide(side, differential) {
    if (differential === 0) return 'Tie';

    const sideWon = (side === 'player' && differential > 0) || (side === 'enemy' && differential < 0);
    const absDiff = Math.abs(differential);

    if (sideWon) {
      return absDiff >= 2 ? 'Victory' : 'Marginal Victory';
    }

    return absDiff >= 2 ? 'Loss' : 'Marginal Loss';
  }

  static getRoundTokenDeltaForResult(resultName) {
    switch (resultName) {
      case 'Victory':
        return 0;
      case 'Marginal Victory':
        return -1;
      case 'Tie':
        return -1;
      case 'Marginal Loss':
        return -2;
      case 'Loss':
        return -2;
      default:
        return 0;
    }
  }

  static collectForceTokenModifierValues(entries, property) {
    if (!Array.isArray(entries)) return [];

    const values = [];
    for (const entry of entries) {
      if (typeof entry !== 'object' || !entry) continue;
      const value = Number(entry[property]);
      if (!Number.isFinite(value) || value === 0) continue;
      values.push(value);
    }

    return values;
  }

  static collectTroopForceTokenModifierValues(troops, troopStatuses, property) {
    if (!Array.isArray(troops)) return [];

    const values = [];
    for (const troop of troops) {
      if (typeof troop !== 'object' || !troop) continue;
      const statusName = troop.status || 'Did not participate';
      const statusDef = troopStatuses.find((status) => status.result === statusName);
      if (!statusDef) continue;
      const value = Number(statusDef[property]);
      if (!Number.isFinite(value) || value === 0) continue;
      values.push(value);
    }

    return values;
  }

  static aggregateTokenFlowFromValues(values) {
    const list = Array.isArray(values) ? values : [];
    let netDelta = 0;
    let losses = 0;
    let gains = 0;

    for (const value of list) {
      const numeric = Number(value);
      if (!Number.isFinite(numeric) || numeric === 0) continue;
      netDelta += numeric;
      if (numeric < 0) losses += Math.abs(numeric);
      if (numeric > 0) gains += numeric;
    }

    return {
      netDelta,
      losses,
      gains,
      lossOccurred: losses > 0
    };
  }

  static getStoredRoundTokenFlow(entry) {
    if (!entry || typeof entry !== 'object') return null;

    const hasStoredValues = Number.isFinite(Number(entry.tokenNetDelta))
      || Number.isFinite(Number(entry.tokenLosses))
      || Number.isFinite(Number(entry.tokenGains))
      || typeof entry.tokenLossOccurred === 'boolean';

    if (!hasStoredValues) return null;

    const netDelta = Number.isFinite(Number(entry.tokenNetDelta)) ? Number(entry.tokenNetDelta) : 0;
    const losses = Number.isFinite(Number(entry.tokenLosses))
      ? Math.max(0, Number(entry.tokenLosses))
      : Math.max(0, -netDelta);
    const gains = Number.isFinite(Number(entry.tokenGains))
      ? Math.max(0, Number(entry.tokenGains))
      : Math.max(0, netDelta);
    const lossOccurred = typeof entry.tokenLossOccurred === 'boolean'
      ? entry.tokenLossOccurred
      : losses > 0;

    return {
      netDelta,
      losses,
      gains,
      lossOccurred
    };
  }

  static getRoundTokenFlowSourceValues(battleData, side, roundResultName = null) {
    if (!battleData) return [];

    const troopStatuses = game.settings.get('swade-mass-battles', 'troopStatuses');
    const oppositeSide = side === 'player' ? 'enemy' : 'player';
    const ownAdvantages = side === 'player' ? (battleData.playerAdvantages || []) : (battleData.enemyAdvantages || []);
    const oppositeAdvantages = oppositeSide === 'player' ? (battleData.playerAdvantages || []) : (battleData.enemyAdvantages || []);
    const ownTroops = side === 'player' ? (battleData.playerTroops || []) : (battleData.enemyTroops || []);
    const oppositeTroops = oppositeSide === 'player' ? (battleData.playerTroops || []) : (battleData.enemyTroops || []);

    const values = [
      ...MassBattleRulesEngine.collectForceTokenModifierValues(ownAdvantages, 'forceTokenModifierSameSide'),
      ...MassBattleRulesEngine.collectForceTokenModifierValues(oppositeAdvantages, 'forceTokenModifierOppositeSide'),
      ...MassBattleRulesEngine.collectTroopForceTokenModifierValues(ownTroops, troopStatuses, 'forceTokenModifierSameSide'),
      ...MassBattleRulesEngine.collectTroopForceTokenModifierValues(oppositeTroops, troopStatuses, 'forceTokenModifierOppositeSide')
    ];

    if (typeof roundResultName === 'string' && roundResultName.trim().length) {
      values.push(MassBattleRulesEngine.getRoundTokenDeltaForResult(roundResultName));
    }

    return values;
  }

  static getRoundTokenFlowForResult(battleData, side, roundResultName) {
    return MassBattleRulesEngine.aggregateTokenFlowFromValues(
      MassBattleRulesEngine.getRoundTokenFlowSourceValues(battleData, side, roundResultName)
    );
  }

  static getRoundTokenFlowForSide(battleData, side, round = null) {
    if (!battleData) {
      return {
        netDelta: 0,
        losses: 0,
        gains: 0,
        lossOccurred: false
      };
    }

    const roundNumber = Number.isInteger(round) && round > 0
      ? round
      : (Number.isInteger(battleData.battleRound) && battleData.battleRound > 0 ? battleData.battleRound : 1);

    const roundHistory = MassBattleRulesEngine.getRoundResultHistoryForSide(battleData, side);
    const roundResult = roundHistory.find((entry) => Number(entry?.round) === roundNumber) || null;
    const storedFlow = MassBattleRulesEngine.getStoredRoundTokenFlow(roundResult);
    if (storedFlow) return storedFlow;

    const resultName = typeof roundResult?.resultName === 'string' ? roundResult.resultName : null;
    return MassBattleRulesEngine.aggregateTokenFlowFromValues(
      MassBattleRulesEngine.getRoundTokenFlowSourceValues(battleData, side, resultName)
    );
  }

  static getCumulativeTokenLossesForSide(battleData, side) {
    if (!battleData) return 0;

    const history = MassBattleRulesEngine.getRoundResultHistoryForSide(battleData, side);
    let cumulativeLosses = history.reduce((sum, entry) => {
      const storedFlow = MassBattleRulesEngine.getStoredRoundTokenFlow(entry);
      if (storedFlow) return sum + storedFlow.losses;

      const fallbackFlow = MassBattleRulesEngine.aggregateTokenFlowFromValues([
        MassBattleRulesEngine.getRoundTokenDeltaForResult(entry?.resultName)
      ]);
      return sum + fallbackFlow.losses;
    }, 0);

    const currentRound = Number.isInteger(battleData.battleRound) && battleData.battleRound > 0 ? battleData.battleRound : 1;
    const hasCurrentRoundHistory = history.some((entry) => Number(entry?.round) === currentRound);
    if (!hasCurrentRoundHistory) {
      cumulativeLosses += MassBattleRulesEngine.getRoundTokenFlowForSide(battleData, side, currentRound).losses;
    }

    return cumulativeLosses;
  }

  static calculateModifiers(side) {
    const battleData = game.settings.get('swade-mass-battles', 'battleData');
    const troopStatuses = game.settings.get('swade-mass-battles', 'troopStatuses');
    const oppositeSide = side === 'player' ? 'enemy' : 'player';

    const playerSize = battleData.playerForceSize || 0;
    const enemySize = battleData.enemyForceSize || 0;
    const forceMod = side === 'player' ? Math.max(0, playerSize - enemySize) : Math.max(0, enemySize - playerSize);

    const advantages = side === 'player' ? (battleData.playerAdvantages || []) : (battleData.enemyAdvantages || []);
    const advantagesMod = advantages.reduce((sum, adv) => {
      if (typeof adv === 'object' && adv.modifier !== undefined && !adv.result) {
        return sum + adv.modifier;
      }
      return sum + (adv.battleModifierSameSide || 0);
    }, 0);

    const oppositeAdvantages = oppositeSide === 'player' ? (battleData.playerAdvantages || []) : (battleData.enemyAdvantages || []);
    const oppositeAdvantagesMod = oppositeAdvantages.reduce((sum, adv) => {
      if (typeof adv === 'object' && adv.modifier !== undefined && !adv.result) {
        return sum;
      }
      return sum + (adv.battleModifierOppositeSide || 0);
    }, 0);

    const troops = side === 'player' ? (battleData.playerTroops || []) : (battleData.enemyTroops || []);
    const troopsMod = troops.reduce((sum, troop) => {
      if (typeof troop !== 'object') return sum;
      const statusName = troop.status || 'Did not participate';
      const statusDef = troopStatuses.find((status) => status.result === statusName);
      if (!statusDef) return sum;
      return sum + (statusDef.battleModifierSameSide || 0);
    }, 0);

    const oppositeTroops = oppositeSide === 'player' ? (battleData.playerTroops || []) : (battleData.enemyTroops || []);
    const oppositeTroopsMod = oppositeTroops.reduce((sum, troop) => {
      if (typeof troop !== 'object') return sum;
      const statusName = troop.status || 'Did not participate';
      const statusDef = troopStatuses.find((status) => status.result === statusName);
      if (!statusDef) return sum;
      return sum + (statusDef.battleModifierOppositeSide || 0);
    }, 0);

    const battleTotal = forceMod + advantagesMod + oppositeAdvantagesMod + troopsMod + oppositeTroopsMod;

    const moraleSameAdvantages = advantages.reduce((sum, adv) => {
      if (typeof adv === 'object' && adv.modifier !== undefined && !adv.result) {
        return sum;
      }
      return sum + (adv.moraleModifierSameSide || 0);
    }, 0);

    const moraleOppositeAdvantages = oppositeAdvantages.reduce((sum, adv) => {
      if (typeof adv === 'object' && adv.modifier !== undefined && !adv.result) {
        return sum;
      }
      return sum + (adv.moraleModifierOppositeSide || 0);
    }, 0);

    const moraleSameTroops = troops.reduce((sum, troop) => {
      if (typeof troop !== 'object') return sum;
      const statusName = troop.status || 'Did not participate';
      const statusDef = troopStatuses.find((status) => status.result === statusName);
      if (!statusDef) return sum;
      return sum + (statusDef.moraleModifierSameSide || 0);
    }, 0);

    const moraleOppositeTroops = oppositeTroops.reduce((sum, troop) => {
      if (typeof troop !== 'object') return sum;
      const statusName = troop.status || 'Did not participate';
      const statusDef = troopStatuses.find((status) => status.result === statusName);
      if (!statusDef) return sum;
      return sum + (statusDef.moraleModifierOppositeSide || 0);
    }, 0);

    const cumulativeTokenLossPenalty = -MassBattleRulesEngine.getCumulativeTokenLossesForSide(battleData, side);
    const moraleTotal = moraleSameAdvantages
      + moraleOppositeAdvantages
      + moraleSameTroops
      + moraleOppositeTroops
      + cumulativeTokenLossPenalty;

    return {
      battle: battleTotal,
      morale: moraleTotal
    };
  }
}