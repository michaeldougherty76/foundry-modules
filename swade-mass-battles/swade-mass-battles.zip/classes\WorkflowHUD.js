﻿import { WorkflowService } from './WorkflowService.js';
import { WorkflowContextBuilder } from './WorkflowContextBuilder.js';
import { WorkflowInteractionController } from './WorkflowInteractionController.js';

const { ApplicationV2, HandlebarsApplicationMixin } = foundry.applications.api;

function getWorkflowServices() {
  return game.modules.get('swade-mass-battles')?.api?.services ?? null;
}

/**
 * WorkflowHUD
 *
 * Workflow pane HUD for Mass Battles. Renders as a centered, non-popout, fixed-position
 * Application overlay containing all workflow-stage navigation buttons, battle-roll
 * acceptance controls, morale-check controls, round advancement, and round-reset actions.
 *
 * This class owns its own behavior and reads required collaborators from module APIs
 * and helper classes directly, rather than relying on init-time dependency injection.
 */
export class WorkflowHUD extends HandlebarsApplicationMixin(ApplicationV2) {
  // ---------------------------------------------------------------------------
  // Application options
  // ---------------------------------------------------------------------------

  static DEFAULT_OPTIONS = {
    window: { frame: false, positioned: false }
  };

  static PARTS = {
    content: { template: 'modules/swade-mass-battles/hbs/workflow-hud.hbs' }
  };

  // ---------------------------------------------------------------------------
  // Template data
  // ---------------------------------------------------------------------------

  async _prepareContext(options) {
    const services = getWorkflowServices();
    const contextBuilder = services?.workflowContextBuilder || new WorkflowContextBuilder();
    return contextBuilder.build({ options });
  }

  // ---------------------------------------------------------------------------
  // Listeners / button handlers
  // ---------------------------------------------------------------------------

  async _onRender(context, options) {
    await super._onRender(context, options);
    const html = $(this.element);
    const services = getWorkflowServices();
    const workflowHudAccess = services?.workflowHudAccess;
    const workflowService = services?.workflowService || new WorkflowService();
    const interactionController = services?.workflowInteractionController || new WorkflowInteractionController();
    await interactionController.onRender({
      hud: this,
      html,
      workflowMethods: {
        sendBattleDataUpdate: (battleData) => workflowService.sendBattleDataUpdate(battleData),
        getPendingBattleRollsForSide: (battleData, side) => workflowService.getPendingBattleRollsForSide(battleData, side),
        getPendingMoraleRollsForSide: (battleData, side) => workflowService.getPendingMoraleRollsForSide(battleData, side),
        getMoraleCheckTotalKey: (side) => workflowService.getMoraleCheckTotalKey(side),
        getMoraleOutcomeData: (total) => workflowService.getMoraleOutcomeData(total),
        appendCurrentRoundResultHistoryIfReady: (battleData) => workflowService.appendCurrentRoundResultHistoryIfReady(battleData),
        syncRoundResultUnderlays: (battleData) => workflowService.syncRoundResultUnderlays(battleData),
        scheduleRoundResultUnderlaySync: () => workflowService.scheduleRoundResultUnderlaySync(),
        rollOnMassBattleResultsTable: (side, index) => workflowService.rollOnMassBattleResultsTable(side, index),
        getPlayerHUD: () => workflowHudAccess?.getPlayerHUD?.() ?? null,
        getEnemyHUD: () => workflowHudAccess?.getEnemyHUD?.() ?? null,
        setPreserveRoundResultUnderlaysOnce: (value) => workflowService.setPreserveRoundResultUnderlaysOnce(value),
        hasSocket: () => workflowService.hasSocket(),
        getWorkflowHUD: () => workflowHudAccess?.getWorkflowHUD?.() ?? null
      }
    });
  }
}
