﻿export class BattleData {
  static MODULE_ID = 'swade-mass-battles';
  static SETTING_KEY = 'battleData';

  static defaultData() {
    return {
      workflowStage: 0,
      battleRound: 1,
      playerBattleRollTotal: null,
      enemyBattleRollTotal: null,
      playerBattleRollSuccesses: null,
      enemyBattleRollSuccesses: null,
      playerPendingBattleRolls: [],
      enemyPendingBattleRolls: [],
      playerMoraleCheckTotal: null,
      enemyMoraleCheckTotal: null,
      playerPendingMoraleRolls: [],
      enemyPendingMoraleRolls: [],
      playerRoundResultHistory: [],
      enemyRoundResultHistory: [],
      playerBattleMaster: null,
      enemyBattleMaster: null,
      playerForceSize: 0,
      enemyForceSize: 0,
      playerAdvantages: [],
      enemyAdvantages: [],
      playerTroops: [],
      enemyTroops: []
    };
  }

  static getRaw() {
    return game.settings.get(this.MODULE_ID, this.SETTING_KEY);
  }

  static get() {
    return new BattleData(this.getRaw());
  }

  static async set(nextData) {
    const data = nextData instanceof BattleData ? nextData.toObject() : foundry.utils.deepClone(nextData);
    await game.settings.set(this.MODULE_ID, this.SETTING_KEY, data);
  }

  static async update(mutator) {
    const current = BattleData.get();
    const maybeNext = await mutator(current);
    const next = maybeNext instanceof BattleData ? maybeNext : current;
    await BattleData.set(next);
    return next;
  }

  static async ensureDefaults() {
    const existing = this.getRaw() || {};
    const normalized = foundry.utils.mergeObject(this.defaultData(), foundry.utils.deepClone(existing), { inplace: false });
    if (!foundry.utils.objectsEqual(existing, normalized)) {
      await this.set(normalized);
    }
    return normalized;
  }

  constructor(data = {}) {
    const defaults = BattleData.defaultData();
    this.data = foundry.utils.mergeObject(defaults, foundry.utils.deepClone(data), { inplace: false });
  }

  toObject() {
    return foundry.utils.deepClone(this.data);
  }

  clone() {
    return new BattleData(this.toObject());
  }

  get(key) {
    return this.data[key];
  }

  set(key, value) {
    this.data[key] = value;
    return this;
  }
}
