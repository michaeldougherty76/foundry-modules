import { MassBattleRulesEngine } from './MassBattleRulesEngine.js';
import { WorkflowService } from './WorkflowService.js';

export class WorkflowContextBuilder {
  constructor({ rulesEngine = MassBattleRulesEngine, workflowService = new WorkflowService({ rulesEngine }) } = {}) {
    this.rulesEngine = rulesEngine;
    this.workflowService = workflowService;
  }

  static getStageConfigs() {
    return {
      0: {
        instructions: 'Please set the Battlemaster and add any combatants that will be participating in the Mass Battle this round.',
        beginNext: true,
        nextRoundNext: false,
        troopActionsNext: false,
        battleRollsNext: false,
        moraleChecksNext: false
      },
      1: {
        instructions: 'Define Tactical Advantages for this round before moving forward in the workflow.',
        beginNext: false,
        nextRoundNext: true,
        troopActionsNext: false,
        battleRollsNext: false,
        moraleChecksNext: false
      },
      2: {
        instructions: 'Players state their actions and roll their skills. Bestow a Battle Plan bonus if necessary. Make sure you have their results set so that bonuses can be applied on the next stage.',
        beginNext: false,
        nextRoundNext: false,
        troopActionsNext: true,
        battleRollsNext: false,
        moraleChecksNext: false
      },
      3: {
        instructions: 'Battlemasters roll their adjusted battle rolls against each other to determine overall success for the round. Roll using the buttons here to maintain a tie-in to this workflow.',
        beginNext: false,
        nextRoundNext: false,
        troopActionsNext: false,
        battleRollsNext: true,
        moraleChecksNext: false
      },
      4: {
        instructions: 'If necessary, any side required to do so, makes their morale/Spirit check now with any appropriate modifiers.',
        beginNext: false,
        nextRoundNext: false,
        troopActionsNext: false,
        battleRollsNext: false,
        moraleChecksNext: true
      }
    };
  }

  async build() {
    const battleData = game.settings.get('swade-mass-battles', 'battleData');
    const workflowStage = Number.isInteger(battleData.workflowStage) ? battleData.workflowStage : 0;
    const battleRound = Number.isInteger(battleData.battleRound) && battleData.battleRound > 0 ? battleData.battleRound : 1;
    const stageConfigs = WorkflowContextBuilder.getStageConfigs();
    const activeStage = stageConfigs[workflowStage] || stageConfigs[0];

    const playerBattlemasterActor = battleData.playerBattleMaster ? await fromUuid(battleData.playerBattleMaster) : null;
    const enemyBattlemasterActor = battleData.enemyBattleMaster ? await fromUuid(battleData.enemyBattleMaster) : null;

    const playerBattlemaster = playerBattlemasterActor ? {
      name: playerBattlemasterActor.name,
      img: this.workflowService.getActorTokenImage(playerBattlemasterActor)
    } : {
      name: 'Player Battlemaster',
      img: 'icons/svg/mystery-man.svg'
    };

    const enemyBattlemaster = enemyBattlemasterActor ? {
      name: enemyBattlemasterActor.name,
      img: this.workflowService.getActorTokenImage(enemyBattlemasterActor)
    } : {
      name: 'Enemy Battlemaster',
      img: 'icons/svg/mystery-man.svg'
    };

    const hasPlayerBattleRollTotal = Number.isFinite(battleData.playerBattleRollTotal);
    const hasEnemyBattleRollTotal = Number.isFinite(battleData.enemyBattleRollTotal);
    const playerPendingBattleRolls = this.workflowService.getPendingBattleRollsForSide(battleData, 'player');
    const enemyPendingBattleRolls = this.workflowService.getPendingBattleRollsForSide(battleData, 'enemy');
    const playerNeedsMoraleCheck = this.workflowService.sideNeedsMoraleCheck(battleData, 'player');
    const enemyNeedsMoraleCheck = this.workflowService.sideNeedsMoraleCheck(battleData, 'enemy');
    const hasAnyMoraleChecks = playerNeedsMoraleCheck || enemyNeedsMoraleCheck;
    const playerPendingMoraleRolls = playerNeedsMoraleCheck ? this.workflowService.getPendingMoraleRollsForSide(battleData, 'player') : [];
    const enemyPendingMoraleRolls = enemyNeedsMoraleCheck ? this.workflowService.getPendingMoraleRollsForSide(battleData, 'enemy') : [];
    const playerMoraleCheckTotal = Number.isFinite(battleData.playerMoraleCheckTotal) ? Number(battleData.playerMoraleCheckTotal) : null;
    const enemyMoraleCheckTotal = Number.isFinite(battleData.enemyMoraleCheckTotal) ? Number(battleData.enemyMoraleCheckTotal) : null;
    const playerMoraleOutcome = this.workflowService.getMoraleOutcomeData(playerMoraleCheckTotal);
    const enemyMoraleOutcome = this.workflowService.getMoraleOutcomeData(enemyMoraleCheckTotal);
    const playerBattleRollSuccesses = this.rulesEngine.getBattleRollSuccesses(battleData, 'player');
    const enemyBattleRollSuccesses = this.rulesEngine.getBattleRollSuccesses(battleData, 'enemy');
    const hasPlayerBattleRollSuccesses = Number.isFinite(playerBattleRollSuccesses);
    const hasEnemyBattleRollSuccesses = Number.isFinite(enemyBattleRollSuccesses);

    const hasRoundOutcome = hasPlayerBattleRollSuccesses && hasEnemyBattleRollSuccesses;
    let roundOutcomeClass = 'workflow-round-outcome workflow-round-outcome--pending';
    let roundOutcomeTitle = 'Awaiting Result';
    let roundOutcomeDetail = 'Record or accept both battlemaster battle rolls to determine the victor.';

    if (hasRoundOutcome) {
      const differential = playerBattleRollSuccesses - enemyBattleRollSuccesses;
      const absDifferential = Math.abs(differential);

      if (absDifferential === 0) {
        roundOutcomeClass = 'workflow-round-outcome workflow-round-outcome--tie';
        roundOutcomeTitle = 'Tie';
        roundOutcomeDetail = `Both sides achieved ${playerBattleRollSuccesses} successes.`;
      } else {
        const winnerSide = differential > 0 ? 'player' : 'enemy';
        const winnerName = winnerSide === 'player' ? playerBattlemaster.name : enemyBattlemaster.name;

        if (absDifferential === 1) {
          roundOutcomeClass = `workflow-round-outcome workflow-round-outcome--marginal workflow-round-outcome--${winnerSide}`;
          roundOutcomeTitle = `${winnerName}: Marginal Victory`;
          roundOutcomeDetail = `Won by ${absDifferential} success.`;
        } else {
          roundOutcomeClass = `workflow-round-outcome workflow-round-outcome--victory workflow-round-outcome--${winnerSide}`;
          roundOutcomeTitle = `${winnerName}: Victory`;
          roundOutcomeDetail = `Won by ${absDifferential} successes.`;
        }
      }
    }

    return {
      workflowStage,
      battleRound,
      isSetupStage: workflowStage === 0,
      isBattleRollsStage: workflowStage === 3,
      isTroopActionsStage: workflowStage === 2,
      isMoraleChecksStage: workflowStage === 4,
      hasKeptBattleRolls: hasPlayerBattleRollTotal || hasEnemyBattleRollTotal,
      hasPlayerBattleRollTotal,
      hasEnemyBattleRollTotal,
      hasPlayerPendingBattleRolls: playerPendingBattleRolls.length > 0,
      hasEnemyPendingBattleRolls: enemyPendingBattleRolls.length > 0,
      playerPendingBattleRolls,
      enemyPendingBattleRolls,
      hasAnyMoraleChecks,
      playerNeedsMoraleCheck,
      enemyNeedsMoraleCheck,
      hasPlayerPendingMoraleRolls: playerPendingMoraleRolls.length > 0,
      hasEnemyPendingMoraleRolls: enemyPendingMoraleRolls.length > 0,
      playerPendingMoraleRolls,
      enemyPendingMoraleRolls,
      hasPlayerMoraleCheckTotal: Number.isFinite(playerMoraleCheckTotal),
      hasEnemyMoraleCheckTotal: Number.isFinite(enemyMoraleCheckTotal),
      playerMoraleCheckTotal,
      enemyMoraleCheckTotal,
      playerMoraleOutcomeClass: playerMoraleOutcome?.outcomeClass || null,
      playerMoraleOutcomeText: playerMoraleOutcome?.outcomeText || null,
      enemyMoraleOutcomeClass: enemyMoraleOutcome?.outcomeClass || null,
      enemyMoraleOutcomeText: enemyMoraleOutcome?.outcomeText || null,
      hasPlayerBattleRollSuccesses,
      hasEnemyBattleRollSuccesses,
      playerBattleRollTotal: hasPlayerBattleRollTotal ? battleData.playerBattleRollTotal : null,
      enemyBattleRollTotal: hasEnemyBattleRollTotal ? battleData.enemyBattleRollTotal : null,
      playerBattleRollSuccesses: hasPlayerBattleRollSuccesses ? playerBattleRollSuccesses : null,
      enemyBattleRollSuccesses: hasEnemyBattleRollSuccesses ? enemyBattleRollSuccesses : null,
      hasRoundOutcome,
      roundOutcomeClass,
      roundOutcomeTitle,
      roundOutcomeDetail,
      playerBattlemaster,
      enemyBattlemaster,
      isGM: Boolean(game.user?.isGM),
      workflowInstructions: activeStage.instructions,
      beginButtonClass: activeStage.beginNext ? 'workflow-button workflow-button--next' : 'workflow-button',
      nextRoundButtonClass: activeStage.nextRoundNext ? 'workflow-button workflow-button--next' : 'workflow-button',
      troopActionsButtonClass: activeStage.troopActionsNext ? 'workflow-button workflow-button--next' : 'workflow-button',
      battleRollsButtonClass: activeStage.battleRollsNext ? 'workflow-button workflow-button--next' : 'workflow-button',
      moraleChecksButtonClass: activeStage.moraleChecksNext ? 'workflow-button workflow-button--next' : 'workflow-button'
    };
  }
}