import { MassBattleRulesEngine } from './MassBattleRulesEngine.js';
import { RoundResultPresenter } from './RoundResultPresenter.js';

export class HudContextBuilder {
  static getTokenImage(side) {
    return side === 'player'
      ? 'modules/swade-mass-battles/images/BattleForceTokenGood.png'
      : 'modules/swade-mass-battles/images/BattleForceTokenEvil.png';
  }

  static async getBattlemasterData(uuid) {
    let battlemaster = null;
    let battleDieImage = 'systems/swade/assets/dice/d4-grey.svg';
    let moraleDieImage = 'systems/swade/assets/dice/d4-grey.svg';

    if (!uuid) {
      return {
        battlemaster,
        battleDieImage,
        moraleDieImage
      };
    }

    const actor = await fromUuid(uuid);
    if (!actor) {
      return {
        battlemaster,
        battleDieImage,
        moraleDieImage
      };
    }

    const battleSkillItem = actor.items.find((item) => item.type === 'skill' && item.name === 'Battle');
    const battleDie = battleSkillItem?.system?.die?.sides || 4;
    const spiritDie = actor.system?.attributes?.spirit?.die?.sides || 4;

    battlemaster = {
      name: actor.name,
      img: actor.img,
      uuid: actor.uuid
    };
    battleDieImage = `systems/swade/assets/dice/d${battleDie}-grey.svg`;
    moraleDieImage = `systems/swade/assets/dice/d${spiritDie}-grey.svg`;

    return {
      battlemaster,
      battleDieImage,
      moraleDieImage
    };
  }

  static async build({ side, buildModifierStickers, rulesEngine = MassBattleRulesEngine, roundResultPresenter = null }) {
    const presenter = roundResultPresenter || new RoundResultPresenter({ rulesEngine });
    const battleData = game.settings.get('swade-mass-battles', 'battleData');

    const playerBattlemasterData = await HudContextBuilder.getBattlemasterData(battleData.playerBattleMaster);
    const enemyBattlemasterData = await HudContextBuilder.getBattlemasterData(battleData.enemyBattleMaster);

    const playerModifiers = rulesEngine.calculateModifiers('player');
    const enemyModifiers = rulesEngine.calculateModifiers('enemy');
    const playerBattleMod = playerModifiers.battle >= 0 ? `+${playerModifiers.battle}` : `${playerModifiers.battle}`;
    const playerMoraleMod = playerModifiers.morale >= 0 ? `+${playerModifiers.morale}` : `${playerModifiers.morale}`;
    const enemyBattleMod = enemyModifiers.battle >= 0 ? `+${enemyModifiers.battle}` : `${enemyModifiers.battle}`;
    const enemyMoraleMod = enemyModifiers.morale >= 0 ? `+${enemyModifiers.morale}` : `${enemyModifiers.morale}`;
    const playerForceSize = battleData.playerForceSize || 0;
    const enemyForceSize = battleData.enemyForceSize || 0;
    const forceDiff = playerForceSize - enemyForceSize;
    const battleRound = Number.isInteger(battleData.battleRound) && battleData.battleRound > 0 ? battleData.battleRound : 1;

    const makeForceEffectCardData = (effectSide, tokenImage, bonus) => ({
      cardClass: 'force-effect-card',
      compactClass: 'force-compact',
      expandedClass: 'force-expanded',
      hasButtons: false,
      isForceEffect: true,
      side: effectSide,
      title: 'Forces Bonus',
      description: 'The forces on this side outnumber the other side.',
      hasEffects: true,
      tokenImage,
      sameSideEffects: [{ text: `+${bonus} Battle`, textCompact: `+${bonus} Bat.` }],
      modifierStickers: buildModifierStickers(effectSide, { battleModifierSameSide: bonus })
    });

    const playerBonus = Math.abs(forceDiff);
    const enemyBonus = Math.abs(forceDiff);
    const playerTokenImage = HudContextBuilder.getTokenImage('player');
    const enemyTokenImage = HudContextBuilder.getTokenImage('enemy');

    const playerHasForceEffect = forceDiff > 0;
    const enemyHasForceEffect = forceDiff < 0;

    const playerRoundSuccesses = rulesEngine.getBattleRollSuccesses(battleData, 'player');
    const enemyRoundSuccesses = rulesEngine.getBattleRollSuccesses(battleData, 'enemy');
    const hasPlayerSuccesses = Number.isFinite(playerRoundSuccesses);
    const hasEnemySuccesses = Number.isFinite(enemyRoundSuccesses);
    const hasRoundOutcome = hasPlayerSuccesses && hasEnemySuccesses;

    let playerRoundResultEffectData = null;
    let enemyRoundResultEffectData = null;

    if (hasRoundOutcome) {
      const differential = playerRoundSuccesses - enemyRoundSuccesses;
      const playerResultName = rulesEngine.getRoundResultNameForSide('player', differential);
      const enemyResultName = rulesEngine.getRoundResultNameForSide('enemy', differential);

      playerRoundResultEffectData = presenter.buildCurrentRoundResultEffectData('player', playerResultName, playerTokenImage, battleRound);
      enemyRoundResultEffectData = presenter.buildCurrentRoundResultEffectData('enemy', enemyResultName, enemyTokenImage, battleRound);
    }

    const playerResultHistory = rulesEngine.getRoundResultHistoryForSide(battleData, 'player');
    const enemyResultHistory = rulesEngine.getRoundResultHistoryForSide(battleData, 'enemy');
    const playerRoundResultEffectDataList = playerResultHistory.map((entry) => presenter.buildRoundResultEffectDataFromEntry('player', entry));
    const enemyRoundResultEffectDataList = enemyResultHistory.map((entry) => presenter.buildRoundResultEffectDataFromEntry('enemy', entry));

    return {
      side,
      isPlayer: side === 'player',
      isEnemy: side === 'enemy',
      isSetupStage: (battleData.workflowStage ?? 0) === 0,
      isTacticalAdvantagesStage: (battleData.workflowStage ?? 0) === 1,
      playerBattlemaster: playerBattlemasterData.battlemaster,
      enemyBattlemaster: enemyBattlemasterData.battlemaster,
      playerForceSize,
      enemyForceSize,
      playerHasForceEffect,
      enemyHasForceEffect,
      playerForceEffectData: makeForceEffectCardData('player', playerTokenImage, playerBonus),
      enemyForceEffectData: makeForceEffectCardData('enemy', enemyTokenImage, enemyBonus),
      hasRoundOutcome,
      playerRoundResultEffectData,
      enemyRoundResultEffectData,
      playerRoundResultEffectDataList,
      enemyRoundResultEffectDataList,
      playerBattleMod,
      playerMoraleMod,
      enemyBattleMod,
      enemyMoraleMod,
      playerBattleDieImage: playerBattlemasterData.battleDieImage,
      playerMoraleDieImage: playerBattlemasterData.moraleDieImage,
      enemyBattleDieImage: enemyBattlemasterData.battleDieImage,
      enemyMoraleDieImage: enemyBattlemasterData.moraleDieImage
    };
  }
}