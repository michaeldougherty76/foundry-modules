export const MODULE_ID = 'swade-tactical';

export const TACTICAL_BANNER_ID = `${MODULE_ID}-mode-banner`;
export const TACTICAL_MODE_SELECTOR_ID = `${MODULE_ID}-mode-selector`;

export const FLAGS = {
  tacticalState: 'tacticalState'
};

export const TEMPLATES = {
  tacticalPanel: `modules/${MODULE_ID}/templates/tactical-panel.hbs`
};