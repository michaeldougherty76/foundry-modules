import { MODULE_ID } from './constants.js';
import { TacticalPanel } from './apps/TacticalPanel.js';
import { TacticalModeController } from './TacticalModeController.js';

const tacticalModeController = new TacticalModeController();

export function registerSettings() {
  game.settings.register(MODULE_ID, 'enableTacticalOverlay', {
    name: 'SWADE Tactical.EnableOverlay',
    hint: 'SWADE Tactical.EnableOverlayHint',
    scope: 'world',
    config: true,
    type: Boolean,
    default: true
  });
}

export function registerKeybindings() {
  game.keybindings.register(MODULE_ID, 'toggleTacticalMode', {
    name: 'SWADE Tactical.ToggleMode',
    hint: 'SWADE Tactical.ToggleModeHint',
    editable: [
      {
        key: 'Backquote'
      }
    ],
    onDown: () => {
      if (isTextInputFocused()) return false;
      tacticalModeController.toggle();
      return true;
    },
    restricted: false,
    precedence: CONST.KEYBINDING_PRECEDENCE.PRIORITY
  });
}

export function initializeApi() {
  game.swadeTactical = {
    TacticalPanel,
    tacticalModeController,
    toggleMode: () => tacticalModeController.toggle(),
    activateMode: () => tacticalModeController.activate(),
    deactivateMode: () => tacticalModeController.deactivate(),
    openPanel: () => {
      const panel = new TacticalPanel();
      return panel.render(true);
    }
  };
}

export function registerHooks() {
  Hooks.on('getSceneControlButtons', controls => {
    if (!game.user?.isGM) return;

    const tokenControls = controls.find(control => control.name === 'token');
    if (!tokenControls) return;

    tokenControls.tools.push({
      name: 'swade-tactical-panel',
      title: 'SWADE Tactical.OpenPanel',
      icon: 'fas fa-chess-board',
      button: true,
      onClick: () => game.swadeTactical.openPanel()
    });
  });

  Hooks.on('canvasReady', () => {
    tacticalModeController.refresh();
  });

  Hooks.on('createToken', () => {
    tacticalModeController.refresh();
  });

  Hooks.on('deleteToken', () => {
    tacticalModeController.refresh();
  });

  Hooks.on('updateToken', () => {
    tacticalModeController.refresh();
  });

  Hooks.on('refreshToken', token => {
    tacticalModeController.refreshToken(token);
  });

  Hooks.on('controlToken', () => {
    tacticalModeController.refresh();
  });
}

function isTextInputFocused() {
  const activeElement = document.activeElement;
  if (!activeElement) return false;

  const tagName = activeElement.tagName?.toLowerCase();
  return activeElement.isContentEditable || ['input', 'textarea', 'select'].includes(tagName);
}