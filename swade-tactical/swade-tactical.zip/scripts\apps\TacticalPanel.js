import { MODULE_ID, TEMPLATES } from '../constants.js';

export class TacticalPanel extends Application {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: `${MODULE_ID}-panel`,
      title: game.i18n.localize('SWADE Tactical.PanelTitle'),
      template: TEMPLATES.tacticalPanel,
      popOut: true,
      width: 420,
      height: 'auto',
      resizable: true,
      classes: [MODULE_ID, 'swade-tactical-panel']
    });
  }

  async getData() {
    return {
      moduleId: MODULE_ID,
      overlayEnabled: game.settings.get(MODULE_ID, 'enableTacticalOverlay'),
      combatActive: Boolean(game.combat?.started),
      sceneName: canvas.scene?.name ?? game.i18n.localize('SWADE Tactical.NoScene')
    };
  }
}