import { registerSettings, registerKeybindings, initializeApi, registerHooks } from './scripts/main.js';

Hooks.once('init', () => {
  registerSettings();
  registerKeybindings();
  initializeApi();
});

Hooks.once('ready', () => {
  registerHooks();
  console.log('SWADE Tactical | Ready');
});