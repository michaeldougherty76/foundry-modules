# SWADE Tactical

A starter Foundry VTT module scaffold for tactical tools in the SWADE system.

## Included

- Foundry module manifest
- ES module entrypoint
- Localized setting registration
- Starter application panel
- Basic Handlebars template and CSS

## Next Steps

- Add tactical scene or combat hooks
- Build actor or token utilities
- Expand the panel into GM and player workflows