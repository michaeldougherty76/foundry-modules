import { MODULE_ID, TACTICAL_BANNER_ID, TACTICAL_MODE_SELECTOR_ID } from './constants.js';

const FRIENDLY_DISPOSITION = CONST.TOKEN_DISPOSITIONS.FRIENDLY;
const HOSTILE_DISPOSITION = CONST.TOKEN_DISPOSITIONS.HOSTILE;
const OVERLAY_NAME = `${MODULE_ID}-friendly-range-overlay`;
const GANGUP_LAYER_NAME = `${MODULE_ID}-gangup-layer`;
const RANGE_FILL_ALPHA = 0.12;
const RANGE_LINE_ALPHA = 0.95;
const RANGE_LINE_WIDTH = 3;
const RANGE_INCHES = 1;
const OVERLAP_THRESHOLD = 2;
const GANGUP_LINE_COLOR = 0x4cff88;
const HOSTILE_GANGUP_LINE_COLOR = 0xff4c4c;
const GANGUP_LINE_ALPHA = 0.75;
const GANGUP_LINE_WIDTH = 3;
const MODE_GANGUP = 'gangup';
const MODE_RANGEFINDER = 'rangefinder';
const AVAILABLE_MODES = [MODE_GANGUP, MODE_RANGEFINDER];
const DISPOSITION_STYLES = {
  [FRIENDLY_DISPOSITION]: {
    color: 0x4cff88
  },
  [HOSTILE_DISPOSITION]: {
    color: 0xff4c4c
  }
};

export class TacticalModeController {
  constructor() {
    this.active = false;
    this.mode = MODE_GANGUP;
    this.onlyShowSelectedBonuses = false;
  }

  toggle() {
    return this.active ? this.deactivate() : this.activate();
  }

  activate() {
    if (!game.settings.get(MODULE_ID, 'enableTacticalOverlay')) {
      ui.notifications.warn(game.i18n.localize('SWADE Tactical.ModeDisabled'));
      return false;
    }

    if (!canvas?.ready || !canvas.scene) {
      ui.notifications.warn(game.i18n.localize('SWADE Tactical.ModeUnavailable'));
      return false;
    }

    this.active = true;
    this.showBanner();
    this.showModeSelector();
    this.refreshVisuals();
    return true;
  }

  deactivate() {
    this.active = false;
    this.hideBanner();
    this.hideModeSelector();
    this.clearTokenOverlays();
    this.clearGangUpLines();
    return true;
  }

  refresh() {
    if (!this.active) return;
    this.showBanner();
    this.showModeSelector();
    this.refreshVisuals();
  }

  refreshToken(token) {
    if (!this.active) return;
    this.syncTokenOverlay(token);
    this.updateGangUpLines();
  }

  showBanner() {
    const banner = this.#ensureBanner();
    banner.textContent = game.i18n.localize('SWADE Tactical.ModeTitle');
    banner.classList.add('is-visible');
  }

  hideBanner() {
    const banner = document.getElementById(TACTICAL_BANNER_ID);
    banner?.classList.remove('is-visible');
  }

  setMode(mode) {
    if (!AVAILABLE_MODES.includes(mode)) return;

    this.mode = mode;
    this.#updateModeSelectorState();
    this.#updateModeOptionState();
    if (!this.active) return;

    this.refreshVisuals();
  }

  showModeSelector() {
    const selector = this.#ensureModeSelector();
    selector.classList.add('is-visible');
    this.#updateModeSelectorState();
    this.#updateModeOptionState();
  }

  hideModeSelector() {
    const selector = document.getElementById(TACTICAL_MODE_SELECTOR_ID);
    selector?.classList.remove('is-visible');
  }

  refreshVisuals() {
    if (this.#isGangupMode()) {
      this.drawTokenRanges();
      this.updateGangUpLines();
      return;
    }

    this.clearTokenOverlays();
    this.clearGangUpLines();
  }

  drawTokenRanges() {
    if (!canvas?.ready || !canvas.tokens) return;

    const radiusPixels = this.#getOneInchRadiusPixels();

    if (!Number.isFinite(radiusPixels) || radiusPixels <= 0) {
      this.clearTokenOverlays();
      return;
    }

    for (const token of canvas.tokens.placeables) {
      this.syncTokenOverlay(token, radiusPixels);
    }
  }

  syncTokenOverlay(token, radiusPixels = this.#getOneInchRadiusPixels()) {
    if (!token) return;

    const style = DISPOSITION_STYLES[token.document?.disposition];

    const shouldShowOverlay = this.active
      && this.#isGangupMode()
      && Number.isFinite(radiusPixels)
      && radiusPixels > 0
      && Boolean(style)
      && token.visible;

    if (!shouldShowOverlay) {
      this.#removeOverlayFromToken(token);
      return;
    }

    const overlay = this.#ensureOverlayForToken(token);
    overlay.clear();
    overlay.lineStyle(RANGE_LINE_WIDTH, style.color, RANGE_LINE_ALPHA);
    overlay.beginFill(style.color, RANGE_FILL_ALPHA);
    overlay.drawCircle(token.w / 2, token.h / 2, radiusPixels);
    overlay.endFill();
  }

  clearTokenOverlays() {
    if (!canvas?.tokens) return;

    for (const token of canvas.tokens.placeables) {
      this.#removeOverlayFromToken(token);
    }
  }

  #ensureBanner() {
    let banner = document.getElementById(TACTICAL_BANNER_ID);
    if (!banner) {
      banner = document.createElement('div');
      banner.id = TACTICAL_BANNER_ID;
      document.body.appendChild(banner);
    }

    return banner;
  }

  #ensureOverlayForToken(token) {
    let overlay = token.getChildByName?.(OVERLAY_NAME);
    if (!overlay || overlay.destroyed) {
      overlay = new PIXI.Graphics();
      overlay.name = OVERLAY_NAME;
      overlay.eventMode = 'none';
      token.addChild(overlay);
    }

    return overlay;
  }

  #removeOverlayFromToken(token) {
    const overlay = token?.getChildByName?.(OVERLAY_NAME);
    if (!overlay) return;

    overlay.clear();
    overlay.parent?.removeChild(overlay);
    overlay.destroy();
  }

  updateGangUpLines() {
    if (!this.active || !this.#isGangupMode() || !canvas?.tokens) {
      this.clearGangUpLines();
      return;
    }

    const radiusPixels = this.#getOneInchRadiusPixels();
    if (!Number.isFinite(radiusPixels) || radiusPixels <= 0) {
      this.clearGangUpLines();
      return;
    }

    const friendlyTokens = canvas.tokens.placeables.filter(token =>
      token?.document?.disposition === FRIENDLY_DISPOSITION && token.visible
    );

    const hostileTokens = canvas.tokens.placeables.filter(token =>
      token?.document?.disposition === HOSTILE_DISPOSITION && token.visible
    );

    const overlapDistance = radiusPixels * 2;
    const segments = [
      ...this.#collectGangUpSegments({
        attackers: friendlyTokens,
        defenders: hostileTokens,
        overlapDistance,
        lineColor: GANGUP_LINE_COLOR,
        attackDisposition: FRIENDLY_DISPOSITION
      }),
      ...this.#collectGangUpSegments({
        attackers: hostileTokens,
        defenders: friendlyTokens,
        overlapDistance,
        lineColor: HOSTILE_GANGUP_LINE_COLOR,
        attackDisposition: HOSTILE_DISPOSITION
      })
    ];

    const filteredSegments = this.#filterSegmentsForSelection(segments);
    this.#drawGangUpSegments(filteredSegments);
  }

  #filterSegmentsForSelection(segments) {
    if (!this.onlyShowSelectedBonuses) return segments;

    const selectedIds = new Set((canvas?.tokens?.controlled ?? []).map(token => token.id));
    if (selectedIds.size === 0) return [];

    return segments.filter(segment => {
      return selectedIds.has(segment.attackerId) || selectedIds.has(segment.defenderId);
    });
  }

  #collectGangUpSegments({ attackers, defenders, overlapDistance, lineColor, attackDisposition }) {
    const segments = [];

    for (const defenderToken of defenders) {
      const overlappingAttackers = attackers.filter(attackerToken => {
        return this.#tokenDistance(attackerToken, defenderToken) < overlapDistance;
      });

      if (overlappingAttackers.length < OVERLAP_THRESHOLD) continue;

      const gangUpBonus = overlappingAttackers.length - 1;
      const supportingDefenders = defenders.filter(otherDefender => {
        if (otherDefender.id === defenderToken.id) return false;
        return this.#tokenDistance(otherDefender, defenderToken) < overlapDistance;
      });

      for (const attackerToken of overlappingAttackers) {
        const hasInterference = supportingDefenders.some(otherDefender => {
          return this.#tokenDistance(otherDefender, attackerToken) < overlapDistance;
        });

        const adjustedBonus = Math.max(0, gangUpBonus - (hasInterference ? 1 : 0));
        if (adjustedBonus <= 0) continue;

        segments.push({
          start: attackerToken.center,
          end: defenderToken.center,
          bonus: adjustedBonus,
          lineColor,
          attackDisposition,
          attackerId: attackerToken.id,
          defenderId: defenderToken.id
        });
      }
    }

    return segments;
  }

  clearGangUpLines() {
    const layer = this.#getGangUpLayer();
    if (!layer) return;

    this.#clearGangUpLayer(layer);
    layer.parent?.removeChild(layer);
    layer.destroy({ children: true });
  }

  #drawGangUpSegments(segments) {
    const layer = this.#ensureGangUpLayer();
    this.#clearGangUpLayer(layer);

    const graphics = new PIXI.Graphics();
    graphics.name = 'lines';
    graphics.eventMode = 'none';
    layer.addChild(graphics);

    const labels = new PIXI.Container();
    labels.name = 'labels';
    labels.eventMode = 'none';
    layer.addChild(labels);

    const labelPairs = new Map();

    for (const segment of segments) {
      graphics.lineStyle(GANGUP_LINE_WIDTH, segment.lineColor, GANGUP_LINE_ALPHA);
      graphics.moveTo(segment.start.x, segment.start.y);
      graphics.lineTo(segment.end.x, segment.end.y);

      const midX = (segment.start.x + segment.end.x) / 2;
      const midY = (segment.start.y + segment.end.y) / 2;

      const pairKey = this.#getPairKey(segment.attackerId, segment.defenderId);
      const entry = labelPairs.get(pairKey) ?? { midX, midY, friendlyBonus: null, hostileBonus: null };
      if (segment.attackDisposition === FRIENDLY_DISPOSITION) {
        entry.friendlyBonus = segment.bonus;
      } else if (segment.attackDisposition === HOSTILE_DISPOSITION) {
        entry.hostileBonus = segment.bonus;
      }

      labelPairs.set(pairKey, entry);
    }

    for (const entry of labelPairs.values()) {
      const badge = this.#createPairBadge(entry);
      if (!badge) continue;

      badge.x = entry.midX;
      badge.y = entry.midY;
      labels.addChild(badge);
    }
  }

  #createPairBadge({ friendlyBonus, hostileBonus }) {
    const hasFriendly = Number.isFinite(friendlyBonus) && friendlyBonus > 0;
    const hasHostile = Number.isFinite(hostileBonus) && hostileBonus > 0;
    if (!hasFriendly && !hasHostile) return null;

    const badge = new PIXI.Container();
    badge.eventMode = 'none';

    const backdrop = new PIXI.Graphics();
    backdrop.beginFill(0x000000, 0.35);
    if (hasFriendly && hasHostile) {
      backdrop.lineStyle(2, 0xffffff, 0.55);
      backdrop.drawRoundedRect(-30, -12, 60, 24, 7);
      backdrop.endFill();
      badge.addChild(backdrop);

      const friendlyText = this.#createBadgeText(`+${friendlyBonus}`, GANGUP_LINE_COLOR);
      friendlyText.x = -14;
      badge.addChild(friendlyText);

      const hostileText = this.#createBadgeText(`+${hostileBonus}`, HOSTILE_GANGUP_LINE_COLOR);
      hostileText.x = 14;
      badge.addChild(hostileText);
      return badge;
    }

    const lineColor = hasFriendly ? GANGUP_LINE_COLOR : HOSTILE_GANGUP_LINE_COLOR;
    const bonus = hasFriendly ? friendlyBonus : hostileBonus;
    backdrop.lineStyle(2, lineColor, 0.65);
    backdrop.drawRoundedRect(-16, -12, 32, 24, 7);
    backdrop.endFill();
    badge.addChild(backdrop);

    const text = this.#createBadgeText(`+${bonus}`, lineColor);
    badge.addChild(text);
    return badge;
  }

  #createBadgeText(text, strokeColor) {
    const label = new PIXI.Text(text, {
      fontSize: 16,
      fontFamily: 'Signika',
      fontWeight: '600',
      fill: 0xffffff,
      stroke: strokeColor,
      strokeThickness: 2
    });

    label.anchor.set(0.5);
    label.x = 0;
    label.y = 0;
    return label;
  }

  #getPairKey(idA, idB) {
    return idA < idB ? `${idA}|${idB}` : `${idB}|${idA}`;
  }

  #ensureModeSelector() {
    let selector = document.getElementById(TACTICAL_MODE_SELECTOR_ID);
    if (!selector) {
      selector = document.createElement('div');
      selector.id = TACTICAL_MODE_SELECTOR_ID;
      selector.innerHTML = `
        <div class="swade-tactical-mode-tabs">
          <button type="button" class="swade-tactical-mode-option" data-mode="${MODE_GANGUP}"></button>
          <button type="button" class="swade-tactical-mode-option" data-mode="${MODE_RANGEFINDER}"></button>
        </div>
        <div class="swade-tactical-mode-options">
          <div class="swade-tactical-mode-options-group" data-options-for="${MODE_GANGUP}">
            <label class="swade-tactical-mode-checkbox">
              <input type="checkbox" data-option="only-selected-bonuses" />
              <span class="swade-tactical-mode-checkbox-label"></span>
            </label>
          </div>
          <div class="swade-tactical-mode-options-group" data-options-for="${MODE_RANGEFINDER}">
            <p class="swade-tactical-mode-options-placeholder"></p>
          </div>
        </div>
      `;

      selector.addEventListener('click', event => {
        const button = event.target.closest?.('[data-mode]');
        const mode = button?.dataset?.mode;
        if (!mode) return;
        this.setMode(mode);
      });

      selector.addEventListener('change', event => {
        const option = event.target.closest?.('[data-option="only-selected-bonuses"]');
        if (!option) return;

        this.onlyShowSelectedBonuses = Boolean(option.checked);
        if (this.active && this.#isGangupMode()) {
          this.updateGangUpLines();
        }
      });

      document.body.appendChild(selector);
    }

    const gangupButton = selector.querySelector(`[data-mode="${MODE_GANGUP}"]`);
    const rangefinderButton = selector.querySelector(`[data-mode="${MODE_RANGEFINDER}"]`);
    const selectedOnlyLabel = selector.querySelector('.swade-tactical-mode-checkbox-label');
    const selectedOnlyInput = selector.querySelector('[data-option="only-selected-bonuses"]');
    const rangefinderPlaceholder = selector.querySelector('.swade-tactical-mode-options-placeholder');
    if (gangupButton) gangupButton.textContent = game.i18n.localize('SWADE Tactical.ModeGangup');
    if (rangefinderButton) rangefinderButton.textContent = game.i18n.localize('SWADE Tactical.ModeRangefinder');
    if (selectedOnlyLabel) selectedOnlyLabel.textContent = game.i18n.localize('SWADE Tactical.ModeGangupOnlySelectedBonuses');
    if (selectedOnlyInput) selectedOnlyInput.checked = this.onlyShowSelectedBonuses;
    if (rangefinderPlaceholder) rangefinderPlaceholder.textContent = game.i18n.localize('SWADE Tactical.ModeRangefinderOptionsPlaceholder');

    return selector;
  }

  #updateModeSelectorState() {
    const selector = document.getElementById(TACTICAL_MODE_SELECTOR_ID);
    if (!selector) return;

    for (const option of selector.querySelectorAll('[data-mode]')) {
      option.classList.toggle('is-active', option.dataset.mode === this.mode);
    }
  }

  #updateModeOptionState() {
    const selector = document.getElementById(TACTICAL_MODE_SELECTOR_ID);
    if (!selector) return;

    selector.dataset.activeMode = this.mode;
  }

  #isGangupMode() {
    return this.mode === MODE_GANGUP;
  }

  #ensureGangUpLayer() {
    let layer = this.#getGangUpLayer();
    if (!layer) {
      layer = new PIXI.Container();
      layer.name = GANGUP_LAYER_NAME;
      layer.eventMode = 'none';
      canvas.tokens.addChild(layer);
    } else if (layer.parent !== canvas.tokens) {
      layer.parent?.removeChild(layer);
      canvas.tokens.addChild(layer);
    }

    return layer;
  }

  #getGangUpLayer() {
    return canvas?.tokens?.getChildByName?.(GANGUP_LAYER_NAME) ?? null;
  }

  #clearGangUpLayer(layer) {
    if (!layer) return;

    while (layer.children.length > 0) {
      const child = layer.removeChildAt(0);
      child.destroy({ children: true });
    }
  }

  #tokenDistance(tokenA, tokenB) {
    const dx = (tokenA?.center?.x ?? 0) - (tokenB?.center?.x ?? 0);
    const dy = (tokenA?.center?.y ?? 0) - (tokenB?.center?.y ?? 0);
    return Math.hypot(dx, dy);
  }

  #getOneInchRadiusPixels() {
    const sceneGridDistance = Number(canvas.scene?.grid?.distance);
    const sceneGridSize = Number(canvas.scene?.grid?.size);

    if (!Number.isFinite(sceneGridDistance) || sceneGridDistance <= 0) return 0;
    if (!Number.isFinite(sceneGridSize) || sceneGridSize <= 0) return 0;

    const oneInchPixels = (RANGE_INCHES / sceneGridDistance) * sceneGridSize;
    // Reduce by 1 px so touching edges are not treated as overlap.
    return Math.max(0, oneInchPixels - 1);
  }
}