import { MODIFIER_DISPLAY_TYPE } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { MODIFIER_TYPE, TARGET_MODIFIERS } from "../constants.js";

const displayData = {
    label: "Range:",
    descriptor: "Range",
    displayWidget: MODIFIER_DISPLAY_TYPE.DROPDOWN,
    value: "Short",
    options: [
        {                    
            id: "rangeShort",
            category: "Range",
            value: "Short",
            descriptor: "Range (Short)"
        },
        {                    
            id: "rangeMedium",
            category: "Range",
            value: "Medium",
            descriptor: "Range (Medium)"
        },
        {                    
            id: "rangeLong",
            category: "Range",
            value: "Long",
            descriptor: "Range (Long)"
        },
        {                    
            id: "rangeExtreme",
            category: "Range",
            value: "Extreme",
            descriptor: "Range (Extreme)"
        }
    ],
};

const valueModifierTranslations = {
    0:0,
    1:-2,
    2:-4,
    3:-6
};
export class RangeModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=TARGET_MODIFIERS.RANGE;
            this.displayData = displayData;
            this.category = "Core Rules";
            this.descriptor=null; // To be set below
            this.value= this.calculateDefaultValue(); 
            this.traitModifier = valueModifierTranslations[this.value];
            this.type = MODIFIER_TYPE.TARGET;                
            this.calculateValue();
        }
        super.init();
    }
    calculateDefaultValue() {
        var defaultValue = 0;
        if (!this.isActive())
            return defaultValue;
        
        const automataActor = this.getAutomataActor();
        const target = this.getAutomataTargetActor();
        const item = this.getAutomataItem();
        const targetDistance = Math.floor(canvas.grid.measureDistance(automataActor.token, target.token).toFixed(1));
        if (item.swadeItem.range !== undefined) {        
            if (targetDistance > item.swadeItem.range.short && targetDistance <= item.swadeItem.range.medium) {
                defaultValue = 1;
            } else if (targetDistance > item.swadeItem.range.medium && targetDistance <= item.swadeItem.range.long)  {
                defaultValue = 2;
            } else if (targetDistance > item.swadeItem.range.long && targetDistance <= item.swadeItem.range.extreme) {
                defaultValue = 3;
            } else if (targetDistance > item.swadeItem.range.long) { // If range is beyond extreme, just default to extreme
                defaultValue = 3;
            }            
        }
        return defaultValue;
    }

    isActive(currentModifier,currentModifiers) {
        console.log(this.itemHasRange());
        console.log(this.targetExists());
        return this.itemHasRange() && this.targetExists();
    }
    calculateValue() {
        this.traitModifier = valueModifierTranslations[this.value];
        this.descriptor = this.displayData.options[this.value].descriptor;
    }
}