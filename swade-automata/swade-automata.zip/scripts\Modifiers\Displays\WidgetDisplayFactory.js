export const WidgetDisplayFactory = {};
