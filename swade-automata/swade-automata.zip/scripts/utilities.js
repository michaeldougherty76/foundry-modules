export function broofa() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        let r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
        return v.toString(16);
    });
}

export async function showCombatActionMessage(actor, message) {

}

export function bindAction (html, targetClass, action, event = 'click') {
    const target = html.find(targetClass);
    if (target) {
        target.unbind(event).bind(event, action);
    }
}

