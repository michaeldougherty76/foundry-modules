export class EditModifierDialog {
  static async show(label, value) {
    return foundry.applications.api.DialogV2.prompt({
      window: { title: "Edit Modifier" },
      position: { width: 400 },
      content: `
        <fieldset>
          <div class="form-group">
            <label>Modifier</label>
            <input type="text" value="${label}" readonly disabled style="background: #eee; color: #666;" />
          </div>
          <div class="form-group">
            <label>Value</label>
            <input type="text" name="value" value="${value}" placeholder="e.g., +2, -1" autofocus />
          </div>
        </fieldset>
      `,
      rejectClose: false,
      ok: {
        label: "Save",
        callback: (event, button, dialog) => {
          const input = button.form.querySelector('input[name="value"]');
          return input ? input.value : value;
        }
      }
    });
  }
}

