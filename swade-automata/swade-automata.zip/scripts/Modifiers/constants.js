export const MODIFIER_TYPE = {
    ACTOR: "modifierTypeActor",
    TARGET: "modifierTypeTarget",
    TRAITDIE: "modifierTypeTraitDie"
}
export const MODIFIES = {
    TRAIT: "modifiesTrait",
    DAMAGE: "modifiesDamage",
    ROF: "modifiesROF"
}
export const ACTOR_MODIFIERS = {
    WEAPON_DAMAGE: "weaponDamage",
    TARGET_NUMBER_DEFAULT: "targetNumberDefault",    
    BASE_TRAIT_MODIFIER: "baseTraitModifier",
    DISTRACTED: "coreDistracted",
    WOUNDS: "wounds",
    RATE_OF_FIRE: "rateOfFire",
    RECOIL: "recoil",
    MULTI_ACTION_PENALTY: "multiActionPenalty",
    ILLUMINATION: "illumination",
    WILD_ATTACK:"wildAttack",
    OFFHAND_PENALTY: "offhandPenalty",
    AIM: "aim",
    JOKERS_WILD: "jokersWild",
    POWER_BOOSTLOWERTRAIT_TRAITNAME: "powerBoostLowerTrait-TraitName",
}
export const TARGET_MODIFIERS = {
    TARGET_NUMBER_PARRY: "targetNumberParry",
    VULNERABLE: "coreVulnerable",
    GANGUP: "gangup",
    GANGUP_DEFENSE: "gangupDefense",
    RANGE: "range",
    COVER: "cover",
    SCALE: "scale",
    SPEED: "speed",
    CALLED_SHOT: "calledShot"
}
export const TRAITDIE_MODIFIERS = {
    ELAN: "elan"
}