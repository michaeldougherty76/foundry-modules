import { ACTIVE_EFFECT } from "../../Data/modifiers.js";
import { MODIFIER_DISPLAY_TYPE, SKILL } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { MODIFIER_TYPE, TARGET_MODIFIERS } from "../constants.js";

export class VulnerableModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=TARGET_MODIFIERS.VULNERABLE;
            this.displayData={
                displayWidget: MODIFIER_DISPLAY_TYPE.CHECKBOX,
                label: "Vulnerable:",
                case: undefined
            };
            this.category = "Core Rules";
            this.descriptor="Target Vulnerable";
            this.value=1;               // Default is checked
            this.traitModifier = 2;     // Default is +2 bonus
            this.type = MODIFIER_TYPE.TARGET;                
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        const validSkillsUsed = [SKILL.ATHLETICS, SKILL.FIGHTING, SKILL.SHOOTING]
        return this.targetHasEffect(ACTIVE_EFFECT.VULNERABLE)
            && this.skillOrWeaponSkillUsed(validSkillsUsed);
    }
    calculateValue() {
        this.traitModifier = (this.value == 1 ? 2 : 0);
    }
}