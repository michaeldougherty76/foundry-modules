import { MODIFIER_DISPLAY_TYPE } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { MODIFIER_TYPE, TARGET_MODIFIERS } from "../constants.js";

const displayData = {
    label: "Speed:",
    descriptor: "Speed",
    displayWidget: MODIFIER_DISPLAY_TYPE.DROPDOWN,
    value: "Normal",
    options: [
        {                    
            id: "SpeedNone",
            category: "Target Speed",
            value: "N/A",
            descriptor: "None"
        },
        {                    
            id: "Speed60mph",
            category: "Target Speed",
            value: "60 MPH+",
            descriptor: "Speed (60 MPH+)"
        },
        {                    
            id: "speed120mph",
            category: "Target Speed",
            value: "120 MPH+",
            descriptor: "Speed (120 MPH+)"
        },
        {                    
            id: "speed240mph",
            category: "Target Speed",
            value: "240 MPH+",
            descriptor: "Speed (240 MPH+)"
        },
        {                    
            id: "speedmach1",
            category: "Target Speed",
            value: "Mach 1+",
            descriptor: "Speed (Mach 1+)"
        },
        {                    
            id: "speedmach2",
            category: "Target Speed",
            value: "Mach 2+",
            descriptor: "Speed (Mach 2+)"
        },
        {                    
            id: "speedNearLight",
            category: "Target Speed",
            value: "Near Light Speed+",
            descriptor: "Near Light Speed+"
        },

    ],
};

const valueModifierTranslations = {
    0:0,
    1:-1,
    2:-2,
    3:-4,
    4:-6,
    5:-8,
    6:-10
};

export class SpeedModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=TARGET_MODIFIERS.SPEED;
            this.displayData = displayData;
            this.category = "Core Rules";
            this.descriptor=null; 
            this.value= 0;
            this.traitModifier = 0;
            this.type = MODIFIER_TYPE.TARGET;                
            this.calculateValue();
        }

        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        return true;
    }
    calculateValue() {
        this.traitModifier = valueModifierTranslations[this.value];
        this.descriptor = this.displayData.options[this.value].descriptor;
    }
}