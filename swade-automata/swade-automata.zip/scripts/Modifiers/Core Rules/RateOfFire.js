import { ACTIVE_EFFECT } from "../../Data/modifiers.js";
import { MODIFIER_DISPLAY_TYPE } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { ACTOR_MODIFIERS, MODIFIER_TYPE } from "../constants.js";

export class RateOfFireModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=ACTOR_MODIFIERS.RATE_OF_FIRE;
            this.category = "Core Rules";
            this.value=1;               // Default is checked
            this.type = MODIFIER_TYPE.ACTOR;   
            this.displayData = {
                displayWidget: MODIFIER_DISPLAY_TYPE.ROF_SELECTOR,
                options: [
                    { id: "rof-1", displayValue: "1", value: 1, ammo: 1,  penalty: 0  },
                    { id: "rof-2", displayValue: "2", value: 2, ammo: 5,  penalty: -2 },
                    { id: "rof-3", displayValue: "3", value: 3, ammo: 10, penalty: -2 },
                    { id: "rof-4", displayValue: "4", value: 4, ammo: 20, penalty: -2 },
                    { id: "rof-5", displayValue: "5", value: 5, ammo: 30, penalty: -2 },
                    { id: "rof-6", displayValue: "6", value: 6, ammo: 40, penalty: -2 },
                    { id: "rof-7", displayValue: "7", value: 7, ammo: 50, penalty: -2 },
                ]    
            };          
            this.rofModifier = 0;
        }
        super.init();
    }
    // Display the selector if a weapon with a ROF > 1 was used.
    isActive(currentModifier,currentModifiers) {
        return this.itemHasMultipleROF();
    }
    calculateValue() {
        this.rofModifier = this.value -1;
        console.log(this.rofModifier);
    }
}