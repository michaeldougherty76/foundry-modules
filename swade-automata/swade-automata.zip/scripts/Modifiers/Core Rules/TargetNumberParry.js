import { SKILL } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { MODIFIER_TYPE, TARGET_MODIFIERS } from "../constants.js";

export class TargetNumberParryModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id = TARGET_MODIFIERS.TARGET_NUMBER_PARRY;
            this.category = "Core Rules";
            this.value=1;               // Default is checked
            const target = this.getAutomataTargetActor();
            this.targetNumberValue = target !== undefined ? target.getParry() : undefined; // Set the default Target Number            
            this.type = MODIFIER_TYPE.TARGET;
            this.bannerText = "Target Parry being used";
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        return this.skillOrWeaponSkillUsed([SKILL.FIGHTING]) 
            || (this.skillOrWeaponSkillUsed([SKILL.SHOOTING]) && this.targetWithinDistance(1));
    }
    calculateValue() {
        if (this.value === 1) {
            const target = this.getAutomataTargetActor();
            this.targetNumberValue = target !== undefined ? target.getParry() : undefined;
            this.bannerText = "Target Parry being used";    
        } else {
            this.targetNumberValue = undefined;
            this.bannerText = undefined;
        }        
    }
}