import { MODIFIER_DISPLAY_TYPE } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { ACTOR_MODIFIERS, MODIFIER_TYPE } from "../constants.js";

const displayData = {
    label: "Illumination:",
    descriptor: "Illumination",
    displayWidget: MODIFIER_DISPLAY_TYPE.DROPDOWN,
    value: "Normal",
    options: [
        {                    
            id: "normal",
            category: "Illumination",
            value: "Normal",
            descriptor: "Normal"
        },
        {                    
            id: "dim",
            category: "Illumination",
            value: "Dim",
            descriptor: "Illumination (Dim)"
        },
        {                    
            id: "dark",
            category: "Illumination",
            value: "Dark",
            descriptor: "Illumination (Dark)"
        },
        {                    
            id: "pitchBlack",
            category: "Illumination",
            value: "Pitch Black",
            descriptor: "Illumination (Pitch Black)"
        },
    ],
};

const valueModifierTranslations = {
    0:0,
    1:-2,
    2:-4,
    3:-6
};

export class IlluminationModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=ACTOR_MODIFIERS.ILLUMINATION;
            this.displayData = displayData;
            this.category = "Core Rules";
            this.descriptor=null; // To be set by Radio control
            this.value= 0;
            this.traitModifier = 0;
            this.type = MODIFIER_TYPE.ACTOR;                
            this.calculateValue();
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        return true;
    }
    calculateValue() {
        this.traitModifier = valueModifierTranslations[this.value];
        this.descriptor = this.displayData.options[this.value].descriptor;
    }
}