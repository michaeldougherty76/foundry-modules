import { AutomataActor } from "../../classes/Automata/AutomataActor.js";
import { MODIFIER_DISPLAY_TYPE } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { ACTOR_MODIFIERS, MODIFIER_TYPE, TARGET_MODIFIERS } from "../constants.js";
const sizeScaleModifier = {
    '-4':-6,
    '-3':-4,
    '-2':-2,
    '-1':0,
    '0':0,
    '1':0,
    '2':0,
    '3':0,
    '4':2,
    '5':2,
    '6':2,
    '7':2,
    '8':4,
    '9':4,
    '10':4,
    '11':4,
    '12':6,
    '13':6,
    '14':6,
    '15':6,
    '16':6,
    '17':6,
    '18':6,
    '19':6,
    '20':6
}
const modifierToValueConversion = {
    '-12':0,
    '-10':1,
    '-8':2,
    '-6':3,
    '-4':4,
    '-2':5,
    '0':6,
    '2':7,
    '4':8,
    '6':9,
    '8':10,
    '10':11,
    '12':12,
}
const valueToModifierConversion = {
    0 : -12,
    1 : -10,
    2 : -8,
    3 : -6,
    4 : -4,
    5 : -2,
    6 : 0,
    7 : 2,
    8 : 4,
    9 : 6,
    10 : 8,
    11 : 10,
    12 : 12,
}

const displayData = {
    label: "Scale:",
    descriptor: "Scale",
    displayWidget: MODIFIER_DISPLAY_TYPE.DROPDOWN,
    value: "0",
    options: [
        {
            id: "scaleTargetNeg12",
            category: "Scale",
            value: "-12",
            descriptor: "Scale (-12)"
        },
        {                    
            id: "scaleTargetNeg10",
            category: "Scale",
            value: "-10",
            descriptor: "Scale (-10)"
        },
        {                    
            id: "scaleTargetNeg8",
            category: "Scale",
            value: "-8",
            descriptor: "Scale (-8)"
        },
        {                    
            id: "scaleTargetNeg6",
            category: "Scale",
            value: "-6",
            descriptor: "Scale (-6)"
        },
        {                    
            id: "scaleTargetNeg4",
            category: "Scale",
            value: "-4",
            descriptor: "Scale (-4)"
        },
        {                    
            id: "scaleTargetNeg2",
            category: "Scale",
            value: "-2",
            descriptor: "Scale (-2)"
        },
        {                    
            id: "scaleTargetEven",
            category: "Scale",
            value: "0",
            descriptor: "Scale (Even)"
        },
        {
            id: "scaleTargetPos2",
            category: "Scale",
            value: "2",
            descriptor: "Scale (+2)"
        },
        {                    
            id: "scaleTargetPos4",
            category: "Scale",
            value: "4",
            descriptor: "Scale (+4)"
        },
        {                    
            id: "scaleTargetPos6",
            category: "Scale",
            value: "6",
            descriptor: "Scale (+6)"
        },
        {                    
            id: "scaleTargetPos8",
            category: "Scale",
            value: "8",
            descriptor: "Scale (+8)"
        },
        {                    
            id: "scaleTargetPos10",
            category: "Scale",
            value: "10",
            descriptor: "Scale (+10)"
        },
        {                    
            id: "scaleTargetPos12",
            category: "Scale",
            value: "12",
            descriptor: "Scale (+12)"
        },

    ],
};

export class ScaleModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=TARGET_MODIFIERS.SCALE;
            this.displayData = displayData;
            this.category = "Core Rules";
            this.descriptor="Scale"; // To be set by Radio control
            this.value = this.calculateDefaultValue();

            this.type = MODIFIER_TYPE.TARGET;                
            this.calculateValue();
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        return this.targetExists();
    }
    calculateDefaultValue() {
        if (this.targetExists()) {
            const automataActor = this.getAutomataActor();
            const automataTargetActor = this.getAutomataTargetActor();
            const actorSize = automataActor.getSize();
            const targetSize = automataTargetActor.getSize();
            const actorScaleModifier = sizeScaleModifier[actorSize.toString()];
            const targetScaleModifier = sizeScaleModifier[targetSize.toString()];
            this.traitModifier = targetScaleModifier - actorScaleModifier;
            return modifierToValueConversion[this.traitModifier.toString()];    
        } else {
            return 0;
        }        
    }
    calculateValue() {
        this.traitModifier = valueToModifierConversion[this.value];
    }
}