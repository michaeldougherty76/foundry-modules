import { MODIFIER_DISPLAY_TYPE } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { ACTOR_MODIFIERS, MODIFIER_TYPE } from "../constants.js";

export class JokersWildModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=ACTOR_MODIFIERS.JOKERS_WILD;
            this.displayData={
                displayWidget: MODIFIER_DISPLAY_TYPE.CHECKBOX,
                label: "Jokers Wild:",
                case: undefined
            };
            this.category = "Core Rules";
            this.descriptor="Jokers Wild";
            this.value=1;               // Default is checked
            this.traitModifier = 2;    // Default is +2
            this.type = MODIFIER_TYPE.ACTOR;                
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        return this.actorHasJoker();
    }
    calculateValue() {
        this.traitModifier = (this.value == 1 ? 2 : 0);
    }
}