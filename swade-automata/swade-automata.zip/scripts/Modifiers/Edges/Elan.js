import { ACTIVE_EFFECT } from "../../Data/modifiers.js";
import { MODIFIER_DISPLAY_TYPE } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { MODIFIER_TYPE, TRAITDIE_MODIFIERS } from "../constants.js";

export class ElanModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=TRAITDIE_MODIFIERS.ELAN;
            this.displayData={
                displayWidget: MODIFIER_DISPLAY_TYPE.CHECKBOX,
                label: "Elan:",
                case: undefined
            };
            this.category = "Character Effects";
            this.descriptor="Distracted";
            this.value=0;               // Default is unchecked
            this.traitModifier = 0; 
            this.type = MODIFIER_TYPE.TRAITDIE;                
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        return this.actorHasEffect(ACTIVE_EFFECT.DISTRACTED);
    }
    calculateValue() {
        this.traitModifier = (this.value == 1 ? -2 : 0);
    }
    getHtml() {
        const widget = this.getDisplayWidget();
        const defaultValue = 1;
        //return creatorMethod(this, this.value, modifiersList,traitRollData);    
        return widget.createWidget(
            this.id, 
            this.displayData,
            this.descriptor,
            this.value,
            defaultValue
        );
    }
    updateValueFromHTML(html) {
        const widget = this.getDisplayWidget();
        widget.getUIDataForModifier(html, this);
        this.calculateValue();
    }

}