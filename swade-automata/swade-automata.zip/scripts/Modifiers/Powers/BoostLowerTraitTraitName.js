import { ACTIVE_EFFECT } from "../../Data/modifiers.js";
import { MODIFIER_DISPLAY_TYPE, SKILL } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { ACTOR_MODIFIERS, MODIFIER_TYPE, TARGET_MODIFIERS } from "../constants.js";

const displayData = {
    label: "Trait to Boost:",
    descriptor: "Trait to Boost",
    displayWidget: MODIFIER_DISPLAY_TYPE.DROPDOWN,
    value: "Agility",
    options: [
        {                    
            id: "agility",
            category: "Attributes",
            value: "Agility",
        },
        {                    
            id: "smarts",
            category: "Attributes",
            value: "Smarts",
        },
        {                    
            id: "spirit",
            category: "Attributes",
            value: "Spirit",
        },
        {                    
            id: "strength",
            category: "Attributes",
            value: "Strength",
        },
        {                    
            id: "vigor",
            category: "Attributes",
            value: "Vigor",
        },
        {                    
            id: "academics",
            category: "Skills",
            value: "Academics",
        },
        {                    
            id: "athletics",
            category: "Skills",
            value: "Athletics",
        },
        {                    
            id: "battle",
            category: "Skills",
            value: "Battle",
        },
        {                    
            id: "commonKnowledge",
            category: "Skills",
            value: "Common Knowledge",
        },
        {                    
            id: "driving",
            category: "Skills",
            value: "Driving",
        },
        {                    
            id: "electronics",
            category: "Skills",
            value: "Electronics",
        },
        {                    
            id: "fighting",
            category: "Skills",
            value: "Fighting",
        },
        {                    
            id: "gambling",
            category: "Skills",
            value: "Gambling",
        },
        {                    
            id: "hacking",
            category: "Skills",
            value: "Hacking",
        },
        {                    
            id: "healing",
            category: "Skills",
            value: "Healing",
        },
        {                    
            id: "intimidation",
            category: "Skills",
            value: "Intimidation",
        },
        {                    
            id: "notice",
            category: "Skills",
            value: "Notice",
        },
        {                    
            id: "performance",
            category: "Skills",
            value: "Performance",
        },
        {                    
            id: "persuasion",
            category: "Skills",
            value: "Persuasion",
        },
        {                    
            id: "piloting",
            category: "Skills",
            value: "Piloting",
        },
        {                    
            id: "psionics",
            category: "Skills",
            value: "Psionics",
        },
        {                    
            id: "repair",
            category: "Skills",
            value: "Repair",
        },
        {                    
            id: "research",
            category: "Skills",
            value: "Research",
        },
        {                    
            id: "science",
            category: "Skills",
            value: "Science",
        },
        {                    
            id: "shooting",
            category: "Skills",
            value: "Shooting",
        },
        {                    
            id: "stealth",
            category: "Skills",
            value: "Stealth",
        },
        {                    
            id: "survival",
            category: "Skills",
            value: "Survival",
        },
        {                    
            id: "taunt",
            category: "Skills",
            value: "Taunt",
        },
        {                    
            id: "technomancy",
            category: "Skills",
            value: "Technomancy",
        },
        {                    
            id: "thievery",
            category: "Skills",
            value: "Thievery",
        },

    ],
}

export class BoostLowerTraitTraitNameModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=ACTOR_MODIFIERS.POWER_BOOSTLOWERTRAIT_TRAITNAME;
            this.displayData = displayData;
            this.category = "Power Modifiers";
            this.descriptor="";
            this.value = 0;
            this.type = MODIFIER_TYPE.ACTOR;                
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        const automataItem = this.getAutomataItem();
        return automataItem.getType() === "power" && automataItem.getBasePowerName() === "Boost/Lower Trait";
    }
    calculateValue() {
        
    }
}