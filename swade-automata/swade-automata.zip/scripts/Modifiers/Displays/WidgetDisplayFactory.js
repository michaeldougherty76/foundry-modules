export const WidgetDisplayFactory = {};
