// Expected DisplayData should look like: 
// {
//      label: "How to label the checkbox",
//      case:  "If a case is applicable to the label"
// }
export class CheckboxDisplayWidget {
    constructor() { }

    createWidget(modifier){
        const modifierId = modifier.id;
        const displayData = modifier.displayData;
        const descriptor = modifier.descriptor;
        const value = modifier.value;

        const option = `
            <input style="vertical-align: middle;" class="modifier-${modifierId}" type="checkbox" id="${modifierId}" name="${modifierId}" placeholder="${descriptor}" value="1" ${(value == 1)  ? "checked": ""} onChange="recalc();">        
        `;
        return option;    
    }

    getUIDataForModifier(html, modifier){
        const relevantNodes = html.find(`.modifier-${modifier.id}`);
        relevantNodes.each(nodeIndex => {
            if (relevantNodes[nodeIndex].checked) {           
                modifier.value = parseInt(relevantNodes[nodeIndex].value);
            } else {
                modifier.value = 0;
            }
        });
    }
}
