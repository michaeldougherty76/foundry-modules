import { AutomataActor } from "../classes/Automata/AutomataActor.js";
import { USED } from "../mod/constants.js";
import { WidgetDisplayFactory } from "./Displays/WidgetDisplayFactory.js";

export class BaseModifier {
    id;             // ID of the modifier(ie, "distracted")
    isInitialized;
    actorId;        // ID of the actor pertinent for the modifier
    targetId;       // ID of the target the modifier is affecting
    itemId;         // ID of the item being used
    traitDieIndex;  // Index key of the trait die

    displayData;
    category;
    descriptor;
    value;
    type;
    offsetTargets;

    //EFfects of the modifier
    traitModifier;    
    rofModifier;
    offsetModifier;
    targetNumberValue;
    
    setBaseDamage;
    damageModifier;
    bonusDamageModifier;
    setBonusDamage;
    includeGlobalActions;

    bannerText;
    updated;
    subscribedModifiers;
    listeningModifiers;
    listenersDisabled;

    constructor (inputData,existingModifier) {
        if (existingModifier !== undefined && existingModifier !== null) {
            this.id = existingModifier.id;
            this.isInitialized = existingModifier.isInitialized;
            this.actorId = existingModifier.actorId;
            this.targetId = existingModifier.targetId;
            this.itemId = existingModifier.itemId;
            this.displayData = existingModifier.displayData;
            this.category = existingModifier.category;
            this.descriptor = existingModifier.descriptor;
            this.value = existingModifier.value;
            this.type = existingModifier.type;
            this.traitModifier = existingModifier.traitModifier;            
            this.rofModifier = existingModifier.rofModifier;
            this.offsetModifier = existingModifier.offsetModifier;
            this.targetNumberValue = existingModifier.targetNumberValue;            
            this.offsetTargets = existingModifier.offsetTargets;
            this.setBaseDamage = existingModifier.setBaseDamage;
            this.damageModifier = existingModifier.damageModifier;
            this.bonusDamageModifier = existingModifier.bonusDamageModifier;
            this.setBonusDamage = existingModifier.setBonusDamage;
            this.includeGlobalActions = existingModifier.includeGlobalActions;
            this.includeTargetActions = existingModifier.includeTargetActions;
            this.subscribedModifiers = existingModifier.subscribedModifiers;
            this.bannerText = existingModifier.bannerText;
        } else {
            this.actorId = inputData.actorId;
            this.targetId = inputData.targetId;
            this.itemId = inputData.itemId;
        }
    }
    init() {
        this.isInitialized = true;
    }
    getOffsetPenalty() {
        return null;
    }
    getHtml() {
        if (!this.displayData)
            return;

        const modifierLabel = `
            <div class="modifier-data data-left">
                <span>${this.displayData.label}${this.displayData.modifierCase !== undefined ? (' (' + modifierCase + ')') : ''}</span>
            </div>`;
        
        var widgetHtml = '<div class="modifier-data data-right"></div>';
        if (this.displayData.displayWidget !== undefined) {
            const widget = this.getDisplayWidget();
            widgetHtml = this.displayData.displayWidget !== undefined ? widget.createWidget(this) : '<div></div>';    
        }

        var traitModifierDisplayText = '';
        if (this.traitModifier !== undefined) {
            if (this.traitModifier > 0) {
                traitModifierDisplayText = `+${this.traitModifier}`;
            }
            if (this.traitModifier < 0) {
                traitModifierDisplayText = `${this.traitModifier}`;
            }
        }

        var damageModifierDisplayText = '';
        if (this.setBaseDamage !== undefined) {
            damageModifierDisplayText = this.setBaseDamage;
        } else if (this.damageModifier !== undefined) {
            damageModifierDisplayText = this.damageModifier;
        }

        var bonusDamageModifierDisplayText = '';
        if (this.setBonusDamage !== undefined) {
            bonusDamageModifierDisplayText = this.setBonusDamage;
        } else if (this.bonusDamageModifier !== undefined) {
            bonusDamageModifierDisplayText = this.bonusDamageModifier;
        }

        const traitModifierHtml = `
            <div class="modifier-data data-right">
                <div style="display: flex; flex-direction: column; align-items: center;">${traitModifierDisplayText}</div>
            </div>`;
        const damageModifierHtml = `
            <div class="modifier-data data-right">
                <div style="display: flex; flex-direction: column; align-items: center;">${damageModifierDisplayText}</div>
            </div>`;
        const bonusDamageModifierHtml = `
            <div class="modifier-data data-right">
                <div style="display: flex; flex-direction: column; align-items: center;">${bonusDamageModifierDisplayText}</div>
            </div>`;
        const targetNumberModifierHtml = `
            <div class="modifier-data data-right">
                <div style="display: flex; flex-direction: column; align-items: center;">${''}</div>
            </div>`;
        const ammoModifier = `
            <div class="modifier-data data-right">
                <div style="display: flex; flex-direction: column; align-items: center;">${''}</div>
            </div>`;

        const ppModifierHtml = `
            <div class="modifier-data data-right">
                <div style="display: flex; flex-direction: column; align-items: center;">${''}</div>
            </div>`;

        const lineItemHtml = `
            ${modifierLabel}
            ${widgetHtml}
            ${targetNumberModifierHtml}
            ${traitModifierHtml}
            ${damageModifierHtml}
            ${bonusDamageModifierHtml}
            ${ammoModifier}
            ${ppModifierHtml}
        `;
        return lineItemHtml;
    }
    updateValueFromHTML(html) {
        if (this.displayData === undefined || this.displayData.displayWidget === undefined)
            return;
        const widget = this.getDisplayWidget();
        widget.getUIDataForModifier(html, this);
        this.calculateValue();
    }

    getDisplayWidget() {
        const widgetId = this.displayData.displayWidget;
        return new WidgetDisplayFactory[widgetId]();
    }
    getDisplayHtml() {
        let html = '<div style="display: flex; flex-direction: row;justify-content: space-between;"><span>' + this.descriptor + '</span><span>' + this.traitModifier + '</span></div>';
        return html;    
    }
    getTraitModifier() {
        return this.traitModifier !== undefined ? this.traitModifier : 0;
    }
    getCategory() {
        return this.category;
    }  
    calculateValue() { }
    getAutomataActor() {
        return this.actorId !== undefined ? AutomataActor.createFromUUID(this.actorId) : undefined;
    }
    getAutomataTargetActor() {
        return this.targetId !== undefined ? AutomataActor.createFromUUID(this.targetId) : undefined;
    }
    getAutomataItem() {     
        console.log(this.itemId)   ;
        return this.actorId !== undefined && this.itemId !== undefined ? AutomataActor.createFromUUID(this.actorId).getAutomataItemById(this.itemId) : undefined;
    }

    updateFromUIWidget(html) {
        const preUpdateValue = this.value;
        this.updateValueFromHTML(html);
        if (!this.listenersDisabled) {
            if (preUpdateValue !== this.value) {
                if (this.listeningModifiers !== undefined && this.listeningModifiers !== null) {
                    Object.keys(this.listeningModifiers).forEach(listeningModifierKey => {
                        this.listeningModifiers[listeningModifierKey].listenerUpdate(this.id,this.value);
                    });
                }    
            }    
        }            
    }
    //Adds a modifier to a list of "listening" modifiers. These will be updated when changes are made to the value of this modifier.
    addListeningModifier(modifier) {
        if (this.listeningModifiers === undefined)
            this.listeningModifiers = {};
        this.listeningModifiers[modifier.id] = modifier;
    }

    //This needs to be called immediately after constructor
    createSubscriptions(modifierList) {
        if (this.subscribedModifiers !== undefined && this.subscribedModifiers !== null && this.subscribedModifiers.length > 0) {
            this.subscribedModifiers.forEach(modifierKey => {
                modifierList[modifierKey].addListeningModifier(this);
            });    
        }
    }
    async onTraitRoll(actor) {

    }
    //This is called when a subscribed modifier calls updates on change. Override this to determine how to hadnle incoming changes from other modifiers
    listenerUpdate(modifierId,newValue) {

    }

    disableListeners() {
        this.listenersDisabled = true;
    }
    enableListeners() {
        this.listenersDisabled = undefined;
    }
    // Condition Helpers
    actorHasEffect(effectName) {
        const actor = this.getAutomataActor();
        return actor.hasActiveEffectByName(effectName);
    }
    actorHasEffectById(effectId) {
        const actor = this.getAutomataActor();
        return actor.hasActiveEffectById(effectId);
    }

    actorHasEdge(edgeName) {
        const actor = this.getAutomataActor();
        return actor.hasEdgeByName(edgeName);
    }

    actorUsed(usedTypes) {
        if (usedTypes.includes(USED.WEAPON)) {
            const item = this.getAutomataItem();
            if (item.getType() === "weapon") {
                return true;
            }
        }
        return false;
    }
    actorHasJoker() {
        const actor = this.getAutomataActor();
        return [98,99].includes(actor.getCombatCardValue());
    }
    targetExists() {
        const target = this.getAutomataTargetActor();
        return target !== undefined && target !== null;
    }
    targetHasEffect(effectName) {        
        const target = this.getAutomataTargetActor();
        if (!target) {
            return false;
        }
        return target.hasActiveEffectByName(effectName);
    }
    skillOrWeaponSkillUsed(skillList) {
        const item = this.getAutomataItem();
        const usedSkillItem = item.getType() === "skill";
        const usedWeaponItem = item.getType() === "weapon";
        return (usedSkillItem && skillList.includes(item.getName()))
                || (usedWeaponItem && skillList.includes(item.swadeItem.system.actions.trait));
    }
    targetWithinDistance(distance) {
        if (!this.targetExists()) {
            return false;
        }
        const measureDistance = distance +1;
        const actor = this.getAutomataActor();
        const target = this.getAutomataTargetActor();
        return (actor.getDistanceToAutomataActor(target) < measureDistance);
    }
    itemIsType(validTypes) {
        const item = this.getAutomataItem();
        if (item === undefined)
            return false;

        return (validTypes.includes(item.getType()));
    }
    itemHasMultipleROF() {
        const item = this.getAutomataItem();
        if (item === undefined)
            return false;

        return (item.getType() === "weapon" && item.getROF() > 1);
    }
    itemHasRange() {
        const item = this.getAutomataItem();
        if (item.swadeItem.type !== "weapon") {
            return false;
        }
        const itemRangeValues = item.swadeItem.system.range;
        return itemRangeValues !== "" && itemRangeValues !== undefined && itemRangeValues !== null;
    }
    itemIsEquipped() {
        const item = this.getAutomataItem();
        if (item.swadeItem.system.equipStatus === 1 || item.swadeItem.system.equipStatus === 2) {
            return true;
        } else {
            return false;
        }
    }
    itemIsInOffhand() {
        const item = this.getAutomataItem();
        if (item.swadeItem.system.equipStatus === 2) {
            return true;
        } else {
            return false;
        }
    }
    itemIsInMainhand() {
        const item = this.getAutomataItem();
        if (item.swadeItem.system.equipStatus === 1) {
            return true;
        } else {
            return false;
        }
    }

}