export class AutomataItem {
  /**
   * @param {Item | null | undefined} swadeItem
   */
  constructor(swadeItem) {
    this.swadeItem = swadeItem ?? null;
  }

  /**
   * Wrap a SWADE inventory item while preserving transparent property access.
   * @param {Item | AutomataItem | null | undefined} item
   * @returns {AutomataItem | null}
   */
  static wrap(item) {
    if (!item) return null;
    if (item instanceof AutomataItem) return item;

    const wrapper = new AutomataItem(item);
    return new Proxy(wrapper, {
      get(target, prop, receiver) {
        if (prop in target) {
          return Reflect.get(target, prop, receiver);
        }

        const value = target.swadeItem?.[prop];
        return typeof value === "function" ? value.bind(target.swadeItem) : value;
      },
      set(target, prop, value, receiver) {
        if (prop in target) {
          return Reflect.set(target, prop, value, receiver);
        }

        if (!target.swadeItem) return false;
        target.swadeItem[prop] = value;
        return true;
      },
      has(target, prop) {
        return prop in target || (target.swadeItem ? prop in target.swadeItem : false);
      }
    });
  }

  /**
   * Access the original SWADE item explicitly when needed.
   * @returns {Item | null}
   */
  get raw() {
    return this.swadeItem;
  }

  /**
   * Check whether this wrapper currently has any weapon item.
   * @returns {boolean}
   */
  isWeaponUsed() {
    const item = this.swadeItem;
    if (!item) return false;

    const type = item.type ?? item.system?.type;
    return type === "weapon";
  }

  /**
   * Check whether this wrapper currently has a melee weapon item.
   * @returns {boolean}
   */
  isMeleeWeaponUsed() {
    const item = this.swadeItem;
    if (!item) return false;

    const type = item.type ?? item.system?.type;
    const range = item.system?.range;
    const rangeType = item.system?.rangeType;
    const isMeleeFlag = item.system?.isMelee;

    const isWeapon = type === "weapon";
    const isMelee = range === "melee" || rangeType === "melee" || isMeleeFlag === true;

    return isWeapon && isMelee;
  }

  /**
   * Check whether this wrapper currently has a ranged weapon item.
   * @returns {boolean}
   */
  isRangedWeaponUsed() {
    const item = this.swadeItem;
    if (!item) return false;

    const type = item.type ?? item.system?.type;
    const range = item.system?.range;
    const rangeType = item.system?.rangeType;
    const isRangedFlag = item.system?.isRanged;

    const isWeapon = type === "weapon";
    const isRanged = rangeType === "ranged" || isRangedFlag === true || (typeof range === "string" && range !== "melee");

    return isWeapon && isRanged;
  }
}
