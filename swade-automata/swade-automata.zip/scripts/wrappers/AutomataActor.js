import { normalizeAttributeKey } from "../constants/attributes.js";

export class AutomataActor {
  /**
   * @param {Actor | null | undefined} swadeActor
   */
  constructor(swadeActor) {
    this.swadeActor = swadeActor ?? null;
  }

  /**
   * Wrap a SWADE actor while preserving transparent property access.
   * @param {Actor | AutomataActor | null | undefined} actor
   * @returns {AutomataActor | null}
   */
  static wrap(actor) {
    if (!actor) return null;
    if (actor instanceof AutomataActor) return actor;

    const wrapper = new AutomataActor(actor);
    return new Proxy(wrapper, {
      get(target, prop, receiver) {
        if (prop in target) {
          return Reflect.get(target, prop, receiver);
        }

        const value = target.swadeActor?.[prop];
        return typeof value === "function" ? value.bind(target.swadeActor) : value;
      },
      set(target, prop, value, receiver) {
        if (prop in target) {
          return Reflect.set(target, prop, value, receiver);
        }

        if (!target.swadeActor) return false;
        target.swadeActor[prop] = value;
        return true;
      },
      has(target, prop) {
        return prop in target || (target.swadeActor ? prop in target.swadeActor : false);
      }
    });
  }

  /**
   * Access the original SWADE actor explicitly when needed.
   * @returns {Actor | null}
   */
  get raw() {
    return this.swadeActor;
  }

  /**
   * Check if this actor currently has an effect by name.
   * @param {string} effectName
   * @returns {boolean}
   */
  hasEffect(effectName) {
    const normalizedEffectName = String(effectName ?? "").trim().toLowerCase();
    if (!normalizedEffectName) return false;

    const matchesRequestedName = (value) => {
      return String(value ?? "").trim().toLowerCase() === normalizedEffectName;
    };

    const isItemSource = (value) => {
      return typeof value === "string" && (value.includes(".Item.") || value.startsWith("Item."));
    };

    const isEffectActive = (effect) => {
      return !(effect?.disabled ?? false) && !(effect?.isSuppressed ?? false);
    };

    const effects = this.effects ?? [];
    for (const effect of effects) {
      if (!isEffectActive(effect)) continue;

      if (
        matchesRequestedName(effect?.name) ||
        matchesRequestedName(effect?.label) ||
        matchesRequestedName(effect?._source?.name)
      ) {
        return true;
      }

      // Keep item-sourced checks name-aware to avoid false positives across unrelated effects.
      if (
        (isItemSource(effect?.origin) ||
          isItemSource(effect?._source?.origin) ||
          isItemSource(effect?.flags?.core?.sourceId) ||
          isItemSource(effect?.sourceName)) &&
        (matchesRequestedName(effect?.sourceName) ||
          matchesRequestedName(effect?.flags?.core?.sourceId?.split('.')?.pop?.()))
      ) {
        return true;
      }
    }

    // Some item-given effects may remain on the item document itself.
    const items = this.items ?? [];
    for (const item of items) {
      const itemEffects = item?.effects ?? [];

      for (const effect of itemEffects) {
        if (!isEffectActive(effect)) continue;
        if (
          matchesRequestedName(effect?.name) ||
          matchesRequestedName(effect?.label) ||
          matchesRequestedName(effect?._source?.name)
        ) {
          return true;
        }
      }
    }

    return false;
  }

  /**
   * Check if this actor has an item by name.
   * @param {string} itemName
   * @returns {boolean}
   */
  hasItem(itemName) {
    return this.items?.some(i => i.name === itemName) ?? false;
  }

  /**
   * Check if this actor has one of the supported core attributes.
   * @param {string} attrName
   * @returns {boolean}
   */
  hasAttribute(attrName) {
    const attributeKey = normalizeAttributeKey(attrName);
    if (!attributeKey) return false;

    return this.system?.attributes?.[attributeKey] !== undefined;
  }

  /**
   * Check whether the provided skill is one of the allowed skill names.
   * @param {Item | null | undefined} skillToCheck
   * @param {string[]} skillNames
   * @returns {boolean}
   */
  usedAnySkill(skillToCheck, skillNames) {
    if (!skillToCheck || !Array.isArray(skillNames)) return false;
    return skillNames.includes(skillToCheck.name);
  }
}
