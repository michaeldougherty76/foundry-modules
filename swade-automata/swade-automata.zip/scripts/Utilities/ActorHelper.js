export class ActorHelper {
    // Helper method takes a TOKEN or Actor Id
    static GetActorFromId(id) {
        const token = game.canvas.tokens.get(id);
        const actor = token ? token.actor : game.actors.get(id);
        return actor;
    }
    static GetActorIdFromSheet(sheet) {
        return sheet.token ? sheet.token.id : (sheet.object ? sheet.object.id : '');
    }
}