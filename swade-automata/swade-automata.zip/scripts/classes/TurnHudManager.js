export class TurnHudManager {
  static HUD_ID = 'swade-automata-turn-hud';
  static HUD_TEMPLATE = 'modules/swade-automata/templates/turnHud.hbs';
  static TWO_ACTIONS_EFFECT = '2 actions';
  static THREE_ACTIONS_EFFECT = '3 actions';

  static isActionCountEffect(effect) {
    if (!effect) return false;

    const flaggedActionCount = effect.getFlag?.('swade-automata', 'actionCount');
    if ([2, 3].includes(Number(flaggedActionCount))) {
      return true;
    }

    return effect.name === this.TWO_ACTIONS_EFFECT || effect.name === this.THREE_ACTIONS_EFFECT;
  }

  static async notifyActionCountSynced(actor, options = {}) {
    if (!actor) return;

    const actionCount = this.getSelectedActions(actor);
    Hooks.callAll('swadeAutomataActionCountChanged', {
      actorId: actor.id,
      actionCount,
      source: options.source ?? 'effect-sync'
    });

    const currentCombatant = game.combat?.started ? game.combat.combatant : null;
    if (currentCombatant?.actor?.id === actor.id) {
      await this.refresh(game.combat);
    }
  }

  static getHudElement() {
    return document.getElementById(this.HUD_ID);
  }

  static hide() {
    const element = this.getHudElement();
    if (element) element.remove();
  }

  static setHudSelectedAction(actionCount) {
    const element = this.getHudElement();
    if (!element) return;

    element.querySelectorAll('[data-action-count]').forEach((button) => {
      const buttonActionCount = Number(button.dataset.actionCount);
      button.classList.toggle('active', buttonActionCount === actionCount);
    });
  }

  static shouldShowForCombatant(combatant) {
    if (!combatant?.actor || !game.user) return false;

    // Always show for GM (enables GM to set actions for any combatant)
    if (game.user.isGM) return true;

    // For non-GM users, only show if they own the actor
    const ownerLevel = CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER;
    const ownerUsers = game.users.contents.filter((user) => combatant.actor.testUserPermission(user, ownerLevel));
    if (!ownerUsers.length) return false;

    const nonGmOwners = ownerUsers.filter((user) => !user.isGM);
    if (nonGmOwners.length > 0) {
      return nonGmOwners.some((user) => user.id === game.user.id);
    }

    return false;
  }

  static async show() {
    const combatant = game.combat?.started ? game.combat.combatant : null;
    if (!combatant?.actor) return;

    const selectedActions = this.getSelectedActions(combatant.actor);

    let element = this.getHudElement();
    if (!element) {
      element = document.createElement('div');
      element.id = this.HUD_ID;
      element.classList.add('swade-automata-turn-hud');
      document.body.appendChild(element);
    }

    element.innerHTML = await renderTemplate(this.HUD_TEMPLATE, {
      isOneActionSelected: selectedActions === 1,
      isTwoActionsSelected: selectedActions === 2,
      isThreeActionsSelected: selectedActions === 3
    });

    this.activateListeners(element, combatant);
  }

  static async refresh(combat = game.combat) {
    const combatant = combat?.started ? combat.combatant : null;
    if (!combatant || !this.shouldShowForCombatant(combatant)) {
      this.hide();
      return;
    }

    await this.show();
  }

  static getSelectedActions(actor) {
    if (!actor) return 1;

    if (actor.effects.some((effect) => effect.name === this.THREE_ACTIONS_EFFECT)) return 3;
    if (actor.effects.some((effect) => effect.name === this.TWO_ACTIONS_EFFECT)) return 2;
    return 1;
  }

  static activateListeners(element, combatant) {
    element.querySelectorAll('[data-action-count]').forEach((button) => {
      button.addEventListener('click', async (event) => {
        event.preventDefault();
        const actionCount = Number(button.dataset.actionCount);
        const isGmSettingForPlayer = this.isGmSettingForPlayerOwnedActor(combatant?.actor);
        if (isGmSettingForPlayer) {
          // GM is setting actions for a player-owned character.
          // Apply locally first so the GM HUD reflects the change immediately,
          // then notify player-owned clients so their HUD/roll dialog stays in sync.
          await this.setActionCount(combatant, actionCount, { source: 'gm-hud-local' });
          await this.emitActionCountChange(combatant.actor.id, actionCount);
        } else {
          // Player or GM owner setting own actions
          await this.setActionCount(combatant, actionCount, { source: 'hud' });
        }
      });
    });
  }

  static isGmSettingForPlayerOwnedActor(actor) {
    if (!game.user?.isGM || !actor) return false;

    const ownerLevel = CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER;
    const hasNonGmOwner = game.users.contents.some((user) => !user.isGM && actor.testUserPermission(user, ownerLevel));
    return hasNonGmOwner;
  }

  static async setActionCount(combatant, actionCount, options = {}) {
    await this.setActionCountForActor(combatant?.actor, actionCount, options);
  }

  static async setActionCountForActor(actor, actionCount, options = {}) {
    if (!actor) return;
    if (![1, 2, 3].includes(actionCount)) return;

    const actionEffects = actor.effects.filter((effect) => {
      return effect.name === this.TWO_ACTIONS_EFFECT || effect.name === this.THREE_ACTIONS_EFFECT;
    });

    const primaryEffect = actionEffects[0];
    const extraEffects = actionEffects.slice(1);

    if (extraEffects.length > 0) {
      await actor.deleteEmbeddedDocuments('ActiveEffect', extraEffects.map((effect) => effect.id));
    }

    if (actionCount === 1) {
      if (primaryEffect) {
        await actor.deleteEmbeddedDocuments('ActiveEffect', [primaryEffect.id]);
      }
    } else if (primaryEffect) {
      const currentFlagValue = Number(primaryEffect.getFlag?.('swade-automata', 'actionCount'));
      if (currentFlagValue !== actionCount || primaryEffect.name !== `${actionCount} actions`) {
        await primaryEffect.update({
          name: `${actionCount} actions`,
          flags: {
            'swade-automata': {
              actionCount
            }
          }
        });
      }
    } else {
      await actor.createEmbeddedDocuments('ActiveEffect', [{
        name: `${actionCount} actions`,
        icon: 'icons/svg/combat.svg',
        duration: {
          rounds: 1,
          turns: 1
        },
        flags: {
          'swade-automata': {
            actionCount
          }
        }
      }]);
    }

    Hooks.callAll('swadeAutomataActionCountChanged', {
      actorId: actor.id,
      actionCount,
      source: options.source ?? 'unknown'
    });

    await this.refresh(game.combat);
  }

  /**
   * Emit a socket event to sync action count change from GM to character owner
   * @param {string} actorId - The actor ID whose actions are being changed
   * @param {number} actionCount - The new action count (1, 2, or 3)
   */
  static async emitActionCountChange(actorId, actionCount) {
    if (!game.socket) return;
    game.socket.emit('module.swade-automata.setActionCount', {
      actorId,
      actionCount
    });
  }

  /**
   * Socket handler for receiving action count updates from GM
   * @param {string} actorId - The actor ID to update
   * @param {number} actionCount - The new action count
   */
  static async handleRemoteActionCountChange(actorId, actionCount) {
    const actor = game.actors.get(actorId);
    if (!actor) return;

    try {
      await this.setActionCountForActor(actor, actionCount, { source: 'gm-hud' });
    } catch (error) {
      // If this client cannot mutate actor effects, still sync local UI state from the incoming value.
      Hooks.callAll('swadeAutomataActionCountChanged', {
        actorId,
        actionCount,
        source: 'gm-hud-fallback'
      });

      const currentCombatant = game.combat?.started ? game.combat.combatant : null;
      if (currentCombatant?.actor?.id === actorId) {
        this.setHudSelectedAction(actionCount);
      }
    }
  }
}
