export class TurnHudManager {
  static HUD_ID = 'swade-automata-turn-hud';
  static HUD_TEMPLATE = 'modules/swade-automata/templates/turnHud.hbs';
  static TWO_ACTIONS_EFFECT = '2 actions';
  static THREE_ACTIONS_EFFECT = '3 actions';

  static getHudElement() {
    return document.getElementById(this.HUD_ID);
  }

  static hide() {
    const element = this.getHudElement();
    if (element) element.remove();
  }

  static shouldShowForCombatant(combatant) {
    if (!combatant?.actor || !game.user) return false;

    // Always show for GM (enables GM to set actions for any combatant)
    if (game.user.isGM) return true;

    // For non-GM users, only show if they own the actor
    const ownerLevel = CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER;
    const ownerUsers = game.users.contents.filter((user) => combatant.actor.testUserPermission(user, ownerLevel));
    if (!ownerUsers.length) return false;

    const nonGmOwners = ownerUsers.filter((user) => !user.isGM);
    if (nonGmOwners.length > 0) {
      return nonGmOwners.some((user) => user.id === game.user.id);
    }

    return false;
  }

  static async show() {
    const combatant = game.combat?.started ? game.combat.combatant : null;
    if (!combatant?.actor) return;

    const selectedActions = this.getSelectedActions(combatant.actor);

    let element = this.getHudElement();
    if (!element) {
      element = document.createElement('div');
      element.id = this.HUD_ID;
      element.classList.add('swade-automata-turn-hud');
      document.body.appendChild(element);
    }

    element.innerHTML = await renderTemplate(this.HUD_TEMPLATE, {
      isOneActionSelected: selectedActions === 1,
      isTwoActionsSelected: selectedActions === 2,
      isThreeActionsSelected: selectedActions === 3
    });

    this.activateListeners(element, combatant);
  }

  static async refresh(combat = game.combat) {
    const combatant = combat?.started ? combat.combatant : null;
    if (!combatant || !this.shouldShowForCombatant(combatant)) {
      this.hide();
      return;
    }

    await this.show();
  }

  static getSelectedActions(actor) {
    if (!actor) return 1;

    if (actor.effects.some((effect) => effect.name === this.THREE_ACTIONS_EFFECT)) return 3;
    if (actor.effects.some((effect) => effect.name === this.TWO_ACTIONS_EFFECT)) return 2;
    return 1;
  }

  static activateListeners(element, combatant) {
    element.querySelectorAll('[data-action-count]').forEach((button) => {
      button.addEventListener('click', async (event) => {
        event.preventDefault();
        const actionCount = Number(button.dataset.actionCount);
        const isGmSettingForPlayer = game.user.isGM && !combatant.actor.testUserPermission(game.user, CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER);
        if (isGmSettingForPlayer) {
          // GM is setting actions for a player-owned character, use socket communication
          await this.emitActionCountChange(combatant.actor.id, actionCount);
        } else {
          // Player or GM owner setting own actions
          await this.setActionCount(combatant, actionCount, { source: 'hud' });
        }
      });
    });
  }

  static async setActionCount(combatant, actionCount, options = {}) {
    await this.setActionCountForActor(combatant?.actor, actionCount, options);
  }

  static async setActionCountForActor(actor, actionCount, options = {}) {
    if (!actor) return;
    if (![1, 2, 3].includes(actionCount)) return;

    const actionEffects = actor.effects.filter((effect) => {
      return effect.name === this.TWO_ACTIONS_EFFECT || effect.name === this.THREE_ACTIONS_EFFECT;
    });

    if (actionEffects.length > 0) {
      await actor.deleteEmbeddedDocuments('ActiveEffect', actionEffects.map((effect) => effect.id));
    }

    if (actionCount >= 2) {
      await actor.createEmbeddedDocuments('ActiveEffect', [{
        name: `${actionCount} actions`,
        icon: 'icons/svg/combat.svg',
        duration: {
          rounds: 1,
          turns: 1
        },
        flags: {
          'swade-automata': {
            actionCount
          }
        }
      }]);
    }

    Hooks.callAll('swadeAutomataActionCountChanged', {
      actorId: actor.id,
      actionCount,
      source: options.source ?? 'unknown'
    });

    await this.refresh(game.combat);
  }

  /**
   * Emit a socket event to sync action count change from GM to character owner
   * @param {string} actorId - The actor ID whose actions are being changed
   * @param {number} actionCount - The new action count (1, 2, or 3)
   */
  static async emitActionCountChange(actorId, actionCount) {
    if (!game.socket) return;
    game.socket.emit('module.swade-automata.setActionCount', {
      actorId,
      actionCount
    });
  }

  /**
   * Socket handler for receiving action count updates from GM
   * @param {string} actorId - The actor ID to update
   * @param {number} actionCount - The new action count
   */
  static async handleRemoteActionCountChange(actorId, actionCount) {
    const actor = game.actors.get(actorId);
    if (!actor) return;
    await this.setActionCountForActor(actor, actionCount, { source: 'gm-hud' });
  }
}
