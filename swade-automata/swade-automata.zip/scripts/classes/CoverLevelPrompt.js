import { COVER_LEVELS } from '../constants/combat.js';

export class CoverLevelPrompt {
  static async handleCreateActiveEffect(effect, userId) {
    if (game.user?.id !== userId) return;

    const hasCoverStatus = effect?.statuses?.has?.('cover') || effect?.statuses?.includes?.('cover');
    if (!hasCoverStatus) return;

    const currentName = String(effect?.name ?? '').trim().toLowerCase();
    if (currentName !== 'cover') return;

    const selectedCover = await this.show();
    if (!selectedCover) return;

    await effect.update({ name: selectedCover });
  }

  static async show() {
    return new Promise((resolve) => {
      const optionsHtml = COVER_LEVELS.map((level, index) => {
        const checked = index === 0 ? 'checked' : '';
        return `<label style="display:block; margin: 0.25rem 0;"><input type="radio" name="cover-level" value="${level.label}" ${checked}> ${level.label}</label>`;
      }).join('');

      new Dialog({
        title: 'Select Cover Level',
        content: `<form><p>Choose the cover type for this effect:</p>${optionsHtml}</form>`,
        buttons: {
          apply: {
            label: 'Apply',
            callback: (html) => {
              const selected = html.find('input[name="cover-level"]:checked').val();
              resolve(typeof selected === 'string' ? selected : null);
            }
          },
          cancel: {
            label: 'Cancel',
            callback: () => resolve(null)
          }
        },
        default: 'apply',
        close: () => resolve(null)
      }).render(true);
    });
  }
}
