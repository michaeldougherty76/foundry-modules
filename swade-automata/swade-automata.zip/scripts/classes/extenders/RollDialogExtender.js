import { TurnHudManager } from '../TurnHudManager.js';

export class RollDialogExtender {
  static registerHooks() {
    Hooks.on('renderRollDialog', this.onRenderRollDialog.bind(this));
    Hooks.on('swadeAutomataActionCountChanged', this.onActionCountChanged.bind(this));
  }

  static onRenderRollDialog(app, html) {
    if (!app?.ctx?.roll || app.ctx.roll.constructor.name !== 'TraitRoll') return;

    const actor = app?.ctx?.actor;
    if (!actor) return;

    const actionCount = TurnHudManager.getSelectedActions(actor);
    this.applyActionCountToRollDialog(html, actionCount);
    this.attachRollDialogMapListeners(app, html);
  }

  static onActionCountChanged({ actorId, actionCount }) {
    if (!actorId || ![1, 2, 3].includes(actionCount)) return;

    const openWindows = Object.values(ui.windows ?? {});
    for (const app of openWindows) {
      if (!app?.ctx?.roll || app.ctx.roll.constructor.name !== 'TraitRoll') continue;
      if (app?.ctx?.actor?.id !== actorId) continue;

      this.applyActionCountToRollDialog(app.element, actionCount);
    }
  }

  static applyActionCountToRollDialog(html, actionCount) {
    const root = this.resolveRootElement(null, html);
    if (!root) return;

    const mapValue = this.actionCountToMapValue(actionCount);
    const radioToSelect = root.querySelector(`input[type="radio"][name="map"][value="${mapValue}"]`);
    if (radioToSelect) {
      radioToSelect.checked = true;
    }
  }

  static attachRollDialogMapListeners(app, html) {
    const root = this.resolveRootElement(app, html);
    if (!root) return;

    root.querySelectorAll('input[type="radio"][name="map"]').forEach((input) => {
      input.addEventListener('change', async () => {
        if (!input.checked) return;

        const mapValue = Number(input.value);
        const actionCount = this.mapValueToActionCount(mapValue);
        await TurnHudManager.setActionCountForActor(app?.ctx?.actor, actionCount, { source: 'roll-dialog' });
      });
    });
  }

  static actionCountToMapValue(actionCount) {
    if (actionCount === 3) return -4;
    if (actionCount === 2) return -2;
    return 0;
  }

  static mapValueToActionCount(mapValue) {
    if (mapValue <= -4) return 3;
    if (mapValue <= -2) return 2;
    return 1;
  }

  static resolveRootElement(app, html) {
    if (html instanceof HTMLElement) return html;
    if (html?.[0] instanceof HTMLElement) return html[0];
    if (app?.element?.[0] instanceof HTMLElement) return app.element[0];
    return null;
  }

}
