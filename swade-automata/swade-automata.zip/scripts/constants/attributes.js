export const ATTRIBUTES = Object.freeze({
  AGILITY: "Agility",
  SMARTS: "Smarts",
  SPIRIT: "Spirit",
  STRENGTH: "Strength",
  VIGOR: "Vigor"
});

export const ATTRIBUTE_KEYS = Object.freeze({
  [ATTRIBUTES.AGILITY]: "agility",
  [ATTRIBUTES.SMARTS]: "smarts",
  [ATTRIBUTES.SPIRIT]: "spirit",
  [ATTRIBUTES.STRENGTH]: "strength",
  [ATTRIBUTES.VIGOR]: "vigor"
});

const ATTRIBUTE_KEYS_BY_LOWER_NAME = Object.freeze(
  Object.entries(ATTRIBUTE_KEYS).reduce((acc, [name, key]) => {
    acc[name.toLowerCase()] = key;
    return acc;
  }, {})
);

/**
 * Normalize a user-facing or key-form attribute name into a SWADE attribute key.
 * @param {string} attrName
 * @returns {string | null}
 */
export function normalizeAttributeKey(attrName) {
  if (typeof attrName !== "string") return null;

  const trimmedName = attrName.trim();
  if (!trimmedName) return null;

  const lowerName = trimmedName.toLowerCase();

  if (lowerName in ATTRIBUTE_KEYS_BY_LOWER_NAME) {
    return ATTRIBUTE_KEYS_BY_LOWER_NAME[lowerName];
  }

  // Also allow direct key usage like "agility".
  if (Object.values(ATTRIBUTE_KEYS).includes(lowerName)) {
    return lowerName;
  }

  return null;
}
