export const COVER_LEVELS = Object.freeze([
  { id: 'light', label: 'Light Cover' },
  { id: 'medium', label: 'Medium Cover' },
  { id: 'heavy', label: 'Heavy Cover' },
  { id: 'near-total', label: 'Near Total Cover' }
]);
