import { MODIFIER_DISPLAY_TYPE, SKILL } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { MODIFIER_TYPE, TARGET_MODIFIERS } from "../constants.js";

const displayData = {
    label: "Gangup Defense:",
    descriptor: "Gangup Defense",
    displayWidget: MODIFIER_DISPLAY_TYPE.DROPDOWN,
    value: "Normal",
    options: [
        {                    
            id: "gangupDefenseNone",
            category: "Gangup Defense",
            value: "None",
            descriptor: "None"
        },
        {                    
            id: "gangupDefenseOne",
            category: "Gangup Defense",
            value: "1 Ally",
            descriptor: "Gangup Defense (1 ally)"
        },
        {                    
            id: "gangupDefenseTwo",
            category: "Gangup Defense",
            value: "2 Allies",
            descriptor: "Gangup Defense (2 allies)"
        },
        {                    
            id: "gangupDefenseThree",
            category: "Gangup Defense",
            value: "3 Allies",
            descriptor: "Gangup Defense (3 allies)"
        },
        {                    
            id: "gangupDefenseFour",
            category: "Gangup Defense",
            value: "4 Allies",
            descriptor: "Gangup Defense (4 allies)"
        },
    ],
};

export class GangupDefenseModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=TARGET_MODIFIERS.GANGUP_DEFENSE;
            this.displayData = displayData;
            this.category = "Core Rules";
            this.descriptor=null; // To be set by Radio control
            this.value= this.calculateDefaultValue(); 
            
            this.offsetModifier = this.value > 4 ? -4 : -this.value; 
            this.offsetTargets = ["gangup"]; // Offsets Gangup modifiers
            this.type = MODIFIER_TYPE.TARGET;                
            this.calculateValue();
        }

        super.init();
    }
    isValidGangupToken(canvasToken, actorToken) {
        if (canvasToken.id !== actorToken.id 
            && canvasToken.document.disposition === actorToken.document.disposition
            && canvasToken.combatant != null
            && !canvasToken.combatant.defeated) {
            return true;
        } else {
            return false;
        }        
    }

    calculateDefaultValue() {
        const automataActor = this.getAutomataActor();
        const target = this.getAutomataTargetActor();
        var defaultValue = 0;

        if (target !== undefined 
            && target.token !== undefined 
            && automataActor !== undefined 
            && automataActor.token != undefined) {
            const adjacentTokens = [];
            game.canvas.tokens.placeables.forEach(canvasToken => {
                if (this.isValidGangupToken(canvasToken, target.token)) {
                    var targetTokenDistance = canvas.grid.measureDistance(target.token, canvasToken).toFixed(1);
                    var actorTokenDistance = canvas.grid.measureDistance(automataActor.token, canvasToken).toFixed(1);
                    if (actorTokenDistance < 2 && targetTokenDistance < 2) {
                        adjacentTokens.push(canvasToken);
                    }
                }
            }); 
            defaultValue = adjacentTokens.length;
        }
        return defaultValue;

        // var adjacentTokens = [];
        // game.canvas.tokens.placeables.forEach(canvasToken => {
        //     if (isValidGangupToken(canvasToken, targetToken)) {
        //         var targetTokenDistance = canvas.grid.measureDistance(targetToken, canvasToken).toFixed(1);
        //         var actorTokenDistance = canvas.grid.measureDistance(actorToken, canvasToken).toFixed(1);
        //         if (actorTokenDistance < 2 && targetTokenDistance < 2) {
        //             adjacentTokens.push(canvasToken);
        //         }
        //     }
        // });
        // return adjacentTokens;
    
    }

    isActive(currentModifier,currentModifiers) {
        const validSkillsUsed = [SKILL.FIGHTING];
        return this.skillOrWeaponSkillUsed(validSkillsUsed);
    }
    calculateValue() {
        this.descriptor = this.displayData.options[this.value].descriptor;
        this.offsetModifier = this.value > 4 ? -4 : -this.value;
    }
}