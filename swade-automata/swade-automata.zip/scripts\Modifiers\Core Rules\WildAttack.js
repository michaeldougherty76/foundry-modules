import { ACTIVE_EFFECT } from "../../Data/modifiers.js";
import { MODIFIER_DISPLAY_TYPE, SKILL } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { ACTOR_MODIFIERS, MODIFIER_TYPE } from "../constants.js";

export class WildAttackModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=ACTOR_MODIFIERS.WILD_ATTACK;
            // this.displayData={
            //     displayWidget: MODIFIER_DISPLAY_TYPE.CHECKBOX,
            //     label: "Wild Attack:",
            //     case: undefined
            // };
            this.category = "Core Rules";
            this.descriptor="Wild Attack";
            this.value=1;
            this.traitModifier = 2;
            this.damageModifier = '+2'
            this.type = MODIFIER_TYPE.ACTOR;  
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {    
        return this.actorHasEffect(ACTIVE_EFFECT.WILD_ATTACK) && this.skillOrWeaponSkillUsed([SKILL.FIGHTING]);
    }
    calculateValue() {
        this.traitModifier = (this.value == 1 ? 2 : 0);
        this.damageModifier = (this.value == 1 ? '+2' : undefined);
    }
}