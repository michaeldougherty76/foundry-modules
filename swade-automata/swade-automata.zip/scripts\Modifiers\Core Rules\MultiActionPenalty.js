import { ACTIVE_EFFECT } from "../../Data/modifiers.js";
import { MODIFIER_DISPLAY_TYPE } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { ACTOR_MODIFIERS, MODIFIER_TYPE } from "../constants.js";

const displayData = {
    label: "Multiple Actions:",
    descriptor: "Multiple Actions",
    displayWidget: MODIFIER_DISPLAY_TYPE.DROPDOWN,
    value: "1",
    descriptor: "Multi-Action (2)",
    options: [
        {                    
            id: "multiOne",
            category: "Number of Actions",
            value: "1 action",
            descriptor: "Multi-Action (1)"
        },
        {                    
            id: "multiTwo",
            category: "Number of Actions",
            value: "2 actions",
            descriptor: "Multi-Action (2)"
        },
        {                    
            id: "multiThree",
            category: "Number of Actions",
            value: "3 actions",
            descriptor: "Multi-Action (3)"
        }
    ],
};

const valueModifierTranslations = {
    0:0,
    1:-2,
    2:-4
};

export class MultiActionPenaltyModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=ACTOR_MODIFIERS.MULTI_ACTION_PENALTY;
            this.displayData = displayData;
            this.category = "Core Rules";
            this.descriptor="Multi-Action (2)"; // To be set by Radio control
            this.value= 0;
            this.traitModifier = 0;
            this.type = MODIFIER_TYPE.ACTOR;                
            this.calculateValue();
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        if (this.actorHasEffectById(ACTIVE_EFFECT.ADDITIONAL_ACTION_1)) {
            console.log("has extra action 1");
        }
        if (this.actorHasEffectById(ACTIVE_EFFECT.ADDITIONAL_ACTION_2)) {
            console.log("has extra action 2");
        }

        return this.actorHasEffectById(ACTIVE_EFFECT.ADDITIONAL_ACTION_1) || this.actorHasEffectById(ACTIVE_EFFECT.ADDITIONAL_ACTION_2)
    }
    calculateValue() {
        var modValue = 0;
        var extraActions = 0;
        if (this.actorHasEffectById(ACTIVE_EFFECT.ADDITIONAL_ACTION_1)) {
            modValue += -2;
            extraActions++;
        }
        if (this.actorHasEffectById(ACTIVE_EFFECT.ADDITIONAL_ACTION_2)) {
            modValue += -2;
            extraActions++;
        }
        this.value = extraActions;
        this.traitModifier = modValue;
        this.descriptor = "Multi-Action (" + extraActions+1 + ")";
    }
}