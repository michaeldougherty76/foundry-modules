import { EditModifierDialog } from '../../apps/EditModifierDialog.js';

export class TraitRollChatCardExtender {
  static registerHooks() {
    Hooks.on('renderChatMessageHTML', this.onRenderChatMessageHTML.bind(this));
    Hooks.once('ready', () => {
      this.wrapRerollFunctions();
    });
  }

  static applyPendingModifierOverrides(additionalMods) {
    if (!game.swadeAutomata?.pendingModifierOverrides) return;

    const overrides = game.swadeAutomata.pendingModifierOverrides;
    for (const [label, newValue] of Object.entries(overrides)) {
      const existingMod = additionalMods.find((m) => m.label === label);
      if (existingMod) {
        existingMod.value = newValue;
      }
    }

    delete game.swadeAutomata.pendingModifierOverrides;
  }

  static onRenderChatMessageHTML(message, html) {
    const $html = $(html);

    const swadeRollMessage = $html.find('.swade-roll-message');
    if (swadeRollMessage.length === 0) return;

    const modifiersDetails = $html.find('.modifiers');
    if (modifiersDetails.length === 0) return;

    const modifiersList = $html.find('.modifier-list li');
    if (modifiersList.length === 0) return;

    const modifiersData = [];

    let modifiersTableHtml = '<div class="swade-automata-modifiers">';
    modifiersTableHtml += '<h4 class="modifiers-header">Modifiers</h4>';
    modifiersTableHtml += '<table class="modifiers-table">';

    let index = 0;
    modifiersList.each(function() {
      const text = $(this).text();
      const parts = text.split(':');
      if (parts.length === 2) {
        const label = parts[0].trim();
        const value = parts[1].trim();
        modifiersData.push({ label, value });
        modifiersTableHtml += `<tr class="modifier-row" data-modifier-index="${index}"><td class="modifier-label">${label}</td><td class="modifier-value">${value}</td></tr>`;
        index += 1;
      }
    });

    modifiersTableHtml += '</table></div>';
    modifiersDetails.replaceWith(modifiersTableHtml);

    $html.find('.modifier-row').on('click', async function() {
      const modifierIndex = parseInt($(this).data('modifier-index'));
      const modifierData = modifiersData[modifierIndex];
      const newValue = await EditModifierDialog.show(modifierData.label, modifierData.value);

      if (newValue !== undefined && newValue !== modifierData.value) {
        await TraitRollChatCardExtender.updateModifierInMessage(message, modifierData.label, newValue);
      }
    });
  }

  static wrapRerollFunctions() {
    const originalRerollFree = CONFIG.Dice.rolls[0].rerollFree;
    const originalRerollBenny = CONFIG.Dice.rolls[0].rerollBenny;

    if (originalRerollFree) {
      CONFIG.Dice.rolls[0].rerollFree = async function(event) {
        const target = event.currentTarget;
        const id = target.closest('.message').dataset.messageId;
        const msg = game.messages.get(id);

        TraitRollChatCardExtender.applyModifiedModifiersToRoll(msg);
        return originalRerollFree.call(this, event);
      };
    }

    if (originalRerollBenny) {
      CONFIG.Dice.rolls[0].rerollBenny = async function(event) {
        const target = event.currentTarget;
        const id = target.closest('.message').dataset.messageId;
        const msg = game.messages.get(id);

        TraitRollChatCardExtender.applyModifiedModifiersToRoll(msg);
        return originalRerollBenny.call(this, event);
      };
    }
  }

  static applyModifiedModifiersToRoll(msg) {
    const modifiedMods = msg?.flags?.['swade-automata']?.modifiedModifiers;
    if (!modifiedMods || !msg?.rolls?.[0]) return;

    const roll = msg.rolls[0];
    if (!roll.options?.modifiers) return;

    for (const [label, newValue] of Object.entries(modifiedMods)) {
      const modifier = roll.options.modifiers.find((m) => m.label === label);
      if (modifier) {
        modifier.value = newValue;

        const parsedNewValue = parseInt(newValue);
        const isPositive = parsedNewValue >= 0;

        for (let i = 0; i < roll.terms.length; i += 1) {
          const term = roll.terms[i];
          if (term.options?.flavor === label) {
            term.number = Math.abs(parsedNewValue);
            if (i > 0 && roll.terms[i - 1].operator !== undefined) {
              roll.terms[i - 1].operator = isPositive ? '+' : '-';
            }
          }
        }
      }
    }
  }

  static async updateModifierInMessage(message, modifierLabel, newValue) {
    const rolls = message.rolls;
    if (!rolls || rolls.length === 0) {
      console.warn('No rolls found in message');
      return;
    }

    const messageData = message.toObject();

    messageData.rolls = messageData.rolls.map((rollDataString) => {
      const rollData = JSON.parse(rollDataString);

      let modifier = null;
      let oldModifierValue = null;

      if (rollData.options?.modifiers) {
        modifier = rollData.options.modifiers.find((m) => m.label === modifierLabel);
        if (modifier) {
          oldModifierValue = modifier.value;
          modifier.value = newValue;
        }
      }

      if (rollData.formula && modifier && oldModifierValue !== null) {
        const parsedOldValue = parseInt(oldModifierValue);
        const parsedNewValue = parseInt(newValue);
        const isPositive = parsedNewValue >= 0;

        if (rollData.terms) {
          for (let i = 0; i < rollData.terms.length; i += 1) {
            const term = rollData.terms[i];
            if (term.class === 'NumericTerm' && term.options?.flavor === modifierLabel) {
              term.number = Math.abs(parsedNewValue);
              if (i > 0 && rollData.terms[i - 1].class === 'OperatorTerm') {
                rollData.terms[i - 1].operator = isPositive ? '+' : '-';
              }
            }
          }
        }

        const oldFormulaOperator = parsedOldValue >= 0 ? '+' : '-';
        const oldFormulaValue = Math.abs(parsedOldValue);
        const newFormulaOperator = isPositive ? '+' : '-';
        const newFormulaValue = Math.abs(parsedNewValue);

        const oldFormulaPattern = `${oldFormulaOperator} ${oldFormulaValue}[${modifierLabel}]`;
        const newFormulaPattern = `${newFormulaOperator} ${newFormulaValue}[${modifierLabel}]`;
        rollData.formula = rollData.formula.replace(oldFormulaPattern, newFormulaPattern);
        rollData.total = this.calculateRollTotal(rollData);
      }

      return JSON.stringify(rollData);
    });

    const parser = new DOMParser();
    const doc = parser.parseFromString(messageData.content, 'text/html');

    const warning = document.createElement('div');
    warning.className = 'swade-automata-edit-warning';
    const now = new Date();
    const timeStr = now.toLocaleTimeString();
    warning.innerHTML = `<em>Modified by ${game.user.name} at ${timeStr}</em>`;

    const messageContent = doc.querySelector('.message-content') || doc.body.firstChild;
    if (messageContent) {
      messageContent.insertBefore(warning, messageContent.firstChild);
    } else {
      doc.body.insertBefore(warning, doc.body.firstChild);
    }

    messageData.content = doc.body.innerHTML;

    if (!messageData.flags) messageData.flags = {};
    if (!messageData.flags['swade-automata']) messageData.flags['swade-automata'] = {};
    if (!messageData.flags['swade-automata'].modifiedModifiers) {
      messageData.flags['swade-automata'].modifiedModifiers = {};
    }
    messageData.flags['swade-automata'].modifiedModifiers[modifierLabel] = newValue;

    messageData.rolls = messageData.rolls.map((rollDataString) => {
      const rollData = JSON.parse(rollDataString);
      return Roll.fromData(rollData);
    });

    await message.delete();
    await ChatMessage.create(messageData);
  }

  static calculateRollTotal(rollData) {
    let total = 0;
    let operator = '+';

    for (const term of rollData.terms) {
      if (term.class === 'OperatorTerm') {
        operator = term.operator;
      } else if (term.class === 'NumericTerm') {
        const value = term.number;
        total = operator === '+' ? total + value : total - value;
      } else if (term.class === 'PoolTerm' && term.total !== undefined) {
        total = operator === '+' ? total + term.total : total - term.total;
      }
    }

    return total;
  }
}
