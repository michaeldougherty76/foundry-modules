import { TurnHudManager } from '../TurnHudManager.js';

export class CombatTrackerExtender {
  static registerHooks() {
    Hooks.on('updateCombat', this.onUpdateCombat.bind(this));
    Hooks.on('combatStart', this.onCombatStart.bind(this));
    Hooks.on('deleteCombat', this.onDeleteCombat.bind(this));
  }

  static sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  static async onUpdateCombat(combat, updates) {
    if ('round' in updates) {
      await this.sleep(200); // Pause to let time to show card distribution
    }

    let isReady = true;
    if ('turn' in updates) {
      const currentTurnIndex = combat.turn;
      const previousTurnIndex = currentTurnIndex > 0 ? currentTurnIndex - 1 : combat.turns.length - 1;
      const previousCombatant = combat.turns[previousTurnIndex];

      if (previousCombatant) {
        const previousActor = previousCombatant.actor;

        if (previousActor) {
          const actionEffects = previousActor.effects.filter((e) => {
            return e.name === '2 actions' || e.name === '3 actions';
          });

          for (const effect of actionEffects) {
            await effect.delete();
          }
        }
      }

      combat.turns.forEach((turn) => {
        if (turn.cardValue === null) {
          isReady = false;
        }
      });
    }

    if (isReady) {
      //const actor = AutomataActor.createFromActor(combat.combatant.actor);
      //await actor.showCombatActionMessage();
    }

    await TurnHudManager.refresh(combat);
  }

  static async onCombatStart(combat) {
    await TurnHudManager.refresh(combat);
  }

  static async onDeleteCombat() {
    TurnHudManager.hide();
  }
}
