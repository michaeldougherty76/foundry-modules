import { ACTIVE_EFFECT } from "../../Data/modifiers.js";
import { MODIFIER_DISPLAY_TYPE } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { ACTOR_MODIFIERS, MODIFIER_TYPE } from "../constants.js";

export class RecoilModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=ACTOR_MODIFIERS.RECOIL;
            this.displayData={
                displayWidget: MODIFIER_DISPLAY_TYPE.CHECKBOX,
                label: "Recoil:",
                case: undefined
            };
            this.category = "Core Rules";
            this.descriptor="Recoil";
            this.value=0;               // Default is checked
            this.traitModifier = 0;    // Default is -2 penalty
            this.type = MODIFIER_TYPE.ACTOR;                
            this.subscribedModifiers = [ACTOR_MODIFIERS.RATE_OF_FIRE];
        }
        super.init();
    }
    // Display the selector if a weapon with a ROF > 1 was used.
    isActive(currentModifier,currentModifiers) {
        return this.itemHasMultipleROF();
    }
    calculateValue() {
        this.traitModifier = (this.value == 1 ? -2 : 0);
    }
    listenerUpdate(modifierId,newValue) {
        if (modifierId === ACTOR_MODIFIERS.RATE_OF_FIRE) {
            if (newValue >= 2) {
                this.value = 1
            } else {
                this.value = 0
            }
            this.calculateValue();
            this.updated = true;
        }
    }

}