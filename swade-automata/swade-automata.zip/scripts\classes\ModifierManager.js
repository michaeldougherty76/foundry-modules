import { ConditionProcessor } from './ConditionProcessor.js';
import { AutomataActor, AutomataSkill, AutomataItem } from '../wrappers/index.js';

export class ModifierManager {
  static modifierConfig = null;

  /**
   * Convert a roll modifier value to a number, returning null when invalid.
   * @param {string | number | undefined} value
   * @returns {number | null}
   */
  static toNumericValue(value) {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }

  /**
   * Normalize a modifier label for tolerant matching.
   * @param {string | undefined | null} value
   * @returns {string}
   */
  static normalizeModifierLabel(value) {
    if (value === undefined || value === null) return "";
    return String(value).toLowerCase().replace(/[^a-z0-9]+/g, "").trim();
  }

  /**
   * Check if an existing modifier entry matches a configured system rule label.
   * @param {RollModifier | undefined} mod
   * @param {string | undefined} ruleLabel
   * @returns {boolean}
   */
  static matchesSystemRule(mod, ruleLabel) {
    const modLabelRaw = mod?.label ?? mod?.name ?? mod?.modifier;
    const expected = this.normalizeModifierLabel(ruleLabel);
    const actual = this.normalizeModifierLabel(modLabelRaw);

    if (!expected || !actual) return false;
    if (actual === expected) return true;

    // Allow partial matches for localized or prefixed labels.
    return actual.includes(expected) || expected.includes(actual);
  }

  /**
   * Check if an existing SWADE/system modifier label already exists in roll modifiers.
   * @param {RollModifier[] | undefined} additionalMods
   * @param {string | undefined} systemRuleOverrides
   * @returns {boolean}
   */
  static hasSystemRuleModifier(additionalMods, systemRuleOverrides) {
    if (!systemRuleOverrides || !Array.isArray(additionalMods) || additionalMods.length === 0) {
      return false;
    }

    return additionalMods.some((mod) => this.matchesSystemRule(mod, systemRuleOverrides));
  }

  /**
   * Remove matching SWADE/system modifiers from the existing roll modifiers array.
   * @param {RollModifier[] | undefined} additionalMods
   * @param {string | undefined} overrideSystemRule
   */
  static removeSystemRuleModifier(additionalMods, overrideSystemRule) {
    if (!overrideSystemRule || !Array.isArray(additionalMods) || additionalMods.length === 0) {
      return;
    }

    for (let i = additionalMods.length - 1; i >= 0; i -= 1) {
      const mod = additionalMods[i];
      if (this.matchesSystemRule(mod, overrideSystemRule)) {
        additionalMods.splice(i, 1);
      }
    }
  }

  /**
   * Remove modifiers currently managed by this module from the provided list.
   * This allows deterministic re-application in late hooks like swadePreRollSkill.
   * @param {RollModifier[] | undefined} additionalMods
   */
  static stripManagedModifiers(additionalMods) {
    if (!Array.isArray(additionalMods) || !Array.isArray(this.modifierConfig?.modifiers)) {
      return;
    }

    const managedLabels = new Set(
      this.modifierConfig.modifiers
        .map((m) => this.normalizeModifierLabel(m?.label))
        .filter(Boolean)
    );

    for (let i = additionalMods.length - 1; i >= 0; i -= 1) {
      const mod = additionalMods[i];
      const label = mod?.label ?? mod?.name ?? mod?.modifier;
      const normalized = this.normalizeModifierLabel(label);
      if (managedLabels.has(normalized)) {
        additionalMods.splice(i, 1);
      }
    }
  }

  /**
   * Initialize and load the modifiers configuration from JSON file
   * Should be called during module initialization
   */
  static async initialize() {
    const response = await fetch('modules/swade-automata/data/modifiers.json');
    this.modifierConfig = await response.json();
    console.log('ModifierManager initialized with config:', this.modifierConfig);
  }

  /**
   * Check if conditions for a modifier are met using ConditionProcessor
   * @param {Object} modifierDef - The modifier definition from JSON
   * @param {TokenDocument | undefined} sourceToken - The attacking token
   * @param {TokenDocument | undefined} targetToken - The target token
   * @param {SwadeItem} skill - The skill being used
   * @param {SwadeItem} item - The item being used
   * @param {boolean} isRangedAttack - true if ranged attack
   * @param {boolean} isMeleeAttack - true if melee attack
   * @returns {boolean} Whether the conditions are met
   */
  static checkConditions(modifierDef, sourceToken, targetToken, skill, item, isRangedAttack, isMeleeAttack) {
    // If no conditions, modifier always applies
    if (!modifierDef.conditions) {
      return true;
    }

    // Get actors from tokens
    const actor = AutomataActor.wrap(sourceToken?.actor);
    const target = AutomataActor.wrap(targetToken?.actor);
    const wrappedSkill = AutomataSkill.wrap(skill);
    const wrappedItem = AutomataItem.wrap(item);

    // Evaluate the condition string using ConditionProcessor
    return ConditionProcessor.Evaluate(modifierDef.conditions, actor, target, wrappedSkill, wrappedItem);
  }

  /**
   * Automate modifiers for attack rolls
   * @param {TokenDocument | undefined} sourceToken - The attacking token
   * @param {TokenDocument | undefined} targetToken - The first-targeted token, or undefined if no targets
   * @param {SwadeItem} skill - The skill being used for the attack
   * @param {SwadeItem} item - The weapon/item being used for the attack
   * @param {boolean} isRangedAttack - true if ranged weapon or mixed with non-fighting skill
   * @param {boolean} isMeleeAttack - true if melee weapon or mixed with fighting skill
   * @param {RollModifier[]} additionalMods - Array of existing modifiers
   * @param {BestNonStackingMods} bestNonStackingMods - Best cover and illumination modifiers
   * @returns {RollModifier[]} Array of modifiers to add
   */
  static automateModifiers(
    sourceToken,
    targetToken,
    skill,
    item,
    isRangedAttack,
    isMeleeAttack,
    additionalMods,
    bestNonStackingMods
  ) {
    const modifiers = [];
    const appliedModifiersById = new Map();

    // Check if config is loaded
    if (!this.modifierConfig) {
      console.warn('ModifierManager not initialized yet');
      return modifiers;
    }

    const processModifier = (modifierDef, explicitValue = null) => {
      if (this.hasSystemRuleModifier(additionalMods, modifierDef.systemRuleOverrides)) {
        return false;
      }

      const hasOverrideSystemRule = this.hasSystemRuleModifier(additionalMods, modifierDef.overrideSystemRule);

      // Check if conditions are met
      const conditionsMet = this.checkConditions(modifierDef, sourceToken, targetToken, skill, item, isRangedAttack, isMeleeAttack);

      // If the system rule already exists, allow override rules to trigger even when a custom condition is brittle.
      if (conditionsMet || hasOverrideSystemRule) {
        if (modifierDef.overrideSystemRule) {
          this.removeSystemRuleModifier(additionalMods, modifierDef.overrideSystemRule);
        }

        // Format value as string with +/- sign
        const numValue = explicitValue === null ? this.toNumericValue(modifierDef.value) : explicitValue;
        if (numValue === null) {
          return false;
        }

        const formattedValue = numValue >= 0 ? `+${numValue}` : `${numValue}`;

        const generatedModifier = {
          id: modifierDef.id,
          label: modifierDef.label,
          value: formattedValue,
          ignore: modifierDef.autoEnabled !== true
        };

        modifiers.push(generatedModifier);

        if (modifierDef.id) {
          appliedModifiersById.set(modifierDef.id, {
            value: numValue,
            ignore: generatedModifier.ignore
          });
        }

        return true;
      }

      return false;
    };

    const baseModifiers = [];
    const offsetModifiers = [];
    for (const modifierDef of this.modifierConfig.modifiers) {
      if (Array.isArray(modifierDef.offsets) && modifierDef.offsets.length > 0) {
        offsetModifiers.push(modifierDef);
      } else {
        baseModifiers.push(modifierDef);
      }
    }

    for (const modifierDef of baseModifiers) {
      processModifier(modifierDef);
    }

    for (const modifierDef of offsetModifiers) {
      const offsets = Array.isArray(modifierDef.offsets) ? modifierDef.offsets : [];
      const offsetValues = [];

      for (const offsetId of offsets) {
        const existing = appliedModifiersById.get(offsetId);
        if (!existing || existing.ignore === true) continue;
        offsetValues.push(existing.value);
      }

      // Offset modifiers only apply when at least one referenced modifier already exists.
      if (offsetValues.length === 0) {
        continue;
      }

      const maxOffsetValue = Math.max(...offsetValues);
      const capValue = this.toNumericValue(modifierDef.value);
      if (capValue === null) {
        continue;
      }

      const resolvedValue = Math.min(capValue, maxOffsetValue);
      processModifier(modifierDef, resolvedValue);
    }

    return modifiers;
  }
}
