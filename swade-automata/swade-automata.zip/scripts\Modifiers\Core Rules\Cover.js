import { MODIFIER_DISPLAY_TYPE } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { MODIFIER_TYPE, TARGET_MODIFIERS } from "../constants.js";

const displayData = {
    label: "Cover:",
    descriptor: "Cover",
    displayWidget: MODIFIER_DISPLAY_TYPE.DROPDOWN,
    value: "Normal",
    options: [
        {                    
            id: "coverNone",
            category: "Cover",
            value: "None",
            descriptor: "None"
        },
        {                    
            id: "coverLight",
            category: "Cover",
            value: "Light",
            descriptor: "Cover (Light)"
        },
        {                    
            id: "coverMedium",
            category: "Cover",
            value: "Medium",
            descriptor: "Cover (Medium)"
        },
        {                    
            id: "coverHeavy",
            category: "Cover",
            value: "Heavy",
            descriptor: "Cover (Heavy)"
        },
        {                    
            id: "coverNearTotal",
            category: "Cover",
            value: "Near Total",
            descriptor: "Cover (Near Total)"
        },
    ],
};

const valueModifierTranslations = {
    0:0,
    1:-2,
    2:-4,
    3:-6,
    4:-8
};

export class CoverModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=TARGET_MODIFIERS.COVER;
            this.displayData = displayData;
            this.category = "Core Rules";
            this.descriptor=null; 
            this.value= 0;
            this.traitModifier = 0;
            this.type = MODIFIER_TYPE.TARGET;                
            this.calculateValue();
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        return true;
    }
    calculateValue() {
        this.traitModifier = valueModifierTranslations[this.value];
        this.descriptor = this.displayData.options[this.value].descriptor;
    }
}