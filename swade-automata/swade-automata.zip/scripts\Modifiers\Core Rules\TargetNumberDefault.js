import { BaseModifier } from "../BaseModifier.js";
import { ACTOR_MODIFIERS, MODIFIER_TYPE } from "../constants.js";

export class TargetNumberDefaultModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=ACTOR_MODIFIERS.TARGET_NUMBER_DEFAULT;
            this.category = "Core Rules";
            this.value=1;               // Default is checked
            this.targetNumberValue = 4; // Set the default Target Number
            this.type = MODIFIER_TYPE.ACTOR;                
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        return true;
    }
    calculateValue() {
        this.targetNumberValue = 4;
    }
}