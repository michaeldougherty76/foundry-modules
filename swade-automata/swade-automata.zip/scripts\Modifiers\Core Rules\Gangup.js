import { MODIFIER_DISPLAY_TYPE, SKILL } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { MODIFIER_TYPE, TARGET_MODIFIERS } from "../constants.js";

const displayData = {
    label: "Gangup:",
    descriptor: "Gangup",
    displayWidget: MODIFIER_DISPLAY_TYPE.DROPDOWN,
    value: "Normal",
    options: [
        {                    
            id: "gangupNone",
            category: "Gangup",
            value: "None",
            descriptor: "None"
        },
        {                    
            id: "gangupOne",
            category: "Gangup",
            value: "1 Ally",
            descriptor: "Gangup (1 ally)"
        },
        {                    
            id: "gangupTwo",
            category: "Gangup",
            value: "2 Allies",
            descriptor: "Gangup (2 allies)"
        },
        {                    
            id: "gangupThree",
            category: "Gangup",
            value: "3 Allies",
            descriptor: "Gangup (3 allies)"
        },
        {                    
            id: "gangupFour",
            category: "Gangup",
            value: "4 Allies",
            descriptor: "Gangup (4 allies)"
        },
    ],
};

export class GangupModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=TARGET_MODIFIERS.GANGUP;
            this.displayData = displayData;
            this.category = "Core Rules";
            this.descriptor=null; // To be set by Radio control
            this.value= this.calculateDefaultValue(); 
            
            this.traitModifier = this.value > 4 ? 4 : this.value; 
            this.type = MODIFIER_TYPE.TARGET;                
            this.calculateValue();
        }

        super.init();
    }
    calculateDefaultValue() {
        const automataActor = this.getAutomataActor();
        const target = this.getAutomataTargetActor();
        var defaultValue = 0;

        if (target) {
            const filteredTokensWithinRange = [];
            const tokensWithinRange = target.getTokensWithinRange(
                2, 
                { 
                    disposition: [automataActor.getDisposition()], 
                    defeated: false 
                });
            tokensWithinRange.forEach(token => {
                if (token.id !== automataActor.token.id) {
                    filteredTokensWithinRange.push(token);
                }
            });
            defaultValue = filteredTokensWithinRange.length;
        }
        return defaultValue;
    }

    isActive(currentModifier,currentModifiers) {
        const validSkillsUsed = [SKILL.FIGHTING];
        return this.skillOrWeaponSkillUsed(validSkillsUsed);
    }
    calculateValue() {
        this.descriptor = this.displayData.options[this.value].descriptor;
        this.traitModifier = this.value > 4 ? 4 : this.value;
    }
}