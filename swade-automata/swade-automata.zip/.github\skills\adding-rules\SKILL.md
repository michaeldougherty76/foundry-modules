# Skill: Adding Rules to modifiers.json

## Purpose

Add a new entry to the `modifiers` array in `data/modifiers.json`. Each entry defines an automatic modifier that is applied to a SWADE trait roll (attack, skill check, etc.) when its condition evaluates to `true`.

---

## Output Format

Append a new object to the `modifiers` array in `data/modifiers.json`:

```json
{
  "id": "<generated-id>",
  "label": "<human-readable label>",
  "value": <numeric modifier>,
  "autoEnabled": <boolean>,
  "offsets": ["<modifier-id-1>", "<modifier-id-2>"],
  "conditions": "<condition expression string>",
  "conditionDescriptions": [
    "<human-readable condition part 1>",
    "<human-readable condition part 2>"
  ],
  "systemRuleOverrides": "<optional swade system modifier label>",
  "overrideSystemRule": "<optional swade system modifier label>"
}
```

---

## Field Rules

### `id`
- Kebab-case slug derived from the rule description.
- Must be unique within the array.
- Format: lowercase words joined with hyphens. Strip articles (a, an, the). Keep it short and descriptive.
- Examples:
  - "Target has Arrow Deflection" → `target-arrow-deflection`
  - "Actor is Distracted" → `actor-distracted`
  - "Shooting into melee" → `shooting-into-melee`

### `label`
- Human-readable title of the rule. Sentence-case.
- Should be concise enough to display in a modifier list UI.
- Derived directly from the rule description given by the user.

### `value`
- Numeric trait die modifier. Negative penalises, positive adds a bonus.
- **Always specified by the user.** Do not infer or default it.

### `autoEnabled`
- Boolean flag that controls default checkbox state in the SWADE roll dialog.
- `true`: show modifier checked/applied by default.
- `false`: show modifier in dialog but unchecked/ignored by default.
- If omitted, treat as `false`.

### `offsets` (optional)
- Array of modifier `id` values this modifier can offset.
- Offset modifiers are processed after all non-offset modifiers.
- If none of the referenced ids are currently added, this modifier is not added.
- Compute value using:
  - `maxOffset = max(values of currently-added referenced modifiers)`
  - `resolvedValue = min(value, maxOffset)`
- Example: `value = 4` and referenced max is `2` results in `+2`.

### `conditions`
- A JavaScript expression string that evaluates to `true` when the modifier applies.
- Evaluated by `ConditionProcessor.Evaluate`. See the section below for all available context.
- If the condition cannot be expressed with the available context, **respond with a clear explanation of what is missing** instead of adding the entry.

### `conditionDescriptions`
- Array of human-readable strings that describe each logical part of `conditions`.
- Translate each `&&` segment into a concise phrase.
- Keep ordering aligned with the corresponding condition segments.
- Example:
  - `"item?.isMeleeWeaponUsed?.() && actor.usedAnySkill(skill,['Fighting']) && target.hasEffect('Prone')"`
  - `[
      "Using Melee Weapon",
      "Using Fighting Skill",
      "Target has Prone effect"
    ]`

### `systemRuleOverrides` (optional)
- String label for a SWADE system modifier this rule overrides.
- If a matching system modifier is already present in `additionalMods`, this custom rule should not be processed.
- Use exact label text where possible.

### `overrideSystemRule` (optional)
- String label for a SWADE system modifier to replace.
- If this custom rule's conditions pass and the matching system modifier exists in `additionalMods`, remove that system modifier and add this custom rule.
- If the system modifier is not present, this custom rule can still be added when conditions pass.
- Matching is tolerant (case/format differences, localized/prefixed labels).

---

## Condition Expression Context

The condition string is compiled with `new Function(...)` and has access only to the following named variables. Do **not** reference anything outside this list.

| Variable | Type | Description |
|---|---|---|
| `actor` | `AutomataActor` | The actor making the roll (attacker / skill user) |
| `target` | `AutomataActor` | The targeted actor (may be `null`) |
| `skill` | `AutomataSkill` (proxied) | The skill item being rolled |
| `item` | `AutomataItem` (proxied) | The weapon / power / item driving the roll |
| `hasEffect(a, name)` | function | Returns `true` if actor `a` has an active effect named `name` |
| `hasItem(a, name)` | function | Returns `true` if actor `a` owns an item named `name` |
| `hasAttribute(a, attr)` | function | Returns `true` if actor `a` has the named attribute |
| `getAttributeValue(a, attr)` | function | Returns the die type integer (4/6/8/10/12) for `a`'s attribute |
| `usedAnySkill(skill, [names])` | function | Returns `true` if `skill.name` is in the provided array |

### Methods on `AutomataActor` (`actor` / `target`)

| Method | Signature | Notes |
|---|---|---|
| `hasEffect` | `hasEffect(effectName: string): boolean` | Checks active effects and item-sourced effects |
| `hasItem` | `hasItem(itemName: string): boolean` | Checks the actor's item list |
| `hasAttribute` | `hasAttribute(attrName: string): boolean` | Valid names: `agility`, `smarts`, `spirit`, `strength`, `vigor` |
| `usedAnySkill` | `usedAnySkill(skill, names: string[]): boolean` | Pass the `skill` context variable as first arg |

Transparent proxy: `actor.system.*` and other standard SWADE/Foundry document properties are accessible directly through `actor` and `target`.

### Properties on `skill` / `item`

- `skill.name` — The skill's display name (e.g. `"Shooting"`, `"Fighting"`, `"Athletics"`)
- `item.name` — The item's display name (e.g. `"Longbow"`)
- `skill.system.*` / `item.system.*` — SWADE system data, accessible transparently

### What is NOT available in conditions

- `isRangedAttack` / `isMeleeAttack` — passed to `checkConditions` but **not** injected into the condition expression
- Canvas, token position, distance calculations
- Any global like `game`, `canvas`, `ui`, `Hooks`

If a rule requires any unavailable data, state clearly: *"This condition cannot be built — `<variable>` is not available in the condition expression context."*

---

## Condition Expression Examples

```js
// Target has the Arrow Deflection effect
"target.hasEffect('Arrow Deflection')"

// Actor used Shooting or Athletics skill
"actor.usedAnySkill(skill, ['Athletics', 'Shooting'])"

// Actor is Distracted
"actor.hasEffect('Distracted')"

// Actor has an Edge called Marksman
"actor.hasItem('Marksman')"

// Target has the Vulnerable effect AND actor used Fighting
"target.hasEffect('Vulnerable') && skill.name === 'Fighting'"

// Actor used Fighting skill
"skill.name === 'Fighting'"

// Combine: target has Vulnerable AND actor used any combat skill
"target.hasEffect('Vulnerable') && actor.usedAnySkill(skill, ['Fighting', 'Shooting', 'Athletics'])"
```

---

## Step-by-Step Workflow

1. **Read `data/modifiers.json`** to check for existing IDs and understand current entries.
2. **Derive the `id`** — kebab-case slug from the rule description, unique within the array.
3. **Derive the `label`** — clean, human-readable version of the description.
4. **Confirm the `value`** — must be provided by the user.
5. **Set `autoEnabled`** based on whether the rule should be checked by default in the roll dialog.
6. **Set `offsets`** only when the modifier should cap itself based on existing modifier ids.
7. **Build the `conditions` string** using only the available context variables. If impossible, stop and explain why.
8. **Build `conditionDescriptions`** by translating each condition segment into human-readable phrases.
9. **Add `systemRuleOverrides`** only when the user specifies a SWADE system modifier label to suppress.
10. **Add `overrideSystemRule`** when the user wants to replace an existing SWADE modifier if present.
11. **Append** the new entry to the `modifiers` array in `data/modifiers.json`.

---

## Example: Full Entry

Rule: "Target has Arrow Deflection when using Shooting or Athletics, −1 penalty"

```json
{
  "id": "target-arrow-deflection",
  "label": "Target has Arrow Deflection",
  "value": -1,
  "autoEnabled": true,
  "offsets": [],
  "conditions": "actor.usedAnySkill(skill, ['Athletics', 'Shooting']) && target.hasEffect('Arrow Deflection')",
  "conditionDescriptions": [
    "Using Athletics or Shooting Skill",
    "Target has Arrow Deflection effect"
  ],
  "systemRuleOverrides": "Arrow Deflection",
  "overrideSystemRule": ""
}
```
