export class ROFSelectorDisplayWidget {
    constructor() { }

    createWidget(modifier){
        const modifierId = modifier.id;
        const displayData = modifier.displayData;
        const weapon = modifier.getAutomataItem();
        const value = modifier.value;

        let standardROFEntries = '';
        const maxROF = weapon.getROF();
        const currentShots = weapon.getCurrentShots();

        displayData.options.forEach(option => {
            if (option.value <= maxROF) {
                const isChecked = (value === option.value);
                standardROFEntries += `
                    <td style="border-width: 1; border-style: solid;text-align: center;">
                        <span>
                            <input class="modifier-${modifierId}" type="radio" id="${option.id}" name="${modifierId}" placeholder="Recoil" value="${option.value}"${(isChecked ?' checked': '')} onchange="recalc();">
                            <label for="${option.id}">${option.displayValue}</label>
                        </span>
                    </td>
                `;
            }
        });

        let penaltyRow = '';
        displayData.options.forEach(option => {
            if (option.value <= maxROF) {
                penaltyRow += `<td style="border-width: 1; border-style: solid;text-align: center;"><span>${(option.value===1?0:-2)}</span></td>`;
            }
        });
        
        let ammoRow = '';
        displayData.options.forEach(option => {
            if (option.value <= maxROF) {
                ammoRow += `<td style="border-width: 1; border-style: solid;text-align: center;"><span>${option.ammo}</span></td>`;
            }
        });
        
        let bonusRow = '';
        const content = `
        <div>
            <span>Current shots in weapon: </span><span>` + currentShots + `</span>
            <table style="width: 100%;table-layout: fixed;">
                <tr>
                    <td colspan=${maxROF}></td>
                    ` + bonusRow + `
                </tr>
                <tr>
                    <td style="border-width: 1; border-style: solid;">ROF:</td>
                    ` + standardROFEntries + `
                </tr>
                <tr>
                    <td style="border-width: 1; border-style: solid;"><span>Penalty:</span></td>
                    ` + penaltyRow + `
                </tr>
                <tr>
                    <td style="border-width: 1; border-style: solid;"><span>Ammo Used:</span></td>
                    ` + ammoRow + `
                </tr>
            </table>
        </div>
        `;
       return content;
    }
    
    getUIDataForModifier(html, modifier){
        const relevantNodes = html.find(`.modifier-${modifier.id}`);
        relevantNodes.each(nodeIndex => {
            if (relevantNodes[nodeIndex].checked) {
                const newROF = parseInt(relevantNodes[nodeIndex].id.split('-')[1]);
                console.log(newROF);
                console.log(modifier);
                modifier.value = parseInt(relevantNodes[nodeIndex].value);                                
            }
        });
    }
}