export class DropdownDisplayWidget {
    createWidget(modifier) {
        const modifierId = modifier.id;
        const displayData = modifier.displayData;
        const currentValue = modifier.value;
        const header = displayData.label;
        const options = displayData.options.reduce((acc,cur) => {
            if (acc.hasOwnProperty(cur.category)) {
                acc[cur.category].push(cur);
            } else {
                acc[cur.category] = [cur];
            }
            return acc;
        },{});
        let selectHtml = `<select class="modifier-${modifierId}" name="traits" onChange="recalc();">`;
        Object.keys(options).forEach(category => {
            selectHtml += `<optgroup label="${category}">`;
            options[category].forEach(option => {
                selectHtml +=`<option value="${option.value}"${option.value === displayData.options[currentValue].value ? ' selected' : ''}>${option.value}</option>`;
            });            
        });
        selectHtml += "</select>";

        // let content = `
        // <div style="display: flex; flex-direction: horizontal;justify-content: space-between;">
        //     <div style="display: flex; align-items: center;">${header}</div>
        //     ${selectHtml}
        // </div>
        // `;
        return selectHtml;    
    }
    getUIDataForModifier (html, modifier) {
        const relevantNodes = html.find(`.modifier-${modifier.id}`);
        const selectedValue = (relevantNodes[0])[relevantNodes[0].selectedIndex].value;
        var valueIndex = 0;
        modifier.displayData.options.forEach (option => {
            if (option.value === selectedValue) {
                modifier.value = valueIndex;
            }
            valueIndex++;
        });
    }    
}

