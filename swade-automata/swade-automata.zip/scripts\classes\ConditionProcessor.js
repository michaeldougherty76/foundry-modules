import { AutomataActor, AutomataSkill, AutomataItem } from '../wrappers/index.js';

export class ConditionProcessor {
  static ConditionCompileCache = class {
    constructor(maxEntries = 500) {
      this.maxEntries = maxEntries;
      this.cache = new Map();
    }

    getOrCompile(conditionString, argNames) {
      const argSignature = argNames.join("|");
      const cacheKey = `${argSignature}::${conditionString}`;

      const cachedFn = this.cache.get(cacheKey);
      if (cachedFn) {
        // Touch for simple LRU behavior.
        this.cache.delete(cacheKey);
        this.cache.set(cacheKey, cachedFn);
        return cachedFn;
      }

      const compiledFn = new Function(...argNames, `return ${conditionString};`);
      this.cache.set(cacheKey, compiledFn);

      if (this.cache.size > this.maxEntries) {
        const oldestKey = this.cache.keys().next().value;
        this.cache.delete(oldestKey);
      }

      return compiledFn;
    }
  };

  static compileCache = new ConditionProcessor.ConditionCompileCache();

  /**
   * Evaluates a condition string and returns a boolean result
   * @param {string} conditionString - The condition to evaluate
   * @param {Actor} actor - The actor performing the action
   * @param {Actor} target - The target actor
   * @param {Item} skill - The skill being used
   * @param {Item} item - The original item (weapon, power, etc.)
   * @returns {boolean} - The result of the condition evaluation
   */
  static Evaluate(conditionString, actor, target, skill, item) {
    if (!conditionString) return false;

    const wrappedActor = AutomataActor.wrap(actor);
    const wrappedTarget = AutomataActor.wrap(target);
    const wrappedSkill = AutomataSkill.wrap(skill);
    const wrappedItem = AutomataItem.wrap(item);
    
    // Create a safe evaluation context with available variables
    const context = {
      actor: wrappedActor,
      target: wrappedTarget,
      skill: wrappedSkill,
      item: wrappedItem,
      // Helper functions that can be used in conditions
      hasEffect: (actorToCheck, effectName) => {
        return actorToCheck?.hasEffect?.(effectName) ?? false;
      },
      hasItem: (actorToCheck, itemName) => {
        return actorToCheck?.hasItem?.(itemName) ?? false;
      },
      hasAttribute: (actorToCheck, attrName) => {
        return actorToCheck?.hasAttribute?.(attrName) ?? false;
      },
      getAttributeValue: (actorToCheck, attrName) => {
        return actorToCheck?.system?.attributes?.[attrName]?.value ?? 0;
      },
      usedAnySkill: (skillToCheck, skillNames) => {
        if (!skillToCheck || !Array.isArray(skillNames)) return false;
        return skillNames.includes(skillToCheck.name);
      }
    };

    const contextKeys = Object.keys(context);
    const contextValues = Object.values(context);

    let evalFunction;
    try {
      // Compile each unique condition once and reuse it.
      evalFunction = ConditionProcessor.compileCache.getOrCompile(conditionString, contextKeys);
    } catch (error) {
      console.error('ConditionProcessor: Error compiling condition:', {
        conditionString,
        error
      });
      return false;
    }

    try {
      const result = evalFunction(...contextValues);
      return !!result; // Ensure boolean return
    } catch (error) {
      console.error('ConditionProcessor: Error executing condition:', {
        conditionString,
        contextKeys,
        error
      });
      return false;
    }
  }
}
