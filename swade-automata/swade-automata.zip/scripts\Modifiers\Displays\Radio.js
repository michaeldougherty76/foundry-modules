export class RadioDisplayWidget {
    constructor() { }

    createWidget(modifier){
        const modifierId = modifier.id;
        const displayData = modifier.displayData;
        const value = modifier.value;        
        const header = displayData.label;
        const options = displayData.options.reduce((acc,cur) => {
            acc += `
            <div>
                <input class="modifier-${modifierId}" type="radio" id="${cur.id}" name="${modifierId}" placeholder="${cur.descriptor}" value="${cur.value}" ${(cur.value == value || (value && (cur.id === value))) ? "checked": ""} onChange="recalc();">
                <label for="${cur.id}">${cur.displayValue}</label>
            </div>
            `;
            return acc;
        },"");
        return options;    
    }

    getUIDataForModifier(html, modifier){
        const relevantNodes = html.find(`.modifier-${modifier.id}`);
        relevantNodes.each(nodeIndex => {
            if (relevantNodes[nodeIndex].checked) {                    
                modifier.value = parseInt(relevantNodes[nodeIndex].value);
            }
        });
    }
}