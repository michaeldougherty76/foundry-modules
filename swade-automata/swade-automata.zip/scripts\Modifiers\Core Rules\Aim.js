import { ACTIVE_EFFECT } from "../../Data/modifiers.js";
import { MODIFIER_DISPLAY_TYPE, SKILL } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { ACTOR_MODIFIERS, MODIFIER_TYPE, TARGET_MODIFIERS } from "../constants.js";

const displayData = {
    label: "Aim:",
    descriptor: "Aim",
    displayWidget: MODIFIER_DISPLAY_TYPE.DROPDOWN,
    value: "Normal",
    options: [
        {                    
            id: "aimNone",
            category: "Aim",
            value: "Aim (None)",
            descriptor: "Aim (None)"
        },
        {                    
            id: "aimStandard",
            category: "Aim",
            value: "Aim",
            descriptor: "Aim (+2)"
        },
        {                    
            id: "aimIgnorePenalties",
            category: "Aim",
            value: "Aim (Ignore -4 in penalties)",
            descriptor: "Aim (ignore up to -4 in penalties)" // Range/Cover/Called Shot, Scale, Speed
        },
   ],
};

export class AimModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=ACTOR_MODIFIERS.AIM;
            this.displayData = displayData;
            this.category = "Core Rules";
            this.descriptor=null; // To be set by Radio control
            this.value= 1; 
            
            this.traitModifier = this.value === 1 ? 2 : undefined; 
            this.type = MODIFIER_TYPE.ACTOR;                
            this.calculateValue();
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        const validSkillsUsed = [SKILL.SHOOTING, SKILL.ATHLETICS];
        return this.skillOrWeaponSkillUsed(validSkillsUsed) && this.actorHasEffect(ACTIVE_EFFECT.AIMING);
    }
    calculateValue() {
        if (this.value === 0) {
            this.traitModifier = undefined;
            this.offsetModifier = undefined;
            this.offsetTargets = undefined;
        }
        if (this.value === 1) {
            this.traitModifier = 2;
            this.offsetModifier = undefined;
            this.offsetTargets = undefined;
        }
        if (this.value === 2) {
            this.traitModifier = undefined;
            this.offsetTargets = ["range", "cover", "scale", "speed", "calledShot"];
            this.offsetModifier = 4;
        }
        this.descriptor = this.displayData.options[this.value].descriptor;
    }
}