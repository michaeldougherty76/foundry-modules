import { AutomataActor } from "../../classes/Automata/AutomataActor.js";
import { MODIFIER_DISPLAY_TYPE } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { ACTOR_MODIFIERS, MODIFIER_TYPE } from "../constants.js";

const displayData = {
    label: "Wounds:",
    descriptor: "Wounds",
    displayWidget: MODIFIER_DISPLAY_TYPE.DROPDOWN,
    value: "0",
    options: [
        {
            id: "woundNone",
            category: "Wounds",
            value: "0",
            descriptor: "None"
        },
        {                    
            id: "woundOne",
            category: "Wounds",
            value: "1",
            descriptor: "Wounds (1)"
        },
        {                    
            id: "woundTwo",
            category: "Wounds",
            value: "2",
            descriptor: "Wounds (2)"
        },
        {                    
            id: "woundThree",
            category: "Wounds",
            value: "3",
            descriptor: "Wounds (3)"
        }
    ],
};

export class WoundsModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            const automataActor = AutomataActor.createFromUUID(this.actorId);
            this.id=ACTOR_MODIFIERS.WOUNDS;
            this.displayData = displayData;
            this.category = "Core Rules";
            this.descriptor=null; // To be set by Radio control
            this.value= automataActor.dataReference["woundsPenalty"];
            this.traitModifier = 0;
            this.type = MODIFIER_TYPE.ACTOR;                
            this.calculateValue();
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        return true;
    }
    calculateValue() {
        const data = this.displayData.options[Math.abs(this.value)];
        this.descriptor = data.descriptor;
        this.traitModifier = -parseInt(data.value);
    }
}