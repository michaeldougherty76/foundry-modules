import { ACTIVE_EFFECT } from "../../Data/modifiers.js";
import { ACTION, MODIFIER_DISPLAY_TYPE, USED } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { ACTOR_MODIFIERS, MODIFIER_TYPE, TARGET_MODIFIERS } from "../constants.js";

export class WeaponDamageModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            const item = this.getAutomataItem();
            console.log(item);
            this.id=ACTOR_MODIFIERS.WEAPON_DAMAGE;
            this.category = "Core Rules";
            this.value=1;               // Default is checked
            this.type = MODIFIER_TYPE.ACTOR;
            this.displayData={
                label: "Weapon:" + item.getName(),
            };

            if (item !== undefined && item.getType() === "weapon") {
                this.setBaseDamage = item.getDamage();
                this.setBonusDamage = item.getBonusDamage();
                if (this.targetExists()) {
                    this.includeTargetActions = [ACTION.CREATE_DAMAGE_CARD, ACTION.CREATE_DAMAGE_WITH_RAISE_CARD]
                } else {
                    this.includeGlobalActions = [ACTION.CREATE_DAMAGE_CARD, ACTION.CREATE_DAMAGE_WITH_RAISE_CARD]
                }       
//                this.includeActions = ["damageTarget","bonusDamageTarget"];
            }            
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {     
        return this.actorUsed([USED.WEAPON]);
    }
    calculateValue() {
        // console.log("OK!");
        // if (this.targetExists()) {
        //     this.includeTargetActions = ["actionCreateDamageCard","actionCreateDamageCardWithRaise"]
        // } else {
        //     this.includeGlobalActions = ["actionCreateDamageCard","actionCreateDamageCardWithRaise"]
        // }
    }
}