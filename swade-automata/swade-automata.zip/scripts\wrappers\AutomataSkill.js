export class AutomataSkill {
  /**
   * @param {Item | null | undefined} swadeSkill
   */
  constructor(swadeSkill) {
    this.swadeSkill = swadeSkill ?? null;
  }

  /**
   * Wrap a SWADE skill item while preserving transparent property access.
   * @param {Item | AutomataSkill | null | undefined} skill
   * @returns {AutomataSkill | null}
   */
  static wrap(skill) {
    if (!skill) return null;
    if (skill instanceof AutomataSkill) return skill;

    const wrapper = new AutomataSkill(skill);
    return new Proxy(wrapper, {
      get(target, prop, receiver) {
        if (prop in target) {
          return Reflect.get(target, prop, receiver);
        }

        const value = target.swadeSkill?.[prop];
        return typeof value === "function" ? value.bind(target.swadeSkill) : value;
      },
      set(target, prop, value, receiver) {
        if (prop in target) {
          return Reflect.set(target, prop, value, receiver);
        }

        if (!target.swadeSkill) return false;
        target.swadeSkill[prop] = value;
        return true;
      },
      has(target, prop) {
        return prop in target || (target.swadeSkill ? prop in target.swadeSkill : false);
      }
    });
  }

  /**
   * Access the original SWADE skill explicitly when needed.
   * @returns {Item | null}
   */
  get raw() {
    return this.swadeSkill;
  }
}
