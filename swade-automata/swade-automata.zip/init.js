import { ModifierManager } from './scripts/classes/ModifierManager.js';
import { TurnHudManager } from './scripts/classes/TurnHudManager.js';
import { CoverLevelPrompt } from './scripts/classes/CoverLevelPrompt.js';
import { RollDialogExtender } from './scripts/classes/extenders/RollDialogExtender.js';
import { TraitRollChatCardExtender } from './scripts/classes/extenders/TraitRollChatCardExtender.js';
import { CombatTrackerExtender } from './scripts/classes/extenders/CombatTrackerExtender.js';

Hooks.on('init', () => {
  RollDialogExtender.registerHooks();
  TraitRollChatCardExtender.registerHooks();
  CombatTrackerExtender.registerHooks();
});

Hooks.on(`ready`, async () => {
  game.automata = {};
  await ModifierManager.initialize();

  // Register socket listener for GM action count changes
  game.socket.on('module.swade-automata.setActionCount', async (data) => {
    await TurnHudManager.handleRemoteActionCountChange(data.actorId, data.actionCount);
  });

  await TurnHudManager.refresh();

	console.log('SWADE Automata | Ready');  
  Hooks.callAll('ready-automata');
});

Hooks.on('createActiveEffect', async (effect, options, userId) => {
  await CoverLevelPrompt.handleCreateActiveEffect(effect, userId);
});


Hooks.on("swadeCalculateDefaultAttackMods", (sourceToken, targetToken, skill, item, isRangedAttack, isMeleeAttack, additionalMods, bestNonStackingMods) => {
  // sourceToken: TokenDocument | undefined - The attacking token
  // targetToken: TokenDocument | undefined - The first-targeted token, or undefined if no targets
  // skill: SwadeItem - The skill being used for the attack
  // item: SwadeItem - The weapon/item being used for the attack
  // isRangedAttack: boolean - true if ranged weapon or mixed with non-fighting skill
  // isMeleeAttack: boolean - true if melee weapon or mixed with fighting skill
  // additionalMods: RollModifier[] - Array of modifiers with {label: string, value: string|number, ignore?: boolean}
  // bestNonStackingMods: {bestCover: RollModifier|undefined, bestIllumination: RollModifier|undefined}
  
  TraitRollChatCardExtender.applyPendingModifierOverrides(additionalMods);
  
  // Get automated modifiers and add them to the list
  const automatedModifiers = ModifierManager.automateModifiers(
    sourceToken,
    targetToken,
    skill,
    item,
    isRangedAttack,
    isMeleeAttack,
    additionalMods,
    bestNonStackingMods
  );
  automatedModifiers.forEach(mod => additionalMods.push(mod));
});

Hooks.on('swadePreRollSkill', (actor, skill, roll, modifiers, options) => {
  try {
    const item = options?.item;
    const isAttack = item?.type === 'weapon';
    if (!isAttack || !skill) {
      return true;
    }

    const sourceToken = actor?.getActiveTokens?.(false, true)?.[0]?.document;
    const targetToken = game.user.targets.first()?.document;
    const { isRanged = null, isMelee = null } = item.system ?? {};
    const isRangedAttack = isRanged && (!isMelee || skill?.system?.swid !== 'fighting');
    const isMeleeAttack = isMelee && (!isRanged || skill?.system?.swid === 'fighting');

    // Reconcile from the final modifier list shown in the dialog.
    ModifierManager.stripManagedModifiers(modifiers);

    const automatedModifiers = ModifierManager.automateModifiers(
      sourceToken,
      targetToken,
      skill,
      item,
      isRangedAttack,
      isMeleeAttack,
      modifiers,
      {}
    );

    automatedModifiers.forEach((mod) => modifiers.push(mod));
  } catch (error) {
    console.error('[swade-automata] swadePreRollSkill reconciliation error', error);
  }

  return true;
});


