const database = {
    "Rifle (Laser)" : {
        "anim":"modules/JB2A_DnD5e/Library/Generic/Weapon_Attacks/Ranged/LaserShot_01_Regular_Blue_30ft_1600x400.webm",
        "sound":"modules/swade-eos-combat/sounds/LaserGun.mp3"
    },
    "Pistol (Laser)" : {
        "anim":"modules/JB2A_DnD5e/Library/Generic/Weapon_Attacks/Ranged/LaserShot_01_Regular_Blue_30ft_1600x400.webm",
        "sound":"modules/swade-eos-combat/sounds/LaserGun.mp3"
    },
    "Assault Rifle" : {
        "anim":"modules/JB2A_DnD5e/Library/Generic/Weapon_Attacks/Ranged/Bullet_02_Regular_Orange_30ft_1600x400.webm",
        "sound":"https://assets.forge-vtt.com/bazaar/modules/gAudioBundle-2/assets/src/Guns%20and%20Explosions/Gun_Revolver_Pistol_Shot_04.ogg"
    },
    "Sniper Rifle" : {
        "anim":"modules/JB2A_DnD5e/Library/Generic/Weapon_Attacks/Ranged/Bullet_02_Regular_Orange_30ft_1600x400.webm",
        "sound":"https://assets.forge-vtt.com/bazaar/modules/gAudioBundle-2/assets/src/Guns%20and%20Explosions/Gun_Revolver_Pistol_Shot_04.ogg"
    },
    "Minigun" : {
        "anim":"modules/JB2A_DnD5e/Library/Generic/Weapon_Attacks/Ranged/Bullet_02_Regular_Orange_30ft_1600x400.webm",
        "sound":"https://assets.forge-vtt.com/bazaar/modules/gAudioBundle-2/assets/src/Guns%20and%20Explosions/Gun_Revolver_Pistol_Shot_04.ogg"
    },    
    "Heavy Pistol" : {
        "anim":"modules/JB2A_DnD5e/Library/Generic/Weapon_Attacks/Ranged/Bullet_02_Regular_Orange_30ft_1600x400.webm",
        "sound":"https://assets.forge-vtt.com/bazaar/modules/gAudioBundle-2/assets/src/Guns%20and%20Explosions/Gun_Revolver_Pistol_Shot_04.ogg"
    },    
    '"Ophelia"' : {
        "anim":"modules/JB2A_DnD5e/Library/Generic/Weapon_Attacks/Ranged/Bullet_02_Regular_Orange_30ft_1600x400.webm",
        "sound":"https://assets.forge-vtt.com/bazaar/modules/gAudioBundle-2/assets/src/Guns%20and%20Explosions/Gun_Revolver_Pistol_Shot_04.ogg"
    },
    '"Svetlana"' : {
        "anim":"modules/JB2A_DnD5e/Library/Generic/Weapon_Attacks/Ranged/Bullet_02_Regular_Orange_30ft_1600x400.webm",
        "sound":"https://assets.forge-vtt.com/bazaar/modules/gAudioBundle-2/assets/src/Guns%20and%20Explosions/12%20Gauge%20Shotgun/Shotgun_Fire_Round_Eject_01.ogg"
    },
    'Doberman Double Barrel' : {
        "anim":"modules/JB2A_DnD5e/Library/Generic/Weapon_Attacks/Ranged/Bullet_02_Regular_Orange_30ft_1600x400.webm",
        "sound":"https://assets.forge-vtt.com/bazaar/modules/gAudioBundle-2/assets/src/Guns%20and%20Explosions/12%20Gauge%20Shotgun/Shotgun_Fire_Round_Eject_01.ogg"
    },
    'Double-Barrel Shotgun' : {
        "anim":"modules/JB2A_DnD5e/Library/Generic/Weapon_Attacks/Ranged/Bullet_02_Regular_Orange_30ft_1600x400.webm",
        "sound":"https://assets.forge-vtt.com/bazaar/modules/gAudioBundle-2/assets/src/Guns%20and%20Explosions/12%20Gauge%20Shotgun/Shotgun_Fire_Round_Eject_01.ogg"
    }


};
export default database;

