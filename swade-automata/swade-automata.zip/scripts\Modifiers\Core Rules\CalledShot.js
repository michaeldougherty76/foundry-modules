import { MODIFIER_DISPLAY_TYPE, SKILL } from "../../mod/constants.js";
import { BaseModifier } from "../BaseModifier.js";
import { MODIFIER_TYPE, TARGET_MODIFIERS } from "../constants.js";

export class CalledShotModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=TARGET_MODIFIERS.CALLED_SHOT;
            this.displayData={
                displayWidget: MODIFIER_DISPLAY_TYPE.CHECKBOX,
                label: "Called Shot (to Vitals):",
                case: undefined
            };
            this.category = "Core Rules";
            this.descriptor="Called Shot (to Vitals)";
            this.value=0;           
            this.damageModifier = undefined;
            this.type = MODIFIER_TYPE.TARGET;                
            this.calculateValue();
        }

        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        const validSkillsUsed = [SKILL.ATHLETICS, SKILL.FIGHTING, SKILL.SHOOTING]
        return this.skillOrWeaponSkillUsed(validSkillsUsed);
    }
    calculateValue() {
        this.damageModifier = (this.value === 1 ? '+4' : undefined);
    }
}