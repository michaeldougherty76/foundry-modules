import { BaseModifier } from "../BaseModifier.js";
import { ACTOR_MODIFIERS, MODIFIER_TYPE } from "../constants.js";

export class BaseTraitModifier extends BaseModifier{
    constructor (inputData,existingModifier) {
        super(inputData,existingModifier);
    }
    init() {
        if (!this.isInitialized) {
            this.id=ACTOR_MODIFIERS.BASE_TRAIT_MODIFIER;
            this.type = MODIFIER_TYPE.ACTOR;                
            this.category = "Core Rules";
            this.descriptor="Base Trait Modifier";
            const item = this.getAutomataItem();
            this.value=item.getDie().modifier !== 0 ? 1 : 0; //Only show as a modifier if the modifier is not zero
            this.traitModifier = item.getDie().modifier;
            if (item.getName() === "Unskilled Attempt" || (item.getType() === "weapon" && item.getWeaponSkill().getName() === "Unskilled Attempt")) {
                this.bannerText = "Unskilled Attempt!";
            }                        
        }
        super.init();
    }
    isActive(currentModifier,currentModifiers) {
        return true;
    }
    calculateValue() {
        const item = this.getAutomataItem();
        this.traitModifier = item.getDie().modifier;
        if (item.getName() === "Unskilled Attempt") {
            this.bannerText = "Unskilled Attempt!";
        }            
    }
}