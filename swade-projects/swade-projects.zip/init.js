import { TaskManager, ProjectManager } from './scripts/classes/ProjectManager.js';
import { ProjectsDialog } from './scripts/classes/ProjectsDialog.js';

const MODULE_ID = 'swade-projects';
const DEFAULT_HOTKEY = {
  key: 'KeyJ',
  modifiers: ['Control', 'Alt']
};

/**
 * Register keybindings during init so Foundry picks them up in controls configuration.
 */
Hooks.once('init', () => {
  game.settings.register(MODULE_ID, 'tasks', {
    name: 'SWADE Tasks Data',
    scope: 'world',
    config: false,
    type: Array,
    default: []
  });

  // Legacy storage key retained for migration support.
  game.settings.register(MODULE_ID, 'projects', {
    name: 'SWADE Projects Data',
    scope: 'world',
    config: false,
    type: Array,
    default: []
  });

  game.keybindings.register(MODULE_ID, 'openProjectsDialog', {
    name: 'SWADEPROJECTS.Keybindings.OpenDialog',
    hint: 'SWADEPROJECTS.Keybindings.OpenDialogHint',
    editable: [DEFAULT_HOTKEY],
    onDown: () => {
      ProjectsDialog.toggle();
      return true;
    }
  });
});

/**
 * Initialize persistent storage when the world is ready.
 */
Hooks.once('ready', async () => {
  console.log(`${MODULE_ID} | Initializing...`);
  await TaskManager.initialize();

  console.log(`${MODULE_ID} | Ready! Press Ctrl+Alt+J to open the Projects Manager`);
});

/**
 * Add a button to the scene controls
 */
Hooks.on('getSceneControlButtons', (buttons) => {
  const controls = Array.isArray(buttons) ? buttons : buttons?.controls;
  if (!Array.isArray(controls)) return;

  // Add to a commonly available control group.
  const targetControl = controls.find(b => b.name === 'token') ?? controls.find(b => b.name === 'notes');
  
  if (targetControl) {
    targetControl.tools.push({
      name: 'swade-projects',
      title: 'SWADEPROJECTS.SceneControl.Title',
      icon: 'fas fa-tasks',
      onClick: () => ProjectsDialog.toggle(),
      button: true
    });
  }
});

// Export classes for external use if needed
window.SWADEProjects = {
  TaskManager,
  ProjectManager,
  ProjectsDialog
};
