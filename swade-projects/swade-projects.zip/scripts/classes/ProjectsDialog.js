import { TaskManager } from './ProjectManager.js';
import {
  getUniqueCategories,
  sortTasksByCategory,
  validateTask,
  createBlankTask,
  normalizeTask,
  parseSuccessColorThresholds,
  formatSuccessColorThresholds,
  resolveSuccessDisplayColor,
  SUCCESS_DISPLAY_MODES,
  TASK_TYPES
} from '../utils/helpers.js';

/**
 * Main dialog window for managing projects
 */
export class ProjectsDialog extends Application {
  constructor(options = {}) {
    super(options);
    this.currentTab = 'tasks';
  }

  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      id: 'swade-projects-dialog',
      title: game.i18n.localize('SWADEPROJECTS.Dialog.Title'),
      template: 'modules/swade-projects/templates/projects-dialog.hbs',
      width: 900,
      height: 700,
      resizable: true,
      minimizable: true,
      classes: ['swade-projects-dialog']
    });
  }

  /**
   * Prepare template data
   */
  async getData(options = {}) {
    const allTasks = sortTasksByCategory(TaskManager.getAllTasks())
      .map((task) => this._prepareTaskForDisplay(task));

    const basicTasks = allTasks.filter((task) => task.taskType === TASK_TYPES.TASK);
    const projectTasks = allTasks.filter((task) => task.taskType === TASK_TYPES.PROJECT);

    const projectCategoryNames = getUniqueCategories(projectTasks);
    const projectGroups = projectCategoryNames.map((name) => ({
      name,
      tasks: projectTasks.filter((task) => (task.category || 'Uncategorized') === name)
    }));

    return {
      basicTasks,
      projectTasks,
      projectGroups
    };
  }

  /**
   * Set up event listeners after render
   */
  activateListeners(html) {
    super.activateListeners(html);

    // Tab switching
    html.find('.swade-projects-tab').on('click', (e) => this._switchTab(e));

    // Add new task button
    html.find('#add-task-btn').on('click', () => this._showTaskForm(null));

    // Close dialog button
    html.find('#close-dialog-btn').on('click', () => this.close());

    // Edit task buttons
    html.find('.swade-projects-card').on('click', '.edit-btn', (e) => {
      e.stopPropagation();
      const taskId = $(e.currentTarget).closest('.swade-projects-card').data('task-id');
      this._showTaskForm(taskId);
    });

    // Delete task buttons
    html.find('.swade-projects-card').on('click', '.delete-btn', (e) => {
      e.stopPropagation();
      const taskId = $(e.currentTarget).closest('.swade-projects-card').data('task-id');
      this._deleteTask(taskId);
    });
  }

  /**
   * Switch between player and enemy tabs
   */
  _switchTab(event) {
    event.preventDefault();
    const tab = $(event.currentTarget).data('tab');
    
    this.currentTab = tab;

    // Update tab UI
    $(event.currentTarget).parent().find('.swade-projects-tab').removeClass('active');
    $(event.currentTarget).addClass('active');

    // Show/hide content
    this.element.find('.swade-projects-content').hide();
    this.element.find(`.swade-projects-content[data-content="${tab}"]`).show();
  }

  /**
   * Show task form dialog
   */
  async _showTaskForm(taskId) {
    let task = taskId ? TaskManager.getTaskById(taskId) : createBlankTask(TASK_TYPES.TASK);
    
    if (!task) {
      ui.notifications.error(game.i18n.localize('SWADEPROJECTS.Notifications.ProjectError'));
      return;
    }

    task = normalizeTask(task);

    const isNewTask = !taskId;
    const formHtml = await renderTemplate('modules/swade-projects/templates/project-form.hbs', {
      task,
      isProjectTask: task.taskType === TASK_TYPES.PROJECT,
      taskTypeModes: {
        task: task.taskType === TASK_TYPES.TASK,
        project: task.taskType === TASK_TYPES.PROJECT
      },
      successDisplayModes: {
        number: task.successDisplayMode === SUCCESS_DISPLAY_MODES.NUMBER,
        color: task.successDisplayMode === SUCCESS_DISPLAY_MODES.COLOR
      },
      successColorThresholdsText: formatSuccessColorThresholds(task.successColorThresholds)
    });

    const dialog = new Dialog(
      {
        title: isNewTask
          ? game.i18n.localize('SWADEPROJECTS.Dialog.AddTask')
          : game.i18n.localize('SWADEPROJECTS.Dialog.EditTask'),
        content: formHtml,
        buttons: {},
        render: (html) => {
          const taskTypeField = html.find('#task-type');
          const projectOnlyFields = html.find('.swade-projects-project-only-group');
          const modeField = html.find('#project-success-display-mode');
          const colorModeFields = html.find('.swade-projects-success-color-rules-group');

          const syncFormVisibility = () => {
            const isProjectTask = taskTypeField.val() === TASK_TYPES.PROJECT;
            const useColorMode = modeField.val() === SUCCESS_DISPLAY_MODES.COLOR;

            projectOnlyFields.toggle(isProjectTask);
            colorModeFields.toggle(isProjectTask && useColorMode);
          };

          taskTypeField.on('change', syncFormVisibility);
          modeField.on('change', syncFormVisibility);
          syncFormVisibility();

          html.find('form.swade-projects-form').on('submit', async (event) => {
            event.preventDefault();
            const wasSaved = await this._saveTask(html, task, isNewTask);
            if (wasSaved) dialog.close();
          });

          html.find('#cancel-form').on('click', (event) => {
            event.preventDefault();
            dialog.close();
          });
        }
      },
      {
        classes: ['swade-projects-form-dialog']
      }
    );

    dialog.render(true);
  }

  /**
   * Save task data
   */
  async _saveTask(html, originalTask, isNewTask) {
    const form = html.find('form')[0];
    const formData = new FormData(form);
    const taskType = formData.get('taskType') === TASK_TYPES.PROJECT
      ? TASK_TYPES.PROJECT
      : TASK_TYPES.TASK;
    const successDisplayMode = formData.get('successDisplayMode') || SUCCESS_DISPLAY_MODES.NUMBER;

    const taskData = {
      id: originalTask.id,
      taskType,
      name: formData.get('name').trim(),
      description: formData.get('description').trim()
    };

    if (taskType === TASK_TYPES.PROJECT) {
      const {
        thresholds: successColorThresholds,
        errors: thresholdErrors
      } = parseSuccessColorThresholds(formData.get('successColorThresholds'));

      if (successDisplayMode === SUCCESS_DISPLAY_MODES.COLOR && thresholdErrors.length > 0) {
        ui.notifications.error(thresholdErrors.join(', '));
        return false;
      }

      Object.assign(taskData, {
        category: formData.get('category').trim() || 'Uncategorized',
        successesRequired: parseInt(formData.get('successesRequired')) || 0,
        currentSuccesses: parseInt(formData.get('currentSuccesses')) || 0,
        skills: formData.get('skills').trim(),
        isPlayerProject: formData.get('isPlayerProject') === 'on',
        successDisplayMode,
        successColorThresholds,
        drawingDocumentId: (formData.get('drawingDocumentId') || '').toString().trim()
      });
    }

    // Validate
    const errors = validateTask(taskData);
    if (errors.length > 0) {
      ui.notifications.error(errors.join(', '));
      return false;
    }

    try {
      if (isNewTask) {
        await TaskManager.addTask(taskData);
        ui.notifications.info(game.i18n.localize('SWADEPROJECTS.Notifications.ProjectAdded'));
      } else {
        await TaskManager.updateTask(taskData.id, taskData);
        ui.notifications.info(game.i18n.localize('SWADEPROJECTS.Notifications.ProjectUpdated'));
      }

      await this._syncProjectDrawingColor(taskData);
      this.render();
      return true;
    } catch (error) {
      console.error('Error saving project:', error);
      ui.notifications.error(game.i18n.localize('SWADEPROJECTS.Notifications.ProjectError'));
      return false;
    }
  }

  _prepareTaskForDisplay(task) {
    const normalized = normalizeTask(task);

    if (normalized.taskType !== TASK_TYPES.PROJECT) {
      return {
        ...normalized,
        isProjectTask: false,
        hasSuccessMetrics: false,
        hasSuccessDisplayColor: false,
        successDisplayColor: null,
        statusIcon: 'fas fa-list-check',
        statusClass: 'not-started',
        statusLabel: game.i18n.localize('SWADEPROJECTS.Status.Task')
      };
    }

    const successDisplayColor = resolveSuccessDisplayColor(normalized);
    const current = Number(normalized.currentSuccesses) || 0;
    const required = Number(normalized.successesRequired) || 0;

    let statusIcon = 'fas fa-circle';
    let statusClass = 'not-started';
    let statusLabel = game.i18n.localize('SWADEPROJECTS.Status.NotStarted');

    if (current >= required) {
      statusIcon = 'fas fa-check-circle';
      statusClass = 'complete';
      statusLabel = game.i18n.localize('SWADEPROJECTS.Status.Complete');
    } else if (current > 0) {
      statusIcon = 'fas fa-hourglass-half';
      statusClass = 'in-progress';
      statusLabel = game.i18n.localize('SWADEPROJECTS.Status.InProgress');
    }

    return {
      ...normalized,
      isProjectTask: true,
      hasSuccessMetrics: true,
      hasSuccessDisplayColor: Boolean(successDisplayColor),
      successDisplayColor,
      statusIcon,
      statusClass,
      statusLabel
    };
  }

  async _syncProjectDrawingColor(project) {
    if (project.taskType !== TASK_TYPES.PROJECT) {
      return;
    }

    if (project.successDisplayMode !== SUCCESS_DISPLAY_MODES.COLOR) {
      return;
    }

    const drawingDocumentId = (project.drawingDocumentId || '').trim();
    if (!drawingDocumentId) {
      return;
    }

    const color = resolveSuccessDisplayColor(project);
    if (!color) {
      return;
    }

    const drawingDoc = await this._findDrawingDocument(drawingDocumentId);
    if (!drawingDoc) {
      ui.notifications.warn(game.i18n.localize('SWADEPROJECTS.Notifications.DrawingNotFound'));
      return;
    }

    try {
      await drawingDoc.update({ strokeColor: color });
    } catch (primaryError) {
      try {
        await drawingDoc.update({ lineColor: color });
      } catch (fallbackError) {
        console.error('Error updating drawing color:', primaryError, fallbackError);
        ui.notifications.error(game.i18n.localize('SWADEPROJECTS.Notifications.DrawingUpdateError'));
      }
    }
  }

  async _findDrawingDocument(drawingDocumentId) {
    if (!drawingDocumentId) {
      return null;
    }

    // Allow UUID references in addition to raw drawing IDs.
    if (drawingDocumentId.includes('.')) {
      try {
        const fromUuidDoc = await fromUuid(drawingDocumentId);
        if (fromUuidDoc?.documentName === 'Drawing') {
          return fromUuidDoc;
        }
      } catch (error) {
        console.warn('Invalid drawing UUID reference:', drawingDocumentId, error);
      }
    }

    const currentScene = canvas?.scene;
    const currentSceneMatch = currentScene?.drawings?.get(drawingDocumentId);
    if (currentSceneMatch) {
      return currentSceneMatch;
    }

    for (const scene of game.scenes) {
      if (scene.id === currentScene?.id) {
        continue;
      }

      const sceneMatch = scene.drawings?.get(drawingDocumentId);
      if (sceneMatch) {
        return sceneMatch;
      }
    }

    return null;
  }

  /**
   * Delete a task with confirmation
   */
  async _deleteTask(taskId) {
    const task = TaskManager.getTaskById(taskId);
    if (!task) return;

    Dialog.confirm({
      title: game.i18n.localize('SWADEPROJECTS.Dialog.DeleteTask'),
      content: `<p>${game.i18n.format('SWADEPROJECTS.Confirmations.DeleteTask', { name: task.name })}</p>`,
      yes: async () => {
        try {
          await TaskManager.deleteTask(taskId);
          ui.notifications.info(game.i18n.localize('SWADEPROJECTS.Notifications.ProjectDeleted'));
          this.render();
        } catch (error) {
          console.error('Error deleting project:', error);
          ui.notifications.error(game.i18n.localize('SWADEPROJECTS.Notifications.ProjectError'));
        }
      }
    });
  }

  /**
   * Check if current user is GM
   */
  static async canOpen() {
    if (!game.user.isGM) {
      ui.notifications.warn(game.i18n.localize('SWADEPROJECTS.Warnings.OnlyGM'));
      return false;
    }
    return true;
  }

  /**
   * Open or toggle the dialog
   */
  static async toggle() {
    if (!(await this.canOpen())) return;
    
    const existing = ui.windows[Object.keys(ui.windows).find(key => ui.windows[key] instanceof this)];
    
    if (existing) {
      existing.close();
    } else {
      new this().render(true);
    }
  }
}
