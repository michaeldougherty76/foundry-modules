/**
 * Manages persistent storage of tasks in world settings
 */
import { normalizeTask, TASK_TYPES } from '../utils/helpers.js';

export class TaskManager {
  static MODULE_ID = 'swade-projects';
  static STORAGE_KEY = 'tasks';
  static LEGACY_STORAGE_KEY = 'projects';

  /**
   * Initialize task storage and migrate legacy project data if needed
   */
  static async initialize() {
    const existingTasksRaw = game.settings.get(this.MODULE_ID, this.STORAGE_KEY);
    const legacyProjectsRaw = game.settings.get(this.MODULE_ID, this.LEGACY_STORAGE_KEY);

    const existingTasks = Array.isArray(existingTasksRaw)
      ? existingTasksRaw.map((task) => normalizeTask(task))
      : [];

    const legacyProjects = Array.isArray(legacyProjectsRaw)
      ? legacyProjectsRaw.map((project) => normalizeTask({ ...project, taskType: TASK_TYPES.PROJECT }))
      : [];

    const mergedTasks = [...existingTasks];
    const knownIds = new Set(existingTasks.map((task) => task.id));

    for (const legacyProject of legacyProjects) {
      if (knownIds.has(legacyProject.id)) {
        continue;
      }
      mergedTasks.push(legacyProject);
      knownIds.add(legacyProject.id);
    }

    const targetTasks = mergedTasks;
    const shouldWrite = !Array.isArray(existingTasksRaw)
      || JSON.stringify(existingTasksRaw) !== JSON.stringify(targetTasks);

    if (shouldWrite) {
      await game.settings.set(this.MODULE_ID, this.STORAGE_KEY, targetTasks);
    }
  }

  /**
   * Get all tasks
   */
  static getAllTasks() {
    const tasks = game.settings.get(this.MODULE_ID, this.STORAGE_KEY);
    return Array.isArray(tasks) ? tasks.map((task) => normalizeTask(task)) : [];
  }

  /**
   * Get all project-type tasks
   */
  static getAllProjects() {
    return this.getAllTasks().filter((task) => task.taskType === TASK_TYPES.PROJECT);
  }

  /**
   * Get all tasks of a given type
   */
  static getTasksByType(taskType) {
    return this.getAllTasks().filter((task) => task.taskType === taskType);
  }

  /**
   * Get a task by ID
   */
  static getTaskById(taskId) {
    return this.getAllTasks().find((task) => task.id === taskId);
  }

  /**
   * Get player projects
   */
  static getPlayerProjects() {
    return this.getAllProjects().filter((project) => project.isPlayerProject === true);
  }

  /**
   * Get enemy projects
   */
  static getEnemyProjects() {
    return this.getAllProjects().filter((project) => project.isPlayerProject !== true);
  }

  /**
   * Get a project by ID
   */
  static getProjectById(projectId) {
    const task = this.getTaskById(projectId);
    return task?.taskType === TASK_TYPES.PROJECT ? task : null;
  }

  /**
   * Save a new task
   */
  static async addTask(taskData) {
    const tasks = this.getAllTasks();
    const normalizedTask = normalizeTask(taskData);
    tasks.push(normalizedTask);
    await game.settings.set(this.MODULE_ID, this.STORAGE_KEY, tasks);
    return normalizedTask;
  }

  /**
   * Save a new project
   */
  static async addProject(projectData) {
    return this.addTask({ ...projectData, taskType: TASK_TYPES.PROJECT });
  }

  /**
   * Update an existing task
   */
  static async updateTask(taskId, updates) {
    const tasks = this.getAllTasks();
    const task = tasks.find((item) => item.id === taskId);

    if (!task) {
      throw new Error(`Task ${taskId} not found`);
    }

    Object.assign(task, updates);
    const normalizedTask = normalizeTask(task);
    const index = tasks.findIndex((item) => item.id === taskId);
    tasks[index] = normalizedTask;
    await game.settings.set(this.MODULE_ID, this.STORAGE_KEY, tasks);
    return normalizedTask;
  }

  /**
   * Update an existing project
   */
  static async updateProject(projectId, updates) {
    return this.updateTask(projectId, { ...updates, taskType: TASK_TYPES.PROJECT });
  }

  /**
   * Delete a task
   */
  static async deleteTask(taskId) {
    const tasks = this.getAllTasks();
    const filtered = tasks.filter((task) => task.id !== taskId);
    await game.settings.set(this.MODULE_ID, this.STORAGE_KEY, filtered);
  }

  /**
   * Delete a project
   */
  static async deleteProject(projectId) {
    await this.deleteTask(projectId);
  }

  /**
   * Increment successes on a project
   */
  static async incrementProjectSuccesses(projectId, amount = 1) {
    const project = this.getProjectById(projectId);
    if (!project) {
      throw new Error(`Project ${projectId} not found`);
    }

    const newSuccesses = Math.min(
      project.currentSuccesses + amount,
      project.successesRequired
    );

    return this.updateProject(projectId, { currentSuccesses: newSuccesses });
  }

  /**
   * Decrement successes on a project
   */
  static async decrementProjectSuccesses(projectId, amount = 1) {
    const project = this.getProjectById(projectId);
    if (!project) {
      throw new Error(`Project ${projectId} not found`);
    }

    const newSuccesses = Math.max(0, project.currentSuccesses - amount);
    return this.updateProject(projectId, { currentSuccesses: newSuccesses });
  }
}

// Backward-compatible alias for external integrations.
export class ProjectManager extends TaskManager {}
