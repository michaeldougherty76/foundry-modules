/**
 * Utility functions for the SWADE Projects module
 */

const HEX_COLOR_PATTERN = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;

export const TASK_TYPES = {
  TASK: 'task',
  PROJECT: 'project'
};

export const SUCCESS_DISPLAY_MODES = {
  NUMBER: 'number',
  COLOR: 'color'
};

export const DEFAULT_SUCCESS_COLOR_THRESHOLDS = [
  { successes: 0, color: '#d46b6b' },
  { successes: 1, color: '#d8a95c' },
  { successes: 3, color: '#5ec2a8' }
];

/**
 * Generate a unique ID for a task
 */
export function generateTaskId() {
  return `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Backward-compatible alias.
export const generateProjectId = generateTaskId;

/**
 * Get unique categories from an array of projects, sorted alphabetically
 */
export function getUniqueCategories(projects) {
  const categories = new Set(
    projects
      .map(p => p.category || 'Uncategorized')
      .filter(cat => cat && cat.trim())
  );
  return Array.from(categories).sort((a, b) => a.localeCompare(b));
}

/**
 * Sort tasks by category
 */
export function sortTasksByCategory(tasks) {
  return tasks.sort((a, b) => {
    const catA = (a.category || 'Uncategorized').toLowerCase();
    const catB = (b.category || 'Uncategorized').toLowerCase();
    return catA.localeCompare(catB);
  });
}

// Backward-compatible alias.
export const sortProjectsByCategory = sortTasksByCategory;

/**
 * Validate task data
 */
export function validateTask(data) {
  const errors = [];
  const taskType = data.taskType === TASK_TYPES.PROJECT ? TASK_TYPES.PROJECT : TASK_TYPES.TASK;
  
  if (!data.name || !data.name.trim()) {
    errors.push('Task name is required');
  }

  if (taskType === TASK_TYPES.PROJECT) {
    if (typeof data.successesRequired !== 'number' || data.successesRequired < 0) {
      errors.push('Successes Required must be a positive number');
    }

    if (typeof data.currentSuccesses !== 'number' || data.currentSuccesses < 0) {
      errors.push('Current Successes must be a positive number');
    }

    if (data.currentSuccesses > data.successesRequired) {
      errors.push('Current Successes cannot exceed Successes Required');
    }

    if (![SUCCESS_DISPLAY_MODES.NUMBER, SUCCESS_DISPLAY_MODES.COLOR].includes(data.successDisplayMode)) {
      errors.push('Success display mode is invalid');
    }

    if (data.successDisplayMode === SUCCESS_DISPLAY_MODES.COLOR) {
      if (!Array.isArray(data.successColorThresholds) || data.successColorThresholds.length === 0) {
        errors.push('At least one success color rule is required when using color display');
      } else {
        for (const threshold of data.successColorThresholds) {
          const isValidSuccess = Number.isInteger(threshold.successes) && threshold.successes >= 0;
          const isValidColor = typeof threshold.color === 'string' && HEX_COLOR_PATTERN.test(threshold.color);

          if (!isValidSuccess || !isValidColor) {
            errors.push('Success color rules must use a non-negative number and a hex color like #36c18f');
            break;
          }
        }
      }
    }

    if (data.drawingDocumentId != null && typeof data.drawingDocumentId !== 'string') {
      errors.push('Drawing Document ID must be text');
    }
  }
  
  return errors;
}

// Backward-compatible alias.
export const validateProject = validateTask;

/**
 * Normalize task object shape for backward compatibility
 */
export function normalizeTask(task) {
  const input = task || {};
  const taskType = input.taskType
    ? input.taskType
    : TASK_TYPES.PROJECT;

  const normalized = {
    ...input,
    id: (input.id || generateTaskId()).toString(),
    taskType,
    name: (input.name || '').toString(),
    description: (input.description || '').toString()
  };

  if (taskType !== TASK_TYPES.PROJECT) {
    return normalized;
  }

  const successDisplayMode = input.successDisplayMode === SUCCESS_DISPLAY_MODES.COLOR
    ? SUCCESS_DISPLAY_MODES.COLOR
    : SUCCESS_DISPLAY_MODES.NUMBER;

  return {
    ...normalized,
    category: (input.category || '').toString(),
    successesRequired: Number.isFinite(Number(input.successesRequired)) ? parseInt(input.successesRequired, 10) : 0,
    currentSuccesses: Number.isFinite(Number(input.currentSuccesses)) ? parseInt(input.currentSuccesses, 10) : 0,
    skills: (input.skills || '').toString(),
    isPlayerProject: input.isPlayerProject === true,
    successDisplayMode,
    successColorThresholds: normalizeSuccessColorThresholds(input.successColorThresholds),
    drawingDocumentId: (input.drawingDocumentId || '').toString().trim()
  };
}

// Backward-compatible alias.
export const normalizeProject = normalizeTask;

/**
 * Parse textarea-based success-color rules into threshold objects
 */
export function parseSuccessColorThresholds(input) {
  const lines = (input || '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line.length > 0);

  const thresholds = [];
  const errors = [];

  for (const line of lines) {
    const match = line.match(/^(\d+)\s*[:=\-]\s*(#[0-9a-fA-F]{3}|#[0-9a-fA-F]{6})$/);
    if (!match) {
      errors.push(`Invalid success color rule: "${line}"`);
      continue;
    }

    thresholds.push({
      successes: parseInt(match[1], 10),
      color: match[2].toLowerCase()
    });
  }

  return {
    thresholds: normalizeSuccessColorThresholds(thresholds),
    errors
  };
}

/**
 * Convert thresholds into textarea-friendly lines
 */
export function formatSuccessColorThresholds(thresholds) {
  return normalizeSuccessColorThresholds(thresholds)
    .map((entry) => `${entry.successes}: ${entry.color}`)
    .join('\n');
}

/**
 * Resolve the display color based on current successes and configured thresholds
 */
export function resolveSuccessDisplayColor(project) {
  const normalized = normalizeTask(project);

  if (normalized.taskType !== TASK_TYPES.PROJECT) {
    return null;
  }

  if (normalized.successDisplayMode !== SUCCESS_DISPLAY_MODES.COLOR) {
    return null;
  }

  const thresholds = normalized.successColorThresholds;
  if (thresholds.length === 0) {
    return null;
  }

  const current = Number.isFinite(normalized.currentSuccesses) ? normalized.currentSuccesses : 0;
  let selected = thresholds[0];

  for (const threshold of thresholds) {
    if (threshold.successes <= current) {
      selected = threshold;
    } else {
      break;
    }
  }

  return selected?.color || null;
}

function normalizeSuccessColorThresholds(thresholds) {
  if (!Array.isArray(thresholds)) {
    return [];
  }

  const deduped = new Map();

  for (const raw of thresholds) {
    const successes = parseInt(raw?.successes, 10);
    const color = (raw?.color || '').toString().trim().toLowerCase();

    if (!Number.isInteger(successes) || successes < 0) {
      continue;
    }

    if (!HEX_COLOR_PATTERN.test(color)) {
      continue;
    }

    deduped.set(successes, { successes, color });
  }

  return Array.from(deduped.values()).sort((a, b) => a.successes - b.successes);
}

/**
 * Create a blank task object
 */
export function createBlankTask(taskType = TASK_TYPES.TASK) {
  const base = {
    id: generateTaskId(),
    taskType,
    name: '',
    description: ''
  };

  if (taskType !== TASK_TYPES.PROJECT) {
    return base;
  }

  return {
    ...base,
    category: '',
    successesRequired: 0,
    currentSuccesses: 0,
    skills: '',
    isPlayerProject: false,
    successDisplayMode: SUCCESS_DISPLAY_MODES.NUMBER,
    successColorThresholds: [],
    drawingDocumentId: ''
  };
}

// Backward-compatible alias.
export function createBlankProject() {
  return createBlankTask(TASK_TYPES.PROJECT);
}
